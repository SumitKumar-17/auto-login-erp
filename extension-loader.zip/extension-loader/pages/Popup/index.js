/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[0].use[1]!./node_modules/postcss-loader/dist/cjs.js!./src/pages/Popup/style.css":
/*!***********************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[0].use[1]!./node_modules/postcss-loader/dist/cjs.js!./src/pages/Popup/style.css ***!
  \***********************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__);
// Imports



var ___CSS_LOADER_URL_IMPORT_0___ = new URL(/* asset import */ __webpack_require__(/*! data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 20 20%27%3e%3cpath stroke=%27%236b7280%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%271.5%27 d=%27M6 8l4 4 4-4%27/%3e%3c/svg%3e */ "data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 20 20%27%3e%3cpath stroke=%27%236b7280%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%271.5%27 d=%27M6 8l4 4 4-4%27/%3e%3c/svg%3e"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_1___ = new URL(/* asset import */ __webpack_require__(/*! data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3cpath d=%27M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z%27/%3e%3c/svg%3e */ "data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3cpath d=%27M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z%27/%3e%3c/svg%3e"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_2___ = new URL(/* asset import */ __webpack_require__(/*! data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3ccircle cx=%278%27 cy=%278%27 r=%273%27/%3e%3c/svg%3e */ "data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3ccircle cx=%278%27 cy=%278%27 r=%273%27/%3e%3c/svg%3e"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_3___ = new URL(/* asset import */ __webpack_require__(/*! data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 16 16%27%3e%3cpath stroke=%27white%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%272%27 d=%27M4 8h8%27/%3e%3c/svg%3e */ "data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 16 16%27%3e%3cpath stroke=%27white%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%272%27 d=%27M4 8h8%27/%3e%3c/svg%3e"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_4___ = new URL(/* asset import */ __webpack_require__(/*! ../../assets/images/iitkgp-logo.svg */ "./src/assets/images/iitkgp-logo.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_5___ = new URL(/* asset import */ __webpack_require__(/*! ../../assets/images/bg.jpg */ "./src/assets/images/bg.jpg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_6___ = new URL(/* asset import */ __webpack_require__(/*! ../../assets/images/bg-dark.png */ "./src/assets/images/bg-dark.png"), __webpack_require__.b);
var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_2___);
var ___CSS_LOADER_URL_REPLACEMENT_3___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_3___);
var ___CSS_LOADER_URL_REPLACEMENT_4___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_4___);
var ___CSS_LOADER_URL_REPLACEMENT_5___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_5___);
var ___CSS_LOADER_URL_REPLACEMENT_6___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_6___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
! tailwindcss v3.3.3 | MIT License | https://tailwindcss.com
*//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
*/

html {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  tab-size: 4; /* 3 */
  font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font family by default.
2. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; /* 1 */
  font-size: 1em; /* 2 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
[type='button'],
[type='reset'],
[type='submit'] {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden] {
  display: none;
}

[type='text'],input:where(:not([type])),[type='email'],[type='url'],[type='password'],[type='number'],[type='date'],[type='datetime-local'],[type='month'],[type='search'],[type='tel'],[type='time'],[type='week'],[multiple],textarea,select {
  appearance: none;
  background-color: #fff;
  border-color: #6b7280;
  border-width: 1px;
  border-radius: 0px;
  padding-top: 0.5rem;
  padding-right: 0.75rem;
  padding-bottom: 0.5rem;
  padding-left: 0.75rem;
  font-size: 1rem;
  line-height: 1.5rem;
  --tw-shadow: 0 0 #0000;
}

[type='text']:focus, input:where(:not([type])):focus, [type='email']:focus, [type='url']:focus, [type='password']:focus, [type='number']:focus, [type='date']:focus, [type='datetime-local']:focus, [type='month']:focus, [type='search']:focus, [type='tel']:focus, [type='time']:focus, [type='week']:focus, [multiple]:focus, textarea:focus, select:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  border-color: #2563eb;
}

input::placeholder,textarea::placeholder {
  color: #6b7280;
  opacity: 1;
}

::-webkit-datetime-edit-fields-wrapper {
  padding: 0;
}

::-webkit-date-and-time-value {
  min-height: 1.5em;
}

::-webkit-datetime-edit,::-webkit-datetime-edit-year-field,::-webkit-datetime-edit-month-field,::-webkit-datetime-edit-day-field,::-webkit-datetime-edit-hour-field,::-webkit-datetime-edit-minute-field,::-webkit-datetime-edit-second-field,::-webkit-datetime-edit-millisecond-field,::-webkit-datetime-edit-meridiem-field {
  padding-top: 0;
  padding-bottom: 0;
}

select {
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_0___});
  background-position: right 0.5rem center;
  background-repeat: no-repeat;
  background-size: 1.5em 1.5em;
  padding-right: 2.5rem;
  print-color-adjust: exact;
}

[multiple],[size]:where(select:not([size="1"])) {
  background-image: initial;
  background-position: initial;
  background-repeat: unset;
  background-size: initial;
  padding-right: 0.75rem;
  print-color-adjust: unset;
}

[type='checkbox'],[type='radio'] {
  appearance: none;
  padding: 0;
  print-color-adjust: exact;
  display: inline-block;
  vertical-align: middle;
  background-origin: border-box;
  user-select: none;
  flex-shrink: 0;
  height: 1rem;
  width: 1rem;
  color: #2563eb;
  background-color: #fff;
  border-color: #6b7280;
  border-width: 1px;
  --tw-shadow: 0 0 #0000;
}

[type='checkbox'] {
  border-radius: 0px;
}

[type='radio'] {
  border-radius: 100%;
}

[type='checkbox']:focus,[type='radio']:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width: 2px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
}

[type='checkbox']:checked,[type='radio']:checked {
  border-color: transparent;
  background-color: currentColor;
  background-size: 100% 100%;
  background-position: center;
  background-repeat: no-repeat;
}

[type='checkbox']:checked {
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_1___});
}

[type='radio']:checked {
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_2___});
}

[type='checkbox']:checked:hover,[type='checkbox']:checked:focus,[type='radio']:checked:hover,[type='radio']:checked:focus {
  border-color: transparent;
  background-color: currentColor;
}

[type='checkbox']:indeterminate {
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_3___});
  border-color: transparent;
  background-color: currentColor;
  background-size: 100% 100%;
  background-position: center;
  background-repeat: no-repeat;
}

[type='checkbox']:indeterminate:hover,[type='checkbox']:indeterminate:focus {
  border-color: transparent;
  background-color: currentColor;
}

[type='file'] {
  background: unset;
  border-color: inherit;
  border-width: 0;
  border-radius: 0;
  padding: 0;
  font-size: unset;
  line-height: inherit;
}

[type='file']:focus {
  outline: 1px solid ButtonText;
  outline: 1px auto -webkit-focus-ring-color;
}
  * {
    scrollbar-width: none;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    scroll-behavior: auto !important;
  }

  body {
    color-scheme: light dark;
    font-family: system-ui, sans-serif;
    font-weight: 300;
    font-size: 13px;
    line-height: 1.7;
    position: relative;
    height: 600px;
    width: 348px;
    overflow: hidden;
    --tw-bg-opacity: 1;
    background-color: rgb(229 231 235 / var(--tw-bg-opacity));
    --tw-text-opacity: 1;
    color: rgb(31 41 55 / var(--tw-text-opacity));
  }

  :is(.dark body) {
  --tw-bg-opacity: 1;
  background-color: rgb(25 25 25 / var(--tw-bg-opacity));
  --tw-text-opacity: 1;
  color: rgb(229 231 235 / var(--tw-text-opacity));
}

  [type='text'],
  [type='password'],
  [type='number'],
  [multiple],
  textarea,
  select {
  width: 100%;
  cursor: pointer;
  border-radius: 0.375rem;
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

  [type='text']:focus,
  [type='password']:focus,
  [type='number']:focus,
  [multiple]:focus,
  textarea:focus,
  select:focus {
  --tw-border-opacity: 1;
  border-color: rgb(99 102 241 / var(--tw-border-opacity));
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(99 102 241 / var(--tw-ring-opacity));
}

  [type='text']:disabled,
  [type='password']:disabled,
  [type='number']:disabled,
  [multiple]:disabled,
  textarea:disabled,
  select:disabled {
  cursor: not-allowed;
  background-color: rgb(0 0 0 / 0.1);
}

  :is(.dark [type='text']:disabled),:is(.dark 
  [type='password']:disabled),:is(.dark 
  [type='number']:disabled),:is(.dark 
  [multiple]:disabled),:is(.dark 
  textarea:disabled),:is(.dark 
  select:disabled) {
  background-color: rgb(74 74 74 / 0.8);
}
  select {
  font-weight: 400;
}
  [type='checkbox'],
  [type='radio'] {
  height: 1rem;
  width: 1rem;
  border-radius: 9999px;
  --tw-border-opacity: 1;
  border-color: rgb(209 213 219 / var(--tw-border-opacity));
  background-color: rgb(255 255 255 / 0.2);
  --tw-text-opacity: 1;
  color: rgb(79 70 229 / var(--tw-text-opacity));
}
  [type='checkbox']:focus,
  [type='radio']:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(99 102 241 / var(--tw-ring-opacity));
  --tw-ring-offset-width: 0px;
}
  .required-asterisk::after {
  margin-left: 0.125rem;
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity));
  --tw-content: '*';
  content: var(--tw-content);
}

  /* main layout (full popup) */
  .box-container {
  margin-left: auto;
  margin-right: auto;
  display: flex;
  height: 100%;
  width: 100%;
  flex-direction: column;
  align-items: stretch;
}
  .box-container.right-open .box1-content {
  pointer-events: none;
  flex: 0;
  opacity: 0;
}
  .box-container.right-open .box1-side {
  flex: 0;
  opacity: 0;
}
  .box-container.right-open .box2-side {
  flex: 1;
  opacity: 1;
}
  .box-container.right-open .box2-content {
  flex: 5;
  padding: 1rem;
  opacity: 1;
}
  .box1-content,
  .box1-side,
  .box2-content,
  .box2-side {
  overflow: hidden;
  transition-property: all;
  transition-duration: 300ms;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
  .box1-side,
  .box2-side {
  display: flex;
  align-items: center;
  justify-content: center;
}
  .box1-content {
  flex: 5.4;
  opacity: 1;
}
  .box1-side {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}
  :is(.dark .box1-side) {
  --tw-bg-opacity: 1;
  background-color: rgb(36 37 38 / var(--tw-bg-opacity));
}
  .box1-side { /* to add blur, @apply bg-white/40 backdrop-blur-md dark:bg-[#242526]/40; } */ top: 0.25rem; bottom: 0.25rem; margin-left: 1rem; margin-right: 1rem; margin-bottom: 1rem; height: 100%; flex: 0.6; justify-content: flex-start; border-radius: 0.375rem; --tw-shadow: 0 3px 2px -1px rgba(0,0,0,0.1); --tw-shadow-colored: 0 3px 2px -1px var(--tw-shadow-color); box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
  }
  .box2-side {
  flex: 0;
  opacity: 0;
}
  .box2-content {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}
  :is(.dark .box2-content) {
  --tw-bg-opacity: 1;
  background-color: rgb(36 37 38 / var(--tw-bg-opacity));
}
  .box2-content { /* to add blur, @apply bg-white/40 backdrop-blur-md dark:bg-[#242526]/40; } */ bottom: 0px; left: 0px; right: 0px; margin-bottom: 0px; display: flex; flex: 0; flex-direction: column; justify-content: center;
  }
  .box2-content > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1rem * var(--tw-space-y-reverse));
}
  .box2-content {
  opacity: 0;
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

  /* Form */
  .form-textbox {
  display: flex;
  flex-direction: column;
}
  .form-textbox > label,
  .form-textbox-label {
  margin-bottom: 0.25rem;
  display: block;
  font-size: 0.875rem;
  line-height: 1.25rem;
  font-weight: 500;
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity));
}
  :is(.dark .form-textbox > label),:is(.dark 
  .form-textbox-label) {
  --tw-text-opacity: 1;
  color: rgb(229 231 235 / var(--tw-text-opacity));
}
  .form-textbox > div {
  position: relative;
  width: 100%;
}
  .form-textbox > div > div {
  position: absolute;
  left: 0px;
  top: 0px;
  display: flex;
  height: 100%;
  width: 2.5rem;
  align-items: center;
  justify-content: center;
  border-right-width: 1px;
  --tw-border-opacity: 1;
  border-color: rgb(209 213 219 / var(--tw-border-opacity));
}
  :is(.dark .form-textbox > div > div) {
  border-color: rgb(209 213 219 / 0.1);
}
  .form-textbox > div > div > svg {
  height: 1rem;
  width: 1rem;
  fill: currentColor;
}
  :is(.dark .form-textbox > div > div > svg) {
  fill: #e2e8f0;
}
  .form-textbox > div > input {
  width: 100%;
  --tw-border-opacity: 1;
  border-color: rgb(209 213 219 / var(--tw-border-opacity));
  padding-left: 3rem;
  font-size: 0.75rem;
  line-height: 1rem;
}
  .form-textbox > div > input::placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(156 163 175 / var(--tw-placeholder-opacity));
}
  .form-textbox > div > input:disabled {
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
  :is(.dark .form-textbox > div > input) {
  border-color: rgb(209 213 219 / 0.1);
  background-color: rgb(255 255 255 / 0.05);
}

  /* Message */
  .action {
  cursor: pointer;
  border-radius: 0.125rem;
  background-color: rgb(0 0 0 / 0.1);
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}
  .info,
  .warning,
  .error,
  .success {
  display: flex;
  height: 100%;
  max-height: 2rem;
  align-items: center;
  gap: 0.5rem;
  border-radius: 0.375rem;
  --tw-bg-opacity: 1;
  background-color: rgb(148 163 184 / var(--tw-bg-opacity));
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
  padding-left: 0.75rem;
  padding-right: 0.75rem;
  font-weight: 400;
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity));
}
  .info > svg,
  .warning > svg,
  .error > svg,
  .success > svg {
  height: 1rem;
  width: 1rem;
  fill: currentColor;
}
  .warning {
  display: flex;
  height: 100%;
  max-height: 2rem;
  align-items: center;
  gap: 0.5rem;
  border-radius: 0.375rem;
  --tw-bg-opacity: 1;
  background-color: rgb(148 163 184 / var(--tw-bg-opacity));
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
  padding-left: 0.75rem;
  padding-right: 0.75rem;
  font-weight: 400;
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity));
}
  .warning > svg {
  height: 1rem;
  width: 1rem;
  fill: currentColor;
}
  .warning {
  --tw-bg-opacity: 1;
  background-color: rgb(253 224 71 / var(--tw-bg-opacity));
}
  .error {
  display: flex;
  height: 100%;
  max-height: 2rem;
  align-items: center;
  gap: 0.5rem;
  border-radius: 0.375rem;
  --tw-bg-opacity: 1;
  background-color: rgb(148 163 184 / var(--tw-bg-opacity));
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
  padding-left: 0.75rem;
  padding-right: 0.75rem;
  font-weight: 400;
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity));
}
  .error > svg {
  height: 1rem;
  width: 1rem;
  fill: currentColor;
}
  .error {
  --tw-bg-opacity: 1;
  background-color: rgb(252 165 165 / var(--tw-bg-opacity));
}
  .success {
  display: flex;
  height: 100%;
  max-height: 2rem;
  align-items: center;
  gap: 0.5rem;
  border-radius: 0.375rem;
  --tw-bg-opacity: 1;
  background-color: rgb(148 163 184 / var(--tw-bg-opacity));
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
  padding-left: 0.75rem;
  padding-right: 0.75rem;
  font-weight: 400;
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity));
}
  .success > svg {
  height: 1rem;
  width: 1rem;
  fill: currentColor;
}
  .success {
  --tw-bg-opacity: 1;
  background-color: rgb(134 239 172 / var(--tw-bg-opacity));
}

*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {

  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {

  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {

  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {

  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {

  .container {
    max-width: 1536px;
  }
}
/* Components */
.link-text {
  --tw-text-opacity: 1;
  color: rgb(79 70 229 / var(--tw-text-opacity));
}
.link-text:hover {
  --tw-text-opacity: 1;
  color: rgb(99 102 241 / var(--tw-text-opacity));
}
:is(.dark .link-text) {
  --tw-text-opacity: 1;
  color: rgb(129 140 248 / var(--tw-text-opacity));
}
:is(.dark .link-text:hover) {
  --tw-text-opacity: 1;
  color: rgb(99 102 241 / var(--tw-text-opacity));
}
.svg-btn-primary,
  .svg-btn-secondary {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  border-radius: 0.375rem;
  border-width: 1px;
  border-color: transparent;
  --tw-bg-opacity: 1;
  background-color: rgb(79 70 229 / var(--tw-bg-opacity));
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
  padding-left: 1rem;
  padding-right: 1rem;
  font-size: 0.75rem;
  line-height: 1rem;
  font-weight: 500;
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity));
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.svg-btn-primary:disabled,
  .svg-btn-secondary:disabled {
  cursor: not-allowed;
  --tw-bg-opacity: 1;
  background-color: rgb(165 180 252 / var(--tw-bg-opacity));
}
.svg-btn-primary > svg,
  .svg-btn-secondary > svg {
  height: 1rem;
  width: 1rem;
  fill: #fff;
}
.svg-btn-secondary {
  background-color: rgb(75 85 99 / 0.4);
  --tw-text-opacity: 1;
  color: rgb(17 24 39 / var(--tw-text-opacity));
}
.svg-btn-secondary:hover {
  background-color: rgb(75 85 99 / 0.3);
}
:is(.dark .svg-btn-secondary) {
  --tw-bg-opacity: 1;
  background-color: rgb(51 65 85 / var(--tw-bg-opacity));
  --tw-text-opacity: 1;
  color: rgb(209 213 219 / var(--tw-text-opacity));
}
.svg-btn-secondary > svg {
  height: 1rem;
  width: 1rem;
  fill: #111827;
}
:is(.dark .svg-btn-secondary > svg) {
  fill: #d1d5db;
}
/* panel */
.box-toggle-btn {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}
:is(.dark .box-toggle-btn) {
  --tw-bg-opacity: 1;
  background-color: rgb(36 37 38 / var(--tw-bg-opacity));
}
.box-toggle-btn { /* to add blur, @apply bg-white/40 backdrop-blur-md dark:bg-[#242526]/40; } */ display: flex; align-items: center; justify-content: center; gap: 0.5rem; border-radius: 0.375rem; border-width: 1px; border-color: transparent; padding-top: 0.5rem; padding-bottom: 0.5rem; padding-left: 1rem; padding-right: 1rem; font-size: 0.75rem; line-height: 1rem; font-weight: 500; --tw-text-opacity: 1; color: rgb(0 0 0 / var(--tw-text-opacity)); --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1); --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color); box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow); --tw-backdrop-blur: blur(12px); backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
  }
.box-toggle-btn:hover {
  background-color: rgb(255 255 255 / 0.4);
}
:is(.dark .box-toggle-btn) {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity));
}
:is(.dark .box-toggle-btn):hover {
  background-color: rgb(0 0 0 / 0.4);
}
.box-toggle-btn > svg {
  height: 1rem;
  width: 1rem;
  fill: currentColor;
}
.box-toggle-btn > span {
  text-transform: uppercase;
}
.box-toggle-btn-panel-item {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  border-bottom-right-radius: 0.375rem;
  border-bottom-left-radius: 0.375rem;
}
.box-toggle-btn-panel-item > svg {
  height: 1rem;
  width: 1rem;
  fill: #000;
}
:is(.dark .box-toggle-btn-panel-item > svg) {
  fill: #111827;
}
.box-toggle-btn-panel-item > span {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
  font-weight: 400;
  text-transform: uppercase;
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity));
}
:is(.dark .box-toggle-btn-panel-item > span) {
  --tw-text-opacity: 1;
  color: rgb(17 24 39 / var(--tw-text-opacity));
}
.panel-container {
  position: absolute;
  left: 1rem;
  right: 1rem;
  top: 1rem;
  margin-left: auto;
  margin-right: auto;
  display: flex;
  flex: 1 1 0%;
  flex-direction: row;
  overflow: hidden;
  padding-bottom: 0.5rem;
}
.panel {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}
:is(.dark .panel) {
  --tw-bg-opacity: 1;
  background-color: rgb(36 37 38 / var(--tw-bg-opacity));
}
.panel { /* to add blur, @apply bg-white/40 backdrop-blur-md dark:bg-[#242526]/40; } */ height: 100%; max-height: 490px; width: 100%; flex-shrink: 0; flex-grow: 0; flex-basis: 100%; scroll-snap-align: start; overflow-y: auto; border-radius: 0.375rem; padding-bottom: 0.5rem; --tw-shadow: 0 3px 2px -1px rgba(0,0,0,0.1); --tw-shadow-colored: 0 3px 2px -1px var(--tw-shadow-color); box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
  }
.panel:first-of-type {
  padding-bottom: 0px;
}
.panel-header {
  position: relative;
  display: flex;
  height: 40px;
  width: 100%;
  border-bottom-width: 1px;
  border-bottom-color: rgb(156 163 175 / 0.4);
}
.panel-header-start,
  .panel-header-end {
  margin: 0.25rem;
  display: flex;
  width: 40px;
  align-items: center;
  justify-content: center;
  border-radius: 0.375rem;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}
.panel-header-start:hover,
  .panel-header-end:hover {
  background-color: rgb(156 163 175 / 0.3);
}
:is(.dark .panel-header-start:hover),:is(.dark 
  .panel-header-end:hover) {
  background-color: rgb(255 255 255 / 0.3);
}
.panel-header-middle {
  display: flex;
  flex: 1 1 0%;
  align-items: center;
  justify-content: center;
  font-weight: 500;
  text-transform: uppercase;
}
.panel-header-start > svg,
  .panel-header-end > svg {
  height: 1rem;
  width: 1rem;
  fill: #475569;
}
:is(.dark .panel-header-start > svg),:is(.dark 
  .panel-header-end > svg) {
  fill: #e2e8f0;
}
.panel-group-label {
  margin-left: 0.75rem;
  margin-right: 0.75rem;
  margin-top: 0.5rem;
  text-align: right;
  font-size: 11px;
  --tw-text-opacity: 1;
  color: rgb(75 85 99 / var(--tw-text-opacity));
}
:is(.dark .panel-group-label) {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity));
}
.panel-group-divider {
  margin-top: 0.125rem;
  margin-bottom: 0.125rem;
  border-color: rgb(156 163 175 / 0.4);
}
:is(.dark .panel-group-divider) {
  border-color: rgb(229 231 235 / 0.4);
}
.panel-group-item {
  position: relative;
  display: flex;
  height: 32px;
  width: 100%;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.panel-group-item:hover {
  background-color: rgb(156 163 175 / 0.3);
}
:is(.dark .panel-group-item:hover) {
  background-color: rgb(156 163 175 / 0.4);
}
.panel-group-item-start,
  .panel-group-item-end {
  display: flex;
  width: 40px;
  align-items: center;
  justify-content: center;
  padding: 0.25rem;
}
.panel-group-item-start > svg,
  .panel-group-item-end > svg {
  height: 1rem;
  width: 1rem;
  fill: #0f172a;
}
:is(.dark .panel-group-item-start > svg),:is(.dark 
  .panel-group-item-end > svg) {
  fill: #e2e8f0;
}
.panel-group-item-end > svg {
  fill: #475569;
}
:is(.dark .panel-group-item-end > svg) {
  fill: #94a3b8;
}
.panel-group-item-middle {
  display: flex;
  flex: 1 1 0%;
  flex-direction: column;
  justify-content: center;
}
.panel-group-item-middle > h2 {
  font-weight: 400;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.inset-0 {
  inset: 0px;
}
.left-0 {
  left: 0px;
}
.left-5 {
  left: 1.25rem;
}
.top-0 {
  top: 0px;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.-ml-7 {
  margin-left: -1.75rem;
}
.-mr-7 {
  margin-right: -1.75rem;
}
.ml-2 {
  margin-left: 0.5rem;
}
.block {
  display: block;
}
.flex {
  display: flex;
}
.h-12 {
  height: 3rem;
}
.h-20 {
  height: 5rem;
}
.h-4 {
  height: 1rem;
}
.h-5 {
  height: 1.25rem;
}
.h-full {
  height: 100%;
}
.w-10 {
  width: 2.5rem;
}
.w-12 {
  width: 3rem;
}
.w-20 {
  width: 5rem;
}
.w-4 {
  width: 1rem;
}
.w-5 {
  width: 1.25rem;
}
.w-full {
  width: 100%;
}
@keyframes spin {

  to {
    transform: rotate(360deg);
  }
}
.animate-\\[spin_0\\.2s_linear_infinite\\] {
  animation: spin 0.2s linear infinite;
}
.cursor-pointer {
  cursor: pointer;
}
.flex-row {
  flex-direction: row;
}
.flex-col {
  flex-direction: column;
}
.items-center {
  align-items: center;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-1 {
  gap: 0.25rem;
}
.gap-2 {
  gap: 0.5rem;
}
.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.25rem * var(--tw-space-y-reverse));
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-bl {
  border-bottom-left-radius: 0.25rem;
}
.rounded-tl {
  border-top-left-radius: 0.25rem;
}
.border {
  border-width: 1px;
}
.border-0 {
  border-width: 0px;
}
.border-transparent {
  border-color: transparent;
}
.bg-sky-500\\/40 {
  background-color: rgb(14 165 233 / 0.4);
}
.bg-transparent {
  background-color: transparent;
}
.bg-white {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}
.bg-\\[url\\(\\'\\.\\.\\/\\.\\.\\/assets\\/images\\/iitkgp-logo\\.svg\\'\\)\\] {
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_4___});
}
.bg-contain {
  background-size: contain;
}
.bg-no-repeat {
  background-repeat: no-repeat;
}
.fill-current {
  fill: currentColor;
}
.fill-slate-600 {
  fill: #475569;
}
.fill-slate-900 {
  fill: #0f172a;
}
.p-4 {
  padding: 1rem;
}
.pl-2 {
  padding-left: 0.5rem;
}
.pl-\\[40px\\] {
  padding-left: 40px;
}
.pr-3 {
  padding-right: 0.75rem;
}
.text-center {
  text-align: center;
}
.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}
.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}
.font-medium {
  font-weight: 500;
}
.font-semibold {
  font-weight: 600;
}
.text-gray-600 {
  --tw-text-opacity: 1;
  color: rgb(75 85 99 / var(--tw-text-opacity));
}
.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity));
}
.text-gray-900 {
  --tw-text-opacity: 1;
  color: rgb(17 24 39 / var(--tw-text-opacity));
}
.opacity-25 {
  opacity: 0.25;
}
.opacity-75 {
  opacity: 0.75;
}
.shadow-none {
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline-none {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.ring-0 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.bg-theme {
  background: rgb(181, 214, 243) url(${___CSS_LOADER_URL_REPLACEMENT_5___}) fixed center;
  background-size: cover;
  background-repeat: no-repeat;
}

.bg-theme-dark {
  background: rgb(10, 17, 23) url(${___CSS_LOADER_URL_REPLACEMENT_6___}) fixed center;
  background-size: cover;
  background-repeat: no-repeat;
}

.hover\\:bg-gray-400\\/30:hover {
  background-color: rgb(156 163 175 / 0.3);
}

.focus\\:border-0:focus {
  border-width: 0px;
}

.focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}

.focus\\:ring-0:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

:is(.dark .dark\\:bg-\\[\\#191919\\]) {
  --tw-bg-opacity: 1;
  background-color: rgb(25 25 25 / var(--tw-bg-opacity));
}

:is(.dark .dark\\:bg-slate-200) {
  --tw-bg-opacity: 1;
  background-color: rgb(226 232 240 / var(--tw-bg-opacity));
}

:is(.dark .dark\\:fill-slate-200) {
  fill: #e2e8f0;
}

:is(.dark .dark\\:fill-slate-400) {
  fill: #94a3b8;
}

:is(.dark .dark\\:text-gray-200) {
  --tw-text-opacity: 1;
  color: rgb(229 231 235 / var(--tw-text-opacity));
}

:is(.dark .dark\\:text-gray-400) {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity));
}

:is(.dark .dark\\:hover\\:bg-gray-400\\/40:hover) {
  background-color: rgb(156 163 175 / 0.4);
}
`, "",{"version":3,"sources":["webpack://./src/pages/Popup/style.css","<no source>"],"names":[],"mappings":"AAAA;;CAAc,CAAd;;;CAAc;;AAAd;;;EAAA,sBAAc,EAAd,MAAc;EAAd,eAAc,EAAd,MAAc;EAAd,mBAAc,EAAd,MAAc;EAAd,qBAAc,EAAd,MAAc;AAAA;;AAAd;;EAAA,gBAAc;AAAA;;AAAd;;;;;;;CAAc;;AAAd;EAAA,gBAAc,EAAd,MAAc;EAAd,8BAAc,EAAd,MAAc;EAAd,gBAAc,EAAd,MAAc;EAAd,WAAc,EAAd,MAAc;EAAd,4NAAc,EAAd,MAAc;EAAd,6BAAc,EAAd,MAAc;EAAd,+BAAc,EAAd,MAAc;AAAA;;AAAd;;;CAAc;;AAAd;EAAA,SAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;AAAA;;AAAd;;;;CAAc;;AAAd;EAAA,SAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;EAAd,qBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,iCAAc;AAAA;;AAAd;;CAAc;;AAAd;;;;;;EAAA,kBAAc;EAAd,oBAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,cAAc;EAAd,wBAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,mBAAc;AAAA;;AAAd;;;CAAc;;AAAd;;;;EAAA,+GAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,cAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,cAAc;EAAd,cAAc;EAAd,kBAAc;EAAd,wBAAc;AAAA;;AAAd;EAAA,eAAc;AAAA;;AAAd;EAAA,WAAc;AAAA;;AAAd;;;;CAAc;;AAAd;EAAA,cAAc,EAAd,MAAc;EAAd,qBAAc,EAAd,MAAc;EAAd,yBAAc,EAAd,MAAc;AAAA;;AAAd;;;;CAAc;;AAAd;;;;;EAAA,oBAAc,EAAd,MAAc;EAAd,8BAAc,EAAd,MAAc;EAAd,gCAAc,EAAd,MAAc;EAAd,eAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;EAAd,SAAc,EAAd,MAAc;EAAd,UAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,oBAAc;AAAA;;AAAd;;;CAAc;;AAAd;;;;EAAA,0BAAc,EAAd,MAAc;EAAd,6BAAc,EAAd,MAAc;EAAd,sBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,aAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,gBAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,wBAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,YAAc;AAAA;;AAAd;;;CAAc;;AAAd;EAAA,6BAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,wBAAc;AAAA;;AAAd;;;CAAc;;AAAd;EAAA,0BAAc,EAAd,MAAc;EAAd,aAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,kBAAc;AAAA;;AAAd;;CAAc;;AAAd;;;;;;;;;;;;;EAAA,SAAc;AAAA;;AAAd;EAAA,SAAc;EAAd,UAAc;AAAA;;AAAd;EAAA,UAAc;AAAA;;AAAd;;;EAAA,gBAAc;EAAd,SAAc;EAAd,UAAc;AAAA;;AAAd;;CAAc;AAAd;EAAA,UAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,gBAAc;AAAA;;AAAd;;;CAAc;;AAAd;;EAAA,UAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,eAAc;AAAA;;AAAd;;CAAc;AAAd;EAAA,eAAc;AAAA;;AAAd;;;;CAAc;;AAAd;;;;;;;;EAAA,cAAc,EAAd,MAAc;EAAd,sBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,eAAc;EAAd,YAAc;AAAA;;AAAd,wEAAc;AAAd;EAAA,aAAc;AAAA;;AAAd;EAAA,gBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,iBAAc;EAAd,kBAAc;EAAd,mBAAc;EAAd,sBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,eAAc;EAAd,mBAAc;EAAd,sBAAc;AAAA;;AAAd;EAAA,8BAAc;EAAd,mBAAc;EAAd,4CAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,wBAAc;EAAd,2GAAc;EAAd,yGAAc;EAAd,iFAAc;EAAd;AAAc;;AAAd;EAAA,cAAc;EAAd;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA,cAAc;EAAd;AAAc;;AAAd;EAAA,yDAAc;EAAd,wCAAc;EAAd,4BAAc;EAAd,4BAAc;EAAd,qBAAc;EAAd;AAAc;;AAAd;EAAA,yBAAc;EAAd,4BAAc;EAAd,wBAAc;EAAd,wBAAc;EAAd,sBAAc;EAAd;AAAc;;AAAd;EAAA,gBAAc;EAAd,UAAc;EAAd,yBAAc;EAAd,qBAAc;EAAd,sBAAc;EAAd,6BAAc;EAAd,iBAAc;EAAd,cAAc;EAAd,YAAc;EAAd,WAAc;EAAd,cAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,iBAAc;EAAd;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA,8BAAc;EAAd,mBAAc;EAAd,4CAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,wBAAc;EAAd,2GAAc;EAAd,yGAAc;EAAd;AAAc;;AAAd;EAAA,yBAAc;EAAd,8BAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA,yBAAc;EAAd;AAAc;;AAAd;EAAA,yDAAc;EAAd,yBAAc;EAAd,8BAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd;AAAc;;AAAd;EAAA,yBAAc;EAAd;AAAc;;AAAd;EAAA,iBAAc;EAAd,qBAAc;EAAd,eAAc;EAAd,gBAAc;EAAd,UAAc;EAAd,gBAAc;EAAd;AAAc;;AAAd;EAAA,6BAAc;EAAd;AAAc;EAAd;IAAA,qBAAc;IAAd,mCAAc;IAAd,kCAAc;IAAd,gCAAc;EAAA;;EAAd;IAAA,wBAAc;IAAd,kCAAc;IAAd,gBAAc;IAAd,eAAc;IAAd,gBAAc;IAAd,kBAAc;IAAd,aAAc;IAAd,YAAc;IAAd,gBAAc;IAAd,kBAAc;IAAd,yDAAc;IAAd,oBAAc;IAAd,6CAAc;EAAA;;EAAd;EAAA,kBAAc;EAAd,sDAAc;EAAd,oBAAc;EAAd;AAAc;;EAAd;;;;;;EAAA,WAAc;EAAd,eAAc;EAAd,uBAAc;EAAd,0CAAc;EAAd,uDAAc;EAAd;AAAc;;EAAd;;;;;;EAAA,sBAAc;EAAd,wDAAc;EAAd,oBAAc;EAAd;AAAc;;EAAd;;;;;;EAAA,mBAAc;EAAd;AAAc;;EAAd;;;;;;EAAA;AAAc;EAAd;EAAA;AAAc;EAAd;;EAAA,YAAc;EAAd,WAAc;EAAd,qBAAc;EAAd,sBAAc;EAAd,yDAAc;EAAd,wCAAc;EAAd,oBAAc;EAAd;AAAc;EAAd;;EAAA,2GAAc;EAAd,yGAAc;EAAd,4FAAc;EAAd,oBAAc;EAAd,yDAAc;EAAd;AAAc;EAAd;EAAA,qBAAc;EAAd,oBAAc;EAAd,8CAAc;EAAd,iBAAc;EAAd;AAAc;;EAAd,6BAAc;EAAd;EAAA,iBAAc;EAAd,kBAAc;EAAd,aAAc;EAAd,YAAc;EAAd,WAAc;EAAd,sBAAc;EAAd;AAAc;EAAd;EAAA,oBAAc;EAAd,OAAc;EAAd;AAAc;EAAd;EAAA,OAAc;EAAd;AAAc;EAAd;EAAA,OAAc;EAAd;AAAc;EAAd;EAAA,OAAc;EAAd,aAAc;EAAd;AAAc;EAAd;;;;EAAA,gBAAc;EAAd,wBAAc;EAAd,0BAAc;EAAd;AAAc;EAAd;;EAAA,aAAc;EAAd,mBAAc;EAAd;AAAc;EAAd;EAAA,SAAc;EAAd;AAAc;EAAd;EAAA,kBAAc;EAAd;AAAc;EAAd;EAAA,kBAAc;EAAd;AAAc;EAAd,aAAA,6EAAc,EAAd,YAAc,EAAd,eAAc,EAAd,iBAAc,EAAd,kBAAc,EAAd,mBAAc,EAAd,YAAc,EAAd,SAAc,EAAd,2BAAc,EAAd,uBAAc,EAAd,2CAAc,EAAd,0DAAc,EAAd,uGAAc;EAAA;EAAd;EAAA,OAAc;EAAd;AAAc;EAAd;EAAA,kBAAc;EAAd;AAAc;EAAd;EAAA,kBAAc;EAAd;AAAc;EAAd,gBAAA,6EAAc,EAAd,WAAc,EAAd,SAAc,EAAd,UAAc,EAAd,kBAAc,EAAd,aAAc,EAAd,OAAc,EAAd,sBAAc,EAAd,uBAAc;EAAA;EAAd;EAAA,uBAAc;EAAd,4DAAc;EAAd;AAAc;EAAd;EAAA,UAAc;EAAd,0CAAc;EAAd,uDAAc;EAAd;AAAc;;EAAd,SAAc;EAAd;EAAA,aAAc;EAAd;AAAc;EAAd;;EAAA,sBAAc;EAAd,cAAc;EAAd,mBAAc;EAAd,oBAAc;EAAd,gBAAc;EAAd,oBAAc;EAAd;AAAc;EAAd;;EAAA,oBAAc;EAAd;AAAc;EAAd;EAAA,kBAAc;EAAd;AAAc;EAAd;EAAA,kBAAc;EAAd,SAAc;EAAd,QAAc;EAAd,aAAc;EAAd,YAAc;EAAd,aAAc;EAAd,mBAAc;EAAd,uBAAc;EAAd,uBAAc;EAAd,sBAAc;EAAd;AAAc;EAAd;EAAA;AAAc;EAAd;EAAA,YAAc;EAAd,WAAc;EAAd;AAAc;EAAd;EAAA;AAAc;EAAd;EAAA,WAAc;EAAd,sBAAc;EAAd,yDAAc;EAAd,kBAAc;EAAd,kBAAc;EAAd;AAAc;EAAd;EAAA,2BAAc;EAAd;AAAc;EAAd;EAAA,sBAAc;EAAd,8BAAc;EAAd;AAAc;EAAd;EAAA,oCAAc;EAAd;AAAc;;EAAd,YAAc;EAAd;EAAA,eAAc;EAAd,uBAAc;EAAd,kCAAc;EAAd,oBAAc;EAAd,uBAAc;EAAd,oBAAc;EAAd;AAAc;EAAd;;;;EAAA,aAAc;EAAd,YAAc;EAAd,gBAAc;EAAd,mBAAc;EAAd,WAAc;EAAd,uBAAc;EAAd,kBAAc;EAAd,yDAAc;EAAd,mBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,sBAAc;EAAd,gBAAc;EAAd,oBAAc;EAAd;AAAc;EAAd;;;;EAAA,YAAc;EAAd,WAAc;EAAd;AAAc;EAAd;EAAA,aAAc;EAAd,YAAc;EAAd,gBAAc;EAAd,mBAAc;EAAd,WAAc;EAAd,uBAAc;EAAd,kBAAc;EAAd,yDAAc;EAAd,mBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,sBAAc;EAAd,gBAAc;EAAd,oBAAc;EAAd;AAAc;EAAd;EAAA,YAAc;EAAd,WAAc;EAAd;AAAc;EAAd;EAAA,kBAAc;EAAd;AAAc;EAAd;EAAA,aAAc;EAAd,YAAc;EAAd,gBAAc;EAAd,mBAAc;EAAd,WAAc;EAAd,uBAAc;EAAd,kBAAc;EAAd,yDAAc;EAAd,mBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,sBAAc;EAAd,gBAAc;EAAd,oBAAc;EAAd;AAAc;EAAd;EAAA,YAAc;EAAd,WAAc;EAAd;AAAc;EAAd;EAAA,kBAAc;EAAd;AAAc;EAAd;EAAA,aAAc;EAAd,YAAc;EAAd,gBAAc;EAAd,mBAAc;EAAd,WAAc;EAAd,uBAAc;EAAd,kBAAc;EAAd,yDAAc;EAAd,mBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,sBAAc;EAAd,gBAAc;EAAd,oBAAc;EAAd;AAAc;EAAd;EAAA,YAAc;EAAd,WAAc;EAAd;AAAc;EAAd;EAAA,kBAAc;EAAd;AAAc;;AAAd;EAAA,wBAAc;EAAd,wBAAc;EAAd,mBAAc;EAAd,mBAAc;EAAd,cAAc;EAAd,cAAc;EAAd,cAAc;EAAd,eAAc;EAAd,eAAc;EAAd,aAAc;EAAd,aAAc;EAAd,kBAAc;EAAd,sCAAc;EAAd,8BAAc;EAAd,6BAAc;EAAd,4BAAc;EAAd,eAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,kBAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,sCAAc;EAAd,kCAAc;EAAd,2BAAc;EAAd,sBAAc;EAAd,8BAAc;EAAd,YAAc;EAAd,kBAAc;EAAd,gBAAc;EAAd,iBAAc;EAAd,kBAAc;EAAd,cAAc;EAAd,gBAAc;EAAd,aAAc;EAAd,mBAAc;EAAd,qBAAc;EAAd,2BAAc;EAAd,yBAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,yBAAc;EAAd;AAAc;;AAAd;EAAA,wBAAc;EAAd,wBAAc;EAAd,mBAAc;EAAd,mBAAc;EAAd,cAAc;EAAd,cAAc;EAAd,cAAc;EAAd,eAAc;EAAd,eAAc;EAAd,aAAc;EAAd,aAAc;EAAd,kBAAc;EAAd,sCAAc;EAAd,8BAAc;EAAd,6BAAc;EAAd,4BAAc;EAAd,eAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,kBAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,sCAAc;EAAd,kCAAc;EAAd,2BAAc;EAAd,sBAAc;EAAd,8BAAc;EAAd,YAAc;EAAd,kBAAc;EAAd,gBAAc;EAAd,iBAAc;EAAd,kBAAc;EAAd,cAAc;EAAd,gBAAc;EAAd,aAAc;EAAd,mBAAc;EAAd,qBAAc;EAAd,2BAAc;EAAd,yBAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,yBAAc;EAAd;AAAc;AACd;EAAA;AAAoB;AAApB;;EAAA;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;AAAA;AA+IlB,eAAe;AAEb;EAAA,oBAA4F;EAA5F;AAA4F;AAA5F;EAAA,oBAA4F;EAA5F;AAA4F;AAA5F;EAAA,oBAA4F;EAA5F;AAA4F;AAA5F;EAAA,oBAA4F;EAA5F;AAA4F;AAI5F;;EAAA,oBAA6M;EAA7M,mBAA6M;EAA7M,uBAA6M;EAA7M,WAA6M;EAA7M,uBAA6M;EAA7M,iBAA6M;EAA7M,yBAA6M;EAA7M,kBAA6M;EAA7M,uDAA6M;EAA7M,mBAA6M;EAA7M,sBAA6M;EAA7M,kBAA6M;EAA7M,mBAA6M;EAA7M,kBAA6M;EAA7M,iBAA6M;EAA7M,gBAA6M;EAA7M,oBAA6M;EAA7M,gDAA6M;EAA7M,0CAA6M;EAA7M,uDAA6M;EAA7M;AAA6M;AAA7M;;EAAA,mBAA6M;EAA7M,kBAA6M;EAA7M;AAA6M;AAI7M;;EAAA,YAAyB;EAAzB,WAAyB;EAAzB;AAAyB;AAGzB;EAAA,qCAA6F;EAA7F,oBAA6F;EAA7F;AAA6F;AAA7F;EAAA;AAA6F;AAA7F;EAAA,kBAA6F;EAA7F,sDAA6F;EAA7F,oBAA6F;EAA7F;AAA6F;AAG7F;EAAA,YAA+C;EAA/C,WAA+C;EAA/C;AAA+C;AAA/C;EAAA;AAA+C;AAGjD,UAAU;AAER;EAAA,kBAAyN;EAAzN;AAAyN;AAAzN;EAAA,kBAAyN;EAAzN;AAAyN;AAAzN,kBAAA,6EAAyN,EAAzN,aAAyN,EAAzN,mBAAyN,EAAzN,uBAAyN,EAAzN,WAAyN,EAAzN,uBAAyN,EAAzN,iBAAyN,EAAzN,yBAAyN,EAAzN,mBAAyN,EAAzN,sBAAyN,EAAzN,kBAAyN,EAAzN,mBAAyN,EAAzN,kBAAyN,EAAzN,iBAAyN,EAAzN,gBAAyN,EAAzN,oBAAyN,EAAzN,0CAAyN,EAAzN,+EAAyN,EAAzN,mGAAyN,EAAzN,uGAAyN,EAAzN,8BAAyN,EAAzN,uQAAyN;EAAA;AAAzN;EAAA;AAAyN;AAAzN;EAAA,oBAAyN;EAAzN;AAAyN;AAAzN;EAAA;AAAyN;AAGzN;EAAA,YAA2B;EAA3B,WAA2B;EAA3B;AAA2B;AAG3B;EAAA;AAAgB;AAGhB;EAAA,aAAiE;EAAjE,WAAiE;EAAjE,mBAAiE;EAAjE,uBAAiE;EAAjE,WAAiE;EAAjE,oCAAiE;EAAjE;AAAiE;AAGjE;EAAA,YAA4C;EAA5C,WAA4C;EAA5C;AAA4C;AAA5C;EAAA;AAA4C;AAG5C;EAAA,oBAA+D;EAA/D,uBAA+D;EAA/D,gBAA+D;EAA/D,yBAA+D;EAA/D,oBAA+D;EAA/D;AAA+D;AAA/D;EAAA,oBAA+D;EAA/D;AAA+D;AAG/D;EAAA,kBAAiF;EAAjF,UAAiF;EAAjF,WAAiF;EAAjF,SAAiF;EAAjF,iBAAiF;EAAjF,kBAAiF;EAAjF,aAAiF;EAAjF,YAAiF;EAAjF,mBAAiF;EAAjF,gBAAiF;EAAjF;AAAiF;AAGjF;EAAA,kBAAmK;EAAnK;AAAmK;AAAnK;EAAA,kBAAmK;EAAnK;AAAmK;AAAnK,SAAA,6EAAmK,EAAnK,YAAmK,EAAnK,iBAAmK,EAAnK,WAAmK,EAAnK,cAAmK,EAAnK,YAAmK,EAAnK,gBAAmK,EAAnK,wBAAmK,EAAnK,gBAAmK,EAAnK,uBAAmK,EAAnK,sBAAmK,EAAnK,2CAAmK,EAAnK,0DAAmK,EAAnK,uGAAmK;EAAA;AAGnK;EAAA;AAAW;AAGX;EAAA,kBAAkE;EAAlE,aAAkE;EAAlE,YAAkE;EAAlE,WAAkE;EAAlE,wBAAkE;EAAlE;AAAkE;AAIlE;;EAAA,eAAqH;EAArH,aAAqH;EAArH,WAAqH;EAArH,mBAAqH;EAArH,uBAAqH;EAArH,uBAAqH;EAArH;AAAqH;AAArH;;EAAA;AAAqH;AAArH;;EAAA;AAAqH;AAGrH;EAAA,aAAoE;EAApE,YAAoE;EAApE,mBAAoE;EAApE,uBAAoE;EAApE,gBAAoE;EAApE;AAAoE;AAIpE;;EAAA,YAAiD;EAAjD,WAAiD;EAAjD;AAAiD;AAAjD;;EAAA;AAAiD;AAGjD;EAAA,oBAAwE;EAAxE,qBAAwE;EAAxE,kBAAwE;EAAxE,iBAAwE;EAAxE,eAAwE;EAAxE,oBAAwE;EAAxE;AAAwE;AAAxE;EAAA,oBAAwE;EAAxE;AAAwE;AAGxE;EAAA,oBAAwD;EAAxD,uBAAwD;EAAxD;AAAwD;AAAxD;EAAA;AAAwD;AAGxD;EAAA,kBAA8F;EAA9F,aAA8F;EAA9F,YAA8F;EAA9F,WAA8F;EAA9F,wJAA8F;EAA9F,wDAA8F;EAA9F;AAA8F;AAA9F;EAAA;AAA8F;AAA9F;EAAA;AAA8F;AAI9F;;EAAA,aAAoD;EAApD,WAAoD;EAApD,mBAAoD;EAApD,uBAAoD;EAApD;AAAoD;AAIpD;;EAAA,YAAiD;EAAjD,WAAiD;EAAjD;AAAiD;AAAjD;;EAAA;AAAiD;AAGjD;EAAA;AAAyC;AAAzC;EAAA;AAAyC;AAGzC;EAAA,aAA0C;EAA1C,YAA0C;EAA1C,sBAA0C;EAA1C;AAA0C;AAG1C;EAAA;AAAkB;AAnOtB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,iBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;;EAAA;IAAA;EAAmB;AAAA;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,uBAAmB;EAAnB,+DAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,kBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,mBAAmB;EAAnB;AAAmB;AAAnB;EAAA,kBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,sBAAmB;EAAnB,8BAAmB;EAAnB;AAAmB;AAAnB;EAAA,8BAAmB;EAAnB;AAAmB;AAAnB;EAAA,2GAAmB;EAAnB,yGAAmB;EAAnB;AAAmB;;AAEnB;EACE,mFAA6E;EAC7E,sBAAsB;EACtB,4BAA4B;AAC9B;;AAEA;EACE,gFAA+E;EAC/E,sBAAsB;EACtB,4BAA4B;AAC9B;;AAdA;EAAA;CCAA;;ADAA;EAAA;CCAA;;ADAA;EAAA,+BCAA;EDAA;CCAA;;ADAA;EAAA,4GCAA;EDAA,0GCAA;EDAA;CCAA;;ADAA;EAAA,mBCAA;EDAA;CCAA;;ADAA;EAAA,mBCAA;EDAA;CCAA;;ADAA;EAAA;CCAA;;ADAA;EAAA;CCAA;;ADAA;EAAA,qBCAA;EDAA;CCAA;;ADAA;EAAA,qBCAA;EDAA;CCAA;;ADAA;EAAA;CCAA","sourcesContent":["@tailwind base;\n@tailwind components;\n@tailwind utilities;\n\n.bg-theme {\n  background: rgb(181, 214, 243) url('../../assets/images/bg.jpg') fixed center;\n  background-size: cover;\n  background-repeat: no-repeat;\n}\n\n.bg-theme-dark {\n  background: rgb(10, 17, 23) url('../../assets/images/bg-dark.png') fixed center;\n  background-size: cover;\n  background-repeat: no-repeat;\n}\n\n@layer base {\n  * {\n    scrollbar-width: none;\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n    scroll-behavior: auto !important;\n  }\n\n  body {\n    color-scheme: light dark;\n    font-family: system-ui, sans-serif;\n    font-weight: 300;\n    font-size: 13px;\n    line-height: 1.7;\n    @apply relative h-[600px] w-[348px] overflow-hidden bg-gray-200 text-gray-800 dark:bg-[#191919] dark:text-gray-200;\n  }\n\n  [type='text'],\n  [type='password'],\n  [type='number'],\n  [multiple],\n  textarea,\n  select {\n    @apply w-full cursor-pointer rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 disabled:cursor-not-allowed disabled:bg-black/10 dark:disabled:bg-[#4A4A4A]/80;\n  }\n  select {\n    @apply font-normal;\n  }\n  [type='checkbox'],\n  [type='radio'] {\n    @apply h-4 w-4 rounded-full border-gray-300 bg-white/20 text-indigo-600 focus:ring-1 focus:ring-indigo-500 focus:ring-offset-0;\n  }\n\n  .bg-card {\n    @apply bg-white dark:bg-[#242526]; /* to add blur, @apply bg-white/40 backdrop-blur-md dark:bg-[#242526]/40; } */\n  }\n  .required-asterisk {\n    @apply after:ml-0.5 after:text-red-500 after:content-['*'];\n  }\n\n  /* main layout (full popup) */\n  .box-container {\n    @apply mx-auto flex h-full w-full flex-col items-stretch;\n  }\n  .box-container.right-open .box1-content {\n    @apply pointer-events-none flex-[0] opacity-0;\n  }\n  .box-container.right-open .box1-side {\n    @apply flex-[0] opacity-0;\n  }\n  .box-container.right-open .box2-side {\n    @apply flex-[1] opacity-100;\n  }\n  .box-container.right-open .box2-content {\n    @apply flex-[5] p-4 opacity-100;\n  }\n  .box1-content,\n  .box1-side,\n  .box2-content,\n  .box2-side {\n    @apply overflow-hidden transition-all duration-300 ease-in-out;\n  }\n  .box1-side,\n  .box2-side {\n    @apply flex items-center justify-center;\n  }\n  .box1-content {\n    @apply flex-[5.4] opacity-100;\n  }\n  .box1-side {\n    @apply bg-card inset-y-1 mx-4 mb-4 h-full flex-[0.6] justify-start rounded-md shadow-[0_3px_2px_-1px_rgba(0,0,0,0.1)];\n  }\n  .box2-side {\n    @apply flex-[0] opacity-0;\n  }\n  .box2-content {\n    @apply bg-card bottom-0 left-0 right-0 mb-0 flex flex-[0] flex-col justify-center space-y-4 opacity-0 shadow-sm;\n  }\n\n  /* Form */\n  .form-textbox {\n    @apply flex flex-col;\n  }\n  .form-textbox > label,\n  .form-textbox-label {\n    @apply mb-1 block text-sm font-medium text-gray-700 dark:text-gray-200;\n  }\n  .form-textbox > div {\n    @apply relative w-full;\n  }\n  .form-textbox > div > div {\n    @apply absolute left-0 top-0 flex h-full w-10 items-center justify-center border-r-[1px] border-gray-300 dark:border-gray-300/10;\n  }\n  .form-textbox > div > div > svg {\n    @apply h-4 w-4 fill-current dark:fill-slate-200;\n  }\n  .form-textbox > div > input {\n    @apply w-full border-gray-300 pl-12 text-xs placeholder-gray-400 disabled:shadow-none dark:border-gray-300/10 dark:bg-white/5;\n  }\n\n  /* Message */\n  .action {\n    @apply cursor-pointer rounded-sm bg-black/10 py-1 px-2;\n  }\n  .info,\n  .warning,\n  .error,\n  .success {\n    @apply flex h-full max-h-8 items-center gap-2 rounded-md bg-slate-400 py-2 px-3 font-normal text-black;\n  }\n  .info > svg,\n  .warning > svg,\n  .error > svg,\n  .success > svg {\n    @apply h-4 w-4 fill-current;\n  }\n  .warning {\n    @apply info bg-yellow-300;\n  }\n  .error {\n    @apply info bg-red-300;\n  }\n  .success {\n    @apply info bg-green-300;\n  }\n}\n\n@layer components {\n  /* Components */\n  .link-text {\n    @apply text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-500;\n  }\n  .svg-btn-primary,\n  .svg-btn-secondary {\n    @apply inline-flex items-center justify-center gap-2 rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-xs font-medium text-white shadow-sm disabled:cursor-not-allowed disabled:bg-indigo-300;\n  }\n  .svg-btn-primary > svg,\n  .svg-btn-secondary > svg {\n    @apply h-4 w-4 fill-white;\n  }\n  .svg-btn-secondary {\n    @apply bg-gray-600/40 text-gray-900 hover:bg-gray-600/30 dark:bg-slate-700 dark:text-gray-300;\n  }\n  .svg-btn-secondary > svg {\n    @apply h-4 w-4 fill-gray-900 dark:fill-gray-300;\n  }\n\n  /* panel */\n  .box-toggle-btn {\n    @apply bg-card flex items-center justify-center gap-2 rounded-md border border-transparent py-2 px-4 text-xs font-medium text-black  shadow-lg backdrop-blur-md hover:bg-white/40 dark:text-white  hover:dark:bg-black/40;\n  }\n  .box-toggle-btn > svg {\n    @apply h-4 w-4 fill-current;\n  }\n  .box-toggle-btn > span {\n    @apply uppercase;\n  }\n  .box-toggle-btn-panel-item {\n    @apply flex w-full items-center justify-center gap-2 rounded-b-md;\n  }\n  .box-toggle-btn-panel-item > svg {\n    @apply h-4 w-4 fill-black dark:fill-gray-900;\n  }\n  .box-toggle-btn-panel-item > span {\n    @apply py-1 font-normal uppercase text-black dark:text-gray-900;\n  }\n  .panel-container {\n    @apply absolute inset-x-4 top-4 mx-auto flex flex-1 flex-row overflow-hidden pb-2;\n  }\n  .panel {\n    @apply bg-card h-full max-h-[490px]  w-full flex-shrink-0 flex-grow-0 basis-full snap-start overflow-y-auto rounded-md pb-2 shadow-[0_3px_2px_-1px_rgba(0,0,0,0.1)];\n  }\n  .panel:first-of-type {\n    @apply pb-0;\n  }\n  .panel-header {\n    @apply relative flex h-[40px] w-full border-b border-b-gray-400/40;\n  }\n  .panel-header-start,\n  .panel-header-end {\n    @apply m-1 flex w-[40px] items-center justify-center rounded-md font-mono hover:bg-gray-400/30 dark:hover:bg-white/30;\n  }\n  .panel-header-middle {\n    @apply flex flex-1 items-center justify-center font-medium uppercase;\n  }\n  .panel-header-start > svg,\n  .panel-header-end > svg {\n    @apply h-4 w-4 fill-slate-600 dark:fill-slate-200;\n  }\n  .panel-group-label {\n    @apply mx-3 mt-2 text-right text-[11px] text-gray-600 dark:text-gray-400;\n  }\n  .panel-group-divider {\n    @apply my-0.5 border-gray-400/40 dark:border-gray-200/40;\n  }\n  .panel-group-item {\n    @apply relative flex h-[32px] w-full transition hover:bg-gray-400/30 dark:hover:bg-gray-400/40;\n  }\n  .panel-group-item-start,\n  .panel-group-item-end {\n    @apply flex w-[40px] items-center justify-center p-1;\n  }\n  .panel-group-item-start > svg,\n  .panel-group-item-end > svg {\n    @apply h-4 w-4 fill-slate-900 dark:fill-slate-200;\n  }\n  .panel-group-item-end > svg {\n    @apply fill-slate-600 dark:fill-slate-400;\n  }\n  .panel-group-item-middle {\n    @apply flex flex-1 flex-col justify-center;\n  }\n  .panel-group-item-middle > h2 {\n    @apply font-normal;\n  }\n  .panel-footer {\n    @apply relative mt-4 text-center text-[11px];\n  }\n  .panel-footer > a {\n    @apply text-indigo-500 dark:text-indigo-300;\n  }\n}\n",null],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/***/ ((module) => {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/getUrl.js":
/*!********************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/getUrl.js ***!
  \********************************************************/
/***/ ((module) => {



module.exports = function (url, options) {
  if (!options) {
    options = {};
  }
  if (!url) {
    return url;
  }
  url = String(url.__esModule ? url.default : url);

  // If url is already wrapped in quotes, remove them
  if (/^['"].*['"]$/.test(url)) {
    url = url.slice(1, -1);
  }
  if (options.hash) {
    url += options.hash;
  }

  // Should url be wrapped?
  // See https://drafts.csswg.org/css-values-3/#urls
  if (/["'() \t\n]|(%20)/.test(url) || options.needQuotes) {
    return "\"".concat(url.replace(/"/g, '\\"').replace(/\n/g, "\\n"), "\"");
  }
  return url;
};

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/sourceMaps.js":
/*!************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \************************************************************/
/***/ ((module) => {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ }),

/***/ "./src/pages/Popup/style.css":
/*!***********************************!*\
  !*** ./src/pages/Popup/style.css ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_0_use_1_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[0].use[1]!../../../node_modules/postcss-loader/dist/cjs.js!./style.css */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[0].use[1]!./node_modules/postcss-loader/dist/cjs.js!./src/pages/Popup/style.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_0_use_1_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_0_use_1_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_0_use_1_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_0_use_1_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
/***/ ((module) => {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js":
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
/***/ ((module) => {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js":
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js":
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js":
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ }),

/***/ "./src/services/crypto.ts":
/*!********************************!*\
  !*** ./src/services/crypto.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decrypt: () => (/* binding */ decrypt),
/* harmony export */   encrypt: () => (/* binding */ encrypt)
/* harmony export */ });
const buffToBase64 = (buff) => window.btoa(String.fromCharCode.apply(null, buff));
const base64ToBuff = (b64) => Uint8Array.from(window.atob(b64), (c) => c.charCodeAt(0));
const enc = new TextEncoder();
const dec = new TextDecoder();
const byteLen = { salt: 16, iv: 12 };
/**
 * Given a password,
 * @returns a key from the password.
 */
const getKeyFromPassword = (password) => {
    return window.crypto.subtle.importKey('raw', enc.encode(password), { name: 'PBKDF2' }, false, [
        'deriveBits',
        'deriveKey'
    ]);
};
/**
 * Given a key from a password and a salt,
 * @returns a key derived from the password and salt.
 */
const getKey = (keyFromPassword, salt) => {
    return window.crypto.subtle.deriveKey({
        name: 'PBKDF2',
        salt,
        iterations: 100000,
        hash: 'SHA-256'
    }, keyFromPassword, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
};
const encrypt = async (secret, password) => {
    const keyFromPassword = await getKeyFromPassword(password);
    const salt = window.crypto.getRandomValues(new Uint8Array(byteLen.salt));
    const key = await getKey(keyFromPassword, salt);
    const iv = window.crypto.getRandomValues(new Uint8Array(byteLen.iv));
    const encoded = enc.encode(secret);
    const cipherText = await window.crypto.subtle.encrypt({
        name: 'AES-GCM',
        iv
    }, key, encoded);
    const cipher = new Uint8Array(cipherText);
    const buffer = new Uint8Array(salt.byteLength + iv.byteLength + cipher.byteLength);
    buffer.set(salt, 0);
    buffer.set(iv, salt.byteLength);
    buffer.set(cipher, salt.byteLength + iv.byteLength);
    const encrypted = buffToBase64(buffer);
    return encrypted;
};
/**
 * Derive a key from a password supplied by the user,
 * use the key to decrypt the cipherText.
 * if the cipherText was decrypted successfully,
 *   return the decrypted value.
 * if there was an error decrypting,
 *   throw an error message.
 *
 * @param {string} encrypted encrypted base64 string
 * @param {string} password password for the encrypted data
 * @returns secret text set by encrypt() function or an error message
 */
const decrypt = async (encrypted, password) => {
    const encryptedBuffer = base64ToBuff(encrypted);
    const salt = encryptedBuffer.slice(0, byteLen.salt);
    const iv = encryptedBuffer.slice(byteLen.salt, byteLen.salt + byteLen.iv);
    const cipherText = encryptedBuffer.slice(byteLen.salt + byteLen.iv);
    const keyFromPassword = await getKeyFromPassword(password);
    const key = await getKey(keyFromPassword, salt);
    try {
        const decryptedEncoded = await window.crypto.subtle.decrypt({
            name: 'AES-GCM',
            iv
        }, key, cipherText);
        const decrypted = dec.decode(decryptedEncoded);
        return decrypted;
    }
    catch (e) {
        throw new Error(e);
    }
};



/***/ }),

/***/ "./src/services/erp.ts":
/*!*****************************!*\
  !*** ./src/services/erp.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
class ERP {
    onGetSecurityQues;
    isLoggedIn;
    logout;
    authRequest;
    getSecurityQues;
    constructor(roll) {
        let username = roll || '';
        let password = '';
        const securityQuestions = {};
        Object.defineProperties(this, {
            username: {
                get() {
                    return username;
                }
            },
            password: {
                set(pass) {
                    password = pass;
                }
            },
            securityQuestions: {
                set(ques) {
                    if (ques instanceof Object) {
                        for (const q in ques) {
                            if (Object.keys(securityQuestions).includes(q)) {
                                securityQuestions[q] = ques[q];
                            }
                        }
                    }
                },
                get() {
                    return securityQuestions;
                }
            },
            data: {
                get() {
                    return { username, password, securityQuestions };
                }
            },
            load: {
                value(user) {
                    const { username: id, password: pass, securityQuestions: ques } = user;
                    if (id) {
                        username = id;
                    }
                    if (pass) {
                        password = pass;
                    }
                    if (ques) {
                        for (const q in ques) {
                            if (Object.prototype.hasOwnProperty.call(ques, q)) {
                                securityQuestions[q] = ques[q];
                            }
                        }
                    }
                    console.info('user loaded:', {
                        username,
                        password,
                        securityQuestions
                    });
                }
            },
            getAllSecurityQues: {
                async value() {
                    if (Object.keys(securityQuestions).length >= 3) {
                        return Object.keys(securityQuestions);
                    }
                    let question;
                    try {
                        question = await this.getSecurityQues(username);
                    }
                    catch (error) {
                        console.error(error);
                        return false;
                    }
                    if (question === 'FALSE') {
                        console.error(new Error('Invalid username'));
                        return false;
                    }
                    if (Object.keys(securityQuestions).length < 3) {
                        if (!Object.keys(securityQuestions).includes(question)) {
                            this.onGetSecurityQues(question);
                        }
                        securityQuestions[question] = '';
                        await this.getAllSecurityQues();
                    }
                    return Object.keys(securityQuestions);
                }
            },
            login: {
                async value(options) {
                    let { requestedUrl } = options || {};
                    const { sessionToken } = options || {};
                    /* Set a default target url */
                    if (!requestedUrl) {
                        requestedUrl = 'https://erp.iitkgp.ac.in/IIT_ERP3/';
                    }
                    /* Check login status */
                    const isLoggedIn = await this.isLoggedIn(requestedUrl);
                    console.log({ isLoggedIn });
                    if (isLoggedIn) {
                        return requestedUrl;
                    }
                    /* Get security question */
                    let question;
                    try {
                        question = await this.getSecurityQues(username);
                    }
                    catch (error) {
                        console.error(error);
                        return false;
                    }
                    console.log('authSecurityQues:', question);
                    /* Pick answer to the security question */
                    const answer = securityQuestions[question] || '';
                    /* Request for login */
                    const redirectedUrl = await this.authRequest({
                        username,
                        password,
                        answer,
                        sessionToken,
                        requestedUrl
                    });
                    return redirectedUrl;
                }
            }
        });
        this.onGetSecurityQues = function (question) {
            console.log({ question });
        };
        this.logout = async function () {
            const url = 'https://erp.iitkgp.ac.in/IIT_ERP3/logout.htm';
            const response = (await processRequest(new Request(url)));
            if (response.redirected) {
                return response.url;
            }
            return Promise.reject(new Error('Logout failed'));
        };
        this.isLoggedIn = async function (requestedUrl) {
            if (!requestedUrl) {
                requestedUrl = 'https://erp.iitkgp.ac.in/IIT_ERP3/';
            }
            const res = (await processRequest(new Request(requestedUrl)));
            if (!res.redirected) {
                return true;
            }
            return false;
        };
        this.authRequest = async function (authCred) {
            const { username, password, answer, sessionToken, requestedUrl } = authCred;
            if (!username || !password || !answer) {
                throw new Error('Username or Password or Answer is missing!');
            }
            let body = `user_id=${username}&password=${password}&answer=${answer}`;
            if (sessionToken) {
                body += `&sessionToken=${sessionToken}`;
            }
            if (requestedUrl) {
                body += `&requestedUrl=${requestedUrl}`;
            }
            else {
                body += '&requestedUrl=https://erp.iitkgp.ac.in/IIT_ERP3/';
            }
            const url = 'https://erp.iitkgp.ac.in/SSOAdministration/auth.htm';
            const method = 'POST';
            console.log('req_body:', body);
            const response = (await processRequest(new Request(url, { method, body })));
            if (response.redirected) {
                return response.url;
            }
            return Promise.reject(new Error('Invalid credentials'));
        };
        this.getSecurityQues = async function (iitkgpLoginId) {
            if (!iitkgpLoginId) {
                throw new Error('Please provide login id');
            }
            const url = 'https://erp.iitkgp.ac.in/SSOAdministration/getSecurityQues.htm';
            const method = 'POST';
            const body = `user_id=${iitkgpLoginId}`;
            const response = await processRequest(new Request(url, { method, body }));
            return response ? response.text() : 'FALSE';
        };
        const processRequest = async function (request) {
            let ts = Date.now();
            const { url, method } = request;
            const { pathname, search } = new URL(url);
            const response = await nativeFetch(request);
            ts -= Date.now();
            console.log(`${method + response.status}: ${-ts}ms ${pathname + search}`);
            if (response.ok && response.status === 200) {
                return response;
            }
            return Promise.reject(new Error('Api returned status: ' + response.status));
        };
        const nativeFetch = function (request) {
            if (request.method === 'POST') {
                request.headers.set('Content-type', 'application/x-www-form-urlencoded');
            }
            return fetch(request);
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ERP);


/***/ }),

/***/ "./src/utils/displayMessageOnPopup.ts":
/*!********************************************!*\
  !*** ./src/utils/displayMessageOnPopup.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const displayMessageOnPopup = (message, type = 'info', actions = false, onClickYes = () => { }, onclickCancel = () => { }) => {
    const log = document.getElementById('log');
    const logIcon = document.getElementById('logIcon');
    const logText = document.getElementById('logText');
    const status = document.getElementById('status');
    const statusIcon = document.getElementById('statusIcon');
    const statusText = document.getElementById('statusText');
    let iconId;
    log.className = type;
    status.style.backgroundColor = 'yellow';
    switch (type) {
        case 'warning':
            iconId = 'warning';
            break;
        case 'error':
            iconId = 'cross';
            break;
        case 'success':
            iconId = 'check';
            status.style.backgroundColor = 'lightgreen';
            break;
        default:
            iconId = 'info';
            break;
    }
    logText.textContent = message;
    logIcon.setAttribute('href', chrome.runtime.getURL(`/assets/sprite.svg#${iconId || 'info'}`));
    statusText.textContent = message;
    statusIcon.setAttribute('href', chrome.runtime.getURL(`/assets/sprite.svg#${iconId || 'info'}`));
    if (actions) {
        document.querySelectorAll('.action').forEach((el) => el.remove());
        const actionBtnYes = document.createElement('div');
        actionBtnYes.className = 'action';
        actionBtnYes.textContent = 'Yes';
        const actionBtnCancel = document.createElement('div');
        actionBtnCancel.className = 'action';
        actionBtnCancel.textContent = 'Cancel';
        log.appendChild(actionBtnYes);
        log.appendChild(actionBtnCancel);
        actionBtnYes.onclick = () => {
            log.removeChild(actionBtnYes);
            log.removeChild(actionBtnCancel);
            onClickYes();
        };
        actionBtnCancel.onclick = () => {
            log.removeChild(actionBtnYes);
            log.removeChild(actionBtnCancel);
            onclickCancel();
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (displayMessageOnPopup);


/***/ }),

/***/ "data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3ccircle cx=%278%27 cy=%278%27 r=%273%27/%3e%3c/svg%3e":
/*!***************************************************************************************************************************************************************************!*\
  !*** data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3ccircle cx=%278%27 cy=%278%27 r=%273%27/%3e%3c/svg%3e ***!
  \***************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3ccircle cx=%278%27 cy=%278%27 r=%273%27/%3e%3c/svg%3e";

/***/ }),

/***/ "data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3cpath d=%27M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z%27/%3e%3c/svg%3e":
/*!*********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3cpath d=%27M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z%27/%3e%3c/svg%3e ***!
  \*********************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27white%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3cpath d=%27M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z%27/%3e%3c/svg%3e";

/***/ }),

/***/ "data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 16 16%27%3e%3cpath stroke=%27white%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%272%27 d=%27M4 8h8%27/%3e%3c/svg%3e":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 16 16%27%3e%3cpath stroke=%27white%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%272%27 d=%27M4 8h8%27/%3e%3c/svg%3e ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 16 16%27%3e%3cpath stroke=%27white%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%272%27 d=%27M4 8h8%27/%3e%3c/svg%3e";

/***/ }),

/***/ "data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 20 20%27%3e%3cpath stroke=%27%236b7280%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%271.5%27 d=%27M6 8l4 4 4-4%27/%3e%3c/svg%3e":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 20 20%27%3e%3cpath stroke=%27%236b7280%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%271.5%27 d=%27M6 8l4 4 4-4%27/%3e%3c/svg%3e ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 fill=%27none%27 viewBox=%270 0 20 20%27%3e%3cpath stroke=%27%236b7280%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%271.5%27 d=%27M6 8l4 4 4-4%27/%3e%3c/svg%3e";

/***/ }),

/***/ "./src/assets/images/bg-dark.png":
/*!***************************************!*\
  !*** ./src/assets/images/bg-dark.png ***!
  \***************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/images/bg-dark.png";

/***/ }),

/***/ "./src/assets/images/bg.jpg":
/*!**********************************!*\
  !*** ./src/assets/images/bg.jpg ***!
  \**********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/images/bg.jpg";

/***/ }),

/***/ "./src/assets/images/iitkgp-logo.svg":
/*!*******************************************!*\
  !*** ./src/assets/images/iitkgp-logo.svg ***!
  \*******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "assets/images/iitkgp-logo.svg";

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src;
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) {
/******/ 					var i = scripts.length - 1;
/******/ 					while (i > -1 && !scriptUrl) scriptUrl = scripts[i--].src;
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl + "../../";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		__webpack_require__.b = document.baseURI || self.location.href;
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"pages/Popup/index": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// no jsonp function
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!**********************************!*\
  !*** ./src/pages/Popup/index.ts ***!
  \**********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var pages_Popup_style_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! pages/Popup/style.css */ "./src/pages/Popup/style.css");
/* harmony import */ var services_crypto__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! services/crypto */ "./src/services/crypto.ts");
/* harmony import */ var services_erp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! services/erp */ "./src/services/erp.ts");
/* harmony import */ var utils_displayMessageOnPopup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! utils/displayMessageOnPopup */ "./src/utils/displayMessageOnPopup.ts");




/* Initialize Theme */
chrome.storage.local.get(['theme', 'bg', 'landingPage', 'useAltPINDialog'], (result) => {
    const useAltPINDialogInput = document.getElementById('useAltPINDialog');
    useAltPINDialogInput.checked = result.useAltPINDialog || false;
    useAltPINDialogInput.onchange = (ev) => {
        chrome.storage.local.set({
            useAltPINDialog: ev.target.checked
        });
    };
    const landingPageSelect = document.getElementById('landing_page');
    const themeSelect = document.getElementById('theme_select');
    const themeBg = document.getElementById('theme-bg');
    let isDark = false;
    let isBgEnabled = false;
    if (result.theme === 'dark' || (!('theme' in result) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        isDark = true;
        document.documentElement.classList.add('dark');
        themeSelect.value = 'dark';
    }
    else {
        document.documentElement.classList.remove('dark');
        themeSelect.value = 'light';
    }
    if (result.bg === 'yes') {
        isBgEnabled = true;
        if (isDark) {
            document.body.classList.toggle('bg-theme-dark');
        }
        else {
            document.body.classList.toggle('bg-theme');
        }
        themeBg.checked = true;
    }
    else {
        themeBg.checked = false;
    }
    themeBg.onchange = (ev) => {
        if (ev.target.checked) {
            isBgEnabled = true;
            if (isDark) {
                document.body.classList.toggle('bg-theme-dark');
            }
            else {
                document.body.classList.toggle('bg-theme');
            }
        }
        else {
            isBgEnabled = false;
            document.body.classList.remove('bg-theme');
            document.body.classList.remove('bg-theme-dark');
        }
        chrome.storage.local.set({
            bg: ev.target.checked ? 'yes' : 'no'
        });
    };
    themeSelect.onchange = (ev) => {
        isDark = ev.target.value === 'dark';
        if (isBgEnabled) {
            document.body.classList.remove('bg-theme');
            document.body.classList.remove('bg-theme-dark');
            if (isDark) {
                document.body.classList.toggle('bg-theme-dark');
            }
            else {
                document.body.classList.toggle('bg-theme');
            }
        }
        document.documentElement.classList.toggle('dark');
        chrome.storage.local.set({ theme: ev.target.value });
    };
    if (result.landingPage) {
        landingPageSelect.value = result.landingPage;
    }
    landingPageSelect.onchange = (ev) => {
        chrome.storage.local.set({ landingPage: ev.target.value });
    };
});
/* Initialize Form */
window.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get({
        authCredentials: {
            requirePin: false,
            autoLogin: true,
            username: '',
            password: '',
            q1: '',
            q2: '',
            q3: '',
            a1: '',
            a2: '',
            a3: ''
        }
    }, (result) => {
        const authCredentials = result.authCredentials;
        console.log(authCredentials);
        const form = document.getElementById('form_add_user');
        const formResetBtn = document.getElementById('reset_form');
        const formSubmitBtn = document.getElementById('submit_form');
        const username = document.getElementById('username');
        const usernameSubmitBtn = document.getElementById('username_submit_button');
        const password = document.getElementById('password');
        const a1 = document.getElementById('question_one');
        const a2 = document.getElementById('question_two');
        const a3 = document.getElementById('question_three');
        const pin = document.getElementById('pin');
        const questions = document.querySelectorAll("input[name='question']");
        const formToggleBtns = document.querySelectorAll('.left-button,.right-button');
        // Extras
        const loader = document.getElementById('loader');
        const container = document.querySelector('.box-container');
        const autoLoginToggleBtn = document.getElementById('autoLogin');
        username.value = authCredentials.username || '';
        password.value = authCredentials.password || '';
        a1.value = authCredentials.a1 || '';
        a2.value = authCredentials.a2 || '';
        a3.value = authCredentials.a3 || '';
        a1.placeholder = authCredentials.q1 || 'Your erp question 1';
        a2.placeholder = authCredentials.q2 || 'Your erp question 2';
        a3.placeholder = authCredentials.q3 || 'Your erp question 3';
        autoLoginToggleBtn.checked = authCredentials.autoLogin;
        if (authCredentials.username === '') {
            (0,utils_displayMessageOnPopup__WEBPACK_IMPORTED_MODULE_3__["default"])('Enter Roll Number');
            username.removeAttribute('disabled');
            usernameSubmitBtn.removeAttribute('disabled');
        }
        else {
            (0,utils_displayMessageOnPopup__WEBPACK_IMPORTED_MODULE_3__["default"])(`You are all set! ${authCredentials.username}`, 'success');
            pin.style.display = 'none';
            const smallText = document.createElement('b');
            smallText.setAttribute('style', 'margin-left: 50px');
            if (authCredentials.requirePin)
                smallText.innerText = 'PIN was set !';
            else
                smallText.innerText = 'PIN was NOT set !';
            pin.after(smallText);
        }
        const emptyFieldExists = authCredentials.username === '' ||
            authCredentials.password === '' ||
            authCredentials.a1 === '' ||
            authCredentials.q1 === 'Your erp question 1' ||
            authCredentials.a2 === '' ||
            authCredentials.q2 === 'Your erp question 2' ||
            authCredentials.a3 === '' ||
            authCredentials.q3 === 'Your erp question 2';
        if (emptyFieldExists) {
            container.classList.toggle('right-open');
        }
        formToggleBtns.forEach((button) => button.addEventListener('click', () => {
            container.classList.toggle('right-open');
        }));
        autoLoginToggleBtn.addEventListener('change', (e) => {
            const target = e.target;
            console.log(`curr ${target.id}:`, authCredentials[target.id]);
            console.log(`set ${target.id} to:`, target.checked);
            authCredentials[target.id] = target.checked;
            chrome.storage.local.set({
                authCredentials: authCredentials
            });
        });
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            loader.style.display = 'flex';
            setTimeout(() => {
                loader.style.display = 'none';
            }, 500);
            if (pin.value) {
                pin.style.display = 'none';
                const smallText = document.createElement('small');
                smallText.setAttribute('style', 'margin-left: 50px');
                smallText.innerText = 'PIN is set!';
                pin.after(smallText);
                const [ans1, ans2, ans3, pass] = await Promise.all([
                    (0,services_crypto__WEBPACK_IMPORTED_MODULE_1__.encrypt)(a1.value, pin.value),
                    (0,services_crypto__WEBPACK_IMPORTED_MODULE_1__.encrypt)(a2.value, pin.value),
                    (0,services_crypto__WEBPACK_IMPORTED_MODULE_1__.encrypt)(a3.value, pin.value),
                    (0,services_crypto__WEBPACK_IMPORTED_MODULE_1__.encrypt)(password.value, pin.value)
                ]);
                const encryptedCred = {
                    autoLogin: authCredentials.autoLogin,
                    username: username.value,
                    q1: a1.placeholder,
                    q2: a2.placeholder,
                    q3: a3.placeholder,
                    requirePin: true,
                    password: pass,
                    a1: ans1,
                    a2: ans2,
                    a3: ans3
                };
                chrome.storage.local.set({ authCredentials: encryptedCred }, () => location.reload());
            }
            else {
                const credentials = {
                    autoLogin: authCredentials.autoLogin,
                    username: username.value,
                    q1: a1.placeholder,
                    q2: a2.placeholder,
                    q3: a3.placeholder,
                    requirePin: false,
                    password: password.value,
                    a1: a1.value,
                    a2: a2.value,
                    a3: a3.value
                };
                chrome.storage.local.set({ authCredentials: credentials }, () => location.reload());
            }
        });
        formResetBtn.addEventListener('click', (e) => {
            e.preventDefault();
            (0,utils_displayMessageOnPopup__WEBPACK_IMPORTED_MODULE_3__["default"])('Are you sure!', 'warning', true, () => {
                console.log('yes');
                document.forms[0].reset();
                chrome.storage.local.remove(['authCredentials'], () => {
                    location.reload();
                });
            }, () => {
                (0,utils_displayMessageOnPopup__WEBPACK_IMPORTED_MODULE_3__["default"])('Cancelled.');
            });
        });
        username.addEventListener('keyup', (e) => {
            e.preventDefault();
            if (username.value.length !== 9) {
                if (username.value.length === 8 || username.value.length === 10) {
                    questions.forEach((q, i) => {
                        q.placeholder = `Your erp question ${i + 1}`;
                        q.value = '';
                        q.disabled = true;
                    });
                    password.value = '';
                    pin.value = '';
                    password.disabled = true;
                    pin.disabled = true;
                }
                return;
            }
        });
        usernameSubmitBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            (0,utils_displayMessageOnPopup__WEBPACK_IMPORTED_MODULE_3__["default"])('Getting questions, wait...');
            const erpUser = new services_erp__WEBPACK_IMPORTED_MODULE_2__["default"](username.value);
            erpUser.getAllSecurityQues().then((res) => {
                if (res === false) {
                    (0,utils_displayMessageOnPopup__WEBPACK_IMPORTED_MODULE_3__["default"])('Invalid RollNo!', 'error');
                }
                else {
                    (0,utils_displayMessageOnPopup__WEBPACK_IMPORTED_MODULE_3__["default"])('Questions fetched!', 'success');
                    password.removeAttribute('disabled');
                    pin.removeAttribute('disabled');
                    formSubmitBtn.removeAttribute('disabled');
                }
            });
            let idx = 0;
            erpUser.onGetSecurityQues = (q) => {
                questions[idx].removeAttribute('disabled');
                questions[idx].placeholder = q;
                idx++;
            };
        });
        setTimeout(() => {
            loader.style.display = 'none';
        }, 500);
    });
});

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvUG9wdXAvaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNnSDtBQUNqQjtBQUNPO0FBQ3RHLDRDQUE0Qyw2akJBQTZRO0FBQ3pULDRDQUE0Qyxta0JBQWdSO0FBQzVULDRDQUE0QywrWUFBc0w7QUFDbE8sNENBQTRDLHFpQkFBaVE7QUFDN1MsNENBQTRDLCtJQUFzRDtBQUNsRyw0Q0FBNEMsNkhBQTZDO0FBQ3pGLDRDQUE0Qyx1SUFBa0Q7QUFDOUYsOEJBQThCLG1GQUEyQixDQUFDLDRGQUFxQztBQUMvRix5Q0FBeUMsc0ZBQStCO0FBQ3hFLHlDQUF5QyxzRkFBK0I7QUFDeEUseUNBQXlDLHNGQUErQjtBQUN4RSx5Q0FBeUMsc0ZBQStCO0FBQ3hFLHlDQUF5QyxzRkFBK0I7QUFDeEUseUNBQXlDLHNGQUErQjtBQUN4RSx5Q0FBeUMsc0ZBQStCO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQjtBQUMxQixtQkFBbUI7QUFDbkIsdUJBQXVCO0FBQ3ZCLHlCQUF5QjtBQUN6Qjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0Esb0JBQW9CO0FBQ3BCLGtDQUFrQztBQUNsQyxvQkFBb0I7QUFDcEIsZUFBZTtBQUNmLGdPQUFnTztBQUNoTyxpQ0FBaUM7QUFDakMsbUNBQW1DO0FBQ25DOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsYUFBYTtBQUNiLHdCQUF3QjtBQUN4Qjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsYUFBYTtBQUNiLGtCQUFrQjtBQUNsQix5QkFBeUI7QUFDekI7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtSEFBbUg7QUFDbkgsa0JBQWtCO0FBQ2xCOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGtCQUFrQjtBQUNsQix5QkFBeUI7QUFDekIsNkJBQTZCO0FBQzdCOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QixrQ0FBa0M7QUFDbEMsb0NBQW9DO0FBQ3BDLG1CQUFtQjtBQUNuQix3QkFBd0I7QUFDeEIsd0JBQXdCO0FBQ3hCLGtCQUFrQjtBQUNsQixhQUFhO0FBQ2IsY0FBYztBQUNkOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QixpQ0FBaUM7QUFDakMsMEJBQTBCO0FBQzFCOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGlDQUFpQztBQUNqQyx3QkFBd0I7QUFDeEI7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhCQUE4QjtBQUM5QixpQkFBaUI7QUFDakI7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsY0FBYztBQUNkLGtCQUFrQjtBQUNsQjs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQiwwQkFBMEI7QUFDMUI7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDBCQUEwQixtQ0FBbUM7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSwwQkFBMEIsbUNBQW1DO0FBQzdEOztBQUVBO0FBQ0EsMEJBQTBCLG1DQUFtQztBQUM3RDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDBCQUEwQixtQ0FBbUM7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLDRFQUE0RSxpQkFBaUIsaUJBQWlCLG1CQUFtQixvQkFBb0IscUJBQXFCLGNBQWMsV0FBVyw2QkFBNkIseUJBQXlCLDZDQUE2Qyw0REFBNEQ7QUFDalg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IsNEVBQTRFLGdCQUFnQixXQUFXLFlBQVksb0JBQW9CLGVBQWUsU0FBUyx3QkFBd0I7QUFDek07QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQiw0RUFBNEUsa0JBQWtCLHFCQUFxQix5QkFBeUIsYUFBYSx5QkFBeUIsbUJBQW1CLDJCQUEyQixxQkFBcUIsd0JBQXdCLG9CQUFvQixxQkFBcUIsb0JBQW9CLG1CQUFtQixrQkFBa0Isc0JBQXNCLDRDQUE0QyxpRkFBaUYscUdBQXFHLHlHQUF5RyxnQ0FBZ0M7QUFDbHdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsNEVBQTRFLGlCQUFpQixtQkFBbUIsYUFBYSxnQkFBZ0IsY0FBYyxrQkFBa0IsMEJBQTBCLGtCQUFrQix5QkFBeUIsd0JBQXdCLDZDQUE2Qyw0REFBNEQ7QUFDNVg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLG1DQUFtQztBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsdUNBQXVDLG1DQUFtQztBQUMxRTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxvQ0FBb0MsbUNBQW1DO0FBQ3ZFO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLDJHQUEyRyxZQUFZLE1BQU0sT0FBTyxxQkFBcUIsb0JBQW9CLHFCQUFxQixxQkFBcUIsTUFBTSxNQUFNLFdBQVcsTUFBTSxXQUFXLE1BQU0sS0FBSyxxQkFBcUIscUJBQXFCLHFCQUFxQixvQkFBb0IscUJBQXFCLHFCQUFxQixxQkFBcUIsTUFBTSxPQUFPLE1BQU0sS0FBSyxvQkFBb0IscUJBQXFCLE1BQU0sUUFBUSxNQUFNLEtBQUssb0JBQW9CLG9CQUFvQixxQkFBcUIsTUFBTSxNQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxXQUFXLE1BQU0sTUFBTSxNQUFNLE1BQU0sV0FBVyxNQUFNLE9BQU8sTUFBTSxRQUFRLHFCQUFxQixvQkFBb0IsTUFBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE1BQU0sTUFBTSxNQUFNLE1BQU0sVUFBVSxVQUFVLFdBQVcsV0FBVyxNQUFNLEtBQUssVUFBVSxNQUFNLEtBQUssVUFBVSxNQUFNLFFBQVEsTUFBTSxLQUFLLG9CQUFvQixxQkFBcUIscUJBQXFCLE1BQU0sUUFBUSxNQUFNLFNBQVMscUJBQXFCLHFCQUFxQixxQkFBcUIsb0JBQW9CLHFCQUFxQixxQkFBcUIsb0JBQW9CLG9CQUFvQixvQkFBb0IsTUFBTSxNQUFNLE1BQU0sTUFBTSxXQUFXLE1BQU0sT0FBTyxNQUFNLFFBQVEscUJBQXFCLHFCQUFxQixxQkFBcUIsTUFBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE1BQU0sTUFBTSxNQUFNLEtBQUssV0FBVyxNQUFNLE1BQU0sTUFBTSxLQUFLLFdBQVcsTUFBTSxNQUFNLE1BQU0sTUFBTSxVQUFVLE1BQU0sT0FBTyxNQUFNLEtBQUsscUJBQXFCLHFCQUFxQixNQUFNLE1BQU0sTUFBTSxLQUFLLFdBQVcsTUFBTSxPQUFPLE1BQU0sS0FBSyxxQkFBcUIsb0JBQW9CLE1BQU0sTUFBTSxNQUFNLEtBQUssV0FBVyxNQUFNLE1BQU0sTUFBTSxpQkFBaUIsVUFBVSxNQUFNLEtBQUssVUFBVSxVQUFVLE1BQU0sS0FBSyxVQUFVLE1BQU0sT0FBTyxXQUFXLFVBQVUsVUFBVSxNQUFNLE1BQU0sS0FBSyxLQUFLLFVBQVUsTUFBTSxNQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sT0FBTyxNQUFNLE1BQU0sb0JBQW9CLG9CQUFvQixNQUFNLE1BQU0sTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLEtBQUssS0FBSyxVQUFVLE1BQU0sUUFBUSxNQUFNLFlBQVksb0JBQW9CLHFCQUFxQixNQUFNLE1BQU0sTUFBTSxNQUFNLFVBQVUsVUFBVSxNQUFNLFdBQVcsS0FBSyxVQUFVLE1BQU0sS0FBSyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxVQUFVLFdBQVcsV0FBVyxNQUFNLEtBQUssV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsS0FBSyxNQUFNLEtBQUssVUFBVSxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxVQUFVLEtBQUssTUFBTSxLQUFLLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxLQUFLLE1BQU0sS0FBSyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsS0FBSyxNQUFNLEtBQUssV0FBVyxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxVQUFVLFVBQVUsVUFBVSxVQUFVLFdBQVcsV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxLQUFLLE1BQU0sS0FBSyxXQUFXLFdBQVcsV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLEtBQUssV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLEtBQUssV0FBVyxXQUFXLFVBQVUsV0FBVyxVQUFVLFdBQVcsS0FBSyxNQUFNLEtBQUssV0FBVyxLQUFLLEtBQUssS0FBSyxXQUFXLFdBQVcsV0FBVyxXQUFXLE1BQU0sS0FBSyxXQUFXLFdBQVcsV0FBVyxVQUFVLFdBQVcsV0FBVyxVQUFVLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLE1BQU0sS0FBSyxXQUFXLFdBQVcsV0FBVyxLQUFLLE1BQU0sVUFBVSxVQUFVLFVBQVUsV0FBVyxXQUFXLFdBQVcsS0FBSyxNQUFNLFVBQVUsV0FBVyxXQUFXLFdBQVcsS0FBSyxNQUFNLFVBQVUsV0FBVyxLQUFLLE1BQU0sVUFBVSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssTUFBTSxVQUFVLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLEtBQUssS0FBSyxNQUFNLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxLQUFLLEtBQUssS0FBSyxXQUFXLFdBQVcsV0FBVyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssV0FBVyxXQUFXLFVBQVUsVUFBVSxVQUFVLFdBQVcsS0FBSyxLQUFLLEtBQUssV0FBVyxVQUFVLEtBQUssS0FBSyxLQUFLLFVBQVUsS0FBSyxLQUFLLEtBQUssVUFBVSxLQUFLLEtBQUssS0FBSyxVQUFVLFVBQVUsS0FBSyxLQUFLLFFBQVEsV0FBVyxXQUFXLFdBQVcsS0FBSyxLQUFLLE1BQU0sVUFBVSxXQUFXLEtBQUssS0FBSyxLQUFLLFVBQVUsS0FBSyxLQUFLLEtBQUssV0FBVyxLQUFLLEtBQUssS0FBSyxXQUFXLEtBQUssS0FBSyxnSkFBZ0osS0FBSyxLQUFLLFVBQVUsS0FBSyxLQUFLLEtBQUssV0FBVyxLQUFLLEtBQUssS0FBSyxXQUFXLEtBQUssS0FBSyxvR0FBb0csS0FBSyxLQUFLLFdBQVcsV0FBVyxLQUFLLEtBQUssS0FBSyxVQUFVLFdBQVcsV0FBVyxLQUFLLE1BQU0sVUFBVSxLQUFLLFVBQVUsS0FBSyxLQUFLLE1BQU0sV0FBVyxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsS0FBSyxLQUFLLE1BQU0sV0FBVyxLQUFLLEtBQUssS0FBSyxXQUFXLEtBQUssS0FBSyxLQUFLLFdBQVcsVUFBVSxVQUFVLFVBQVUsVUFBVSxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssVUFBVSxVQUFVLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxLQUFLLEtBQUssS0FBSyxXQUFXLEtBQUssS0FBSyxLQUFLLFdBQVcsV0FBVyxLQUFLLEtBQUssS0FBSyxXQUFXLEtBQUssTUFBTSxVQUFVLEtBQUssVUFBVSxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsS0FBSyxLQUFLLFFBQVEsVUFBVSxVQUFVLFdBQVcsV0FBVyxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLEtBQUssS0FBSyxRQUFRLFVBQVUsVUFBVSxLQUFLLEtBQUssS0FBSyxVQUFVLFVBQVUsV0FBVyxXQUFXLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsS0FBSyxLQUFLLEtBQUssVUFBVSxVQUFVLEtBQUssS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLEtBQUssVUFBVSxVQUFVLFdBQVcsV0FBVyxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLEtBQUssS0FBSyxLQUFLLFVBQVUsVUFBVSxLQUFLLEtBQUssS0FBSyxXQUFXLEtBQUssS0FBSyxLQUFLLFVBQVUsVUFBVSxXQUFXLFdBQVcsVUFBVSxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxLQUFLLEtBQUssS0FBSyxVQUFVLFVBQVUsS0FBSyxLQUFLLEtBQUssV0FBVyxLQUFLLE1BQU0sS0FBSyxXQUFXLFdBQVcsV0FBVyxXQUFXLFVBQVUsVUFBVSxVQUFVLFVBQVUsVUFBVSxVQUFVLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsVUFBVSxXQUFXLFdBQVcsV0FBVyxXQUFXLFVBQVUsV0FBVyxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLFdBQVcsV0FBVyxXQUFXLFdBQVcsVUFBVSxVQUFVLFVBQVUsVUFBVSxVQUFVLFVBQVUsVUFBVSxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsVUFBVSxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsVUFBVSxXQUFXLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsS0FBSyxLQUFLLEtBQUssS0FBSyxNQUFNLE9BQU8sS0FBSyxLQUFLLE1BQU0sS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNLEtBQUssT0FBTyxLQUFLLEtBQUssTUFBTSxLQUFLLE9BQU8sS0FBSyxLQUFLLE1BQU0sS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNLEtBQUssWUFBWSxLQUFLLFlBQVksTUFBTSxNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sTUFBTSxZQUFZLE1BQU0sTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLE9BQU8sWUFBWSxhQUFhLGFBQWEsWUFBWSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLE1BQU0sTUFBTSxPQUFPLFlBQVksYUFBYSxNQUFNLE1BQU0sT0FBTyxXQUFXLFlBQVksTUFBTSxNQUFNLE1BQU0sWUFBWSxhQUFhLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLFlBQVksYUFBYSxhQUFhLE1BQU0sTUFBTSxNQUFNLFdBQVcsWUFBWSxNQUFNLE1BQU0sTUFBTSxLQUFLLE1BQU0sV0FBVyxLQUFLLFlBQVksTUFBTSxNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sa1NBQWtTLEtBQUssTUFBTSxLQUFLLE1BQU0sTUFBTSxZQUFZLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLFdBQVcsWUFBWSxNQUFNLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxXQUFXLFlBQVksYUFBYSxhQUFhLFlBQVksYUFBYSxNQUFNLE1BQU0sTUFBTSxXQUFXLFlBQVksTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sWUFBWSxhQUFhLGFBQWEsYUFBYSxhQUFhLE1BQU0sTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLE1BQU0sWUFBWSxZQUFZLFlBQVksWUFBWSxhQUFhLGFBQWEsWUFBWSxZQUFZLGFBQWEsYUFBYSxNQUFNLE1BQU0sTUFBTSxZQUFZLE1BQU0sTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLHVMQUF1TCxLQUFLLE1BQU0sS0FBSyxLQUFLLEtBQUssWUFBWSxZQUFZLFlBQVksWUFBWSxhQUFhLE1BQU0sTUFBTSxPQUFPLFdBQVcsWUFBWSxZQUFZLGFBQWEsYUFBYSxhQUFhLE1BQU0sTUFBTSxPQUFPLEtBQUssTUFBTSxPQUFPLEtBQUssTUFBTSxNQUFNLFdBQVcsWUFBWSxhQUFhLGFBQWEsYUFBYSxNQUFNLE1BQU0sT0FBTyxXQUFXLFlBQVksTUFBTSxNQUFNLE9BQU8sS0FBSyxNQUFNLE1BQU0sWUFBWSxhQUFhLGFBQWEsYUFBYSxZQUFZLGFBQWEsTUFBTSxNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sTUFBTSxZQUFZLGFBQWEsTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sWUFBWSxZQUFZLFlBQVksWUFBWSxhQUFhLGFBQWEsTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sV0FBVyxZQUFZLGFBQWEsYUFBYSxNQUFNLE1BQU0sT0FBTyxXQUFXLFlBQVksTUFBTSxNQUFNLE9BQU8sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sV0FBVyxZQUFZLGFBQWEsTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sWUFBWSxhQUFhLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sTUFBTSxZQUFZLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sTUFBTSxZQUFZLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLFlBQVksYUFBYSxNQUFNLE1BQU0sTUFBTSxZQUFZLE1BQU0sTUFBTSxNQUFNLFlBQVksYUFBYSxNQUFNLE9BQU8sTUFBTSxZQUFZLGFBQWEsYUFBYSxPQUFPLEtBQUssWUFBWSxhQUFhLGFBQWEsT0FBTyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLEtBQUssV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLEtBQUssV0FBVyxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxXQUFXLEtBQUssTUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLEtBQUssS0FBSyx3Q0FBd0MsdUJBQXVCLHNCQUFzQixlQUFlLGtGQUFrRiwyQkFBMkIsaUNBQWlDLEdBQUcsb0JBQW9CLG9GQUFvRiwyQkFBMkIsaUNBQWlDLEdBQUcsaUJBQWlCLE9BQU8sNEJBQTRCLDBDQUEwQyx5Q0FBeUMsdUNBQXVDLEtBQUssWUFBWSwrQkFBK0IseUNBQXlDLHVCQUF1QixzQkFBc0IsdUJBQXVCLHlIQUF5SCxLQUFLLHNHQUFzRyxxTEFBcUwsS0FBSyxZQUFZLHlCQUF5QixLQUFLLDBDQUEwQyxxSUFBcUksS0FBSyxnQkFBZ0IseUNBQXlDLDRFQUE0RSxPQUFPLHdCQUF3QixpRUFBaUUsS0FBSyx3REFBd0QsK0RBQStELEtBQUssNkNBQTZDLG9EQUFvRCxLQUFLLDBDQUEwQyxnQ0FBZ0MsS0FBSywwQ0FBMEMsa0NBQWtDLEtBQUssNkNBQTZDLHNDQUFzQyxLQUFLLG1FQUFtRSxxRUFBcUUsS0FBSywrQkFBK0IsOENBQThDLEtBQUssbUJBQW1CLG9DQUFvQyxLQUFLLGdCQUFnQiw0SEFBNEgsS0FBSyxnQkFBZ0IsZ0NBQWdDLEtBQUssbUJBQW1CLHNIQUFzSCxLQUFLLG1DQUFtQywyQkFBMkIsS0FBSyxtREFBbUQsNkVBQTZFLEtBQUsseUJBQXlCLDZCQUE2QixLQUFLLCtCQUErQix1SUFBdUksS0FBSyxxQ0FBcUMsc0RBQXNELEtBQUssaUNBQWlDLG9JQUFvSSxLQUFLLGdDQUFnQyw2REFBNkQsS0FBSyxnREFBZ0QsNkdBQTZHLEtBQUssd0VBQXdFLGtDQUFrQyxLQUFLLGNBQWMsZ0NBQWdDLEtBQUssWUFBWSw2QkFBNkIsS0FBSyxjQUFjLCtCQUErQixLQUFLLEdBQUcsdUJBQXVCLG9DQUFvQyxtR0FBbUcsS0FBSyw2Q0FBNkMsb05BQW9OLEtBQUsseURBQXlELGdDQUFnQyxLQUFLLHdCQUF3QixvR0FBb0csS0FBSyw4QkFBOEIsc0RBQXNELEtBQUssc0NBQXNDLGdPQUFnTyxLQUFLLDJCQUEyQixrQ0FBa0MsS0FBSyw0QkFBNEIsdUJBQXVCLEtBQUssZ0NBQWdDLHdFQUF3RSxLQUFLLHNDQUFzQyxtREFBbUQsS0FBSyx1Q0FBdUMsc0VBQXNFLEtBQUssc0JBQXNCLHdGQUF3RixLQUFLLFlBQVksMEtBQTBLLEtBQUssMEJBQTBCLGtCQUFrQixLQUFLLG1CQUFtQix5RUFBeUUsS0FBSywrQ0FBK0MsNEhBQTRILEtBQUssMEJBQTBCLDJFQUEyRSxLQUFLLDJEQUEyRCx3REFBd0QsS0FBSyx3QkFBd0IsK0VBQStFLEtBQUssMEJBQTBCLCtEQUErRCxLQUFLLHVCQUF1QixxR0FBcUcsS0FBSyx1REFBdUQsMkRBQTJELEtBQUssbUVBQW1FLHdEQUF3RCxLQUFLLGlDQUFpQyxnREFBZ0QsS0FBSyw4QkFBOEIsaURBQWlELEtBQUssbUNBQW1DLHlCQUF5QixLQUFLLG1CQUFtQixtREFBbUQsS0FBSyx1QkFBdUIsa0RBQWtELEtBQUssR0FBRywwQkFBMEI7QUFDcG1sQjtBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7OztBQzlrRDFCOztBQUViO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxREFBcUQ7QUFDckQ7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRDtBQUNBO0FBQ0EscUZBQXFGO0FBQ3JGO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixpQkFBaUI7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLHFCQUFxQjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVixzRkFBc0YscUJBQXFCO0FBQzNHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVixpREFBaUQscUJBQXFCO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVixzREFBc0QscUJBQXFCO0FBQzNFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7QUNwRmE7O0FBRWI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7OztBQ3pCYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdURBQXVELGNBQWM7QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2RBLE1BQXFHO0FBQ3JHLE1BQTJGO0FBQzNGLE1BQWtHO0FBQ2xHLE1BQXFIO0FBQ3JILE1BQThHO0FBQzlHLE1BQThHO0FBQzlHLE1BQXNMO0FBQ3RMO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHFHQUFtQjtBQUMvQyx3QkFBd0Isa0hBQWE7O0FBRXJDLHVCQUF1Qix1R0FBYTtBQUNwQztBQUNBLGlCQUFpQiwrRkFBTTtBQUN2Qiw2QkFBNkIsc0dBQWtCOztBQUUvQyxhQUFhLDBHQUFHLENBQUMsc0pBQU87Ozs7QUFJZ0k7QUFDeEosT0FBTyxpRUFBZSxzSkFBTyxJQUFJLHNKQUFPLFVBQVUsc0pBQU8sbUJBQW1CLEVBQUM7Ozs7Ozs7Ozs7O0FDMUJoRTs7QUFFYjtBQUNBO0FBQ0E7QUFDQSxrQkFBa0Isd0JBQXdCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLGlCQUFpQjtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLDRCQUE0QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLDZCQUE2QjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7OztBQ25GYTs7QUFFYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7QUNqQ2E7O0FBRWI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7OztBQ1RhOztBQUViO0FBQ0E7QUFDQSxjQUFjLEtBQXdDLEdBQUcsc0JBQWlCLEdBQUcsQ0FBSTtBQUNqRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7O0FDVGE7O0FBRWI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrREFBa0Q7QUFDbEQ7QUFDQTtBQUNBLDBDQUEwQztBQUMxQztBQUNBO0FBQ0E7QUFDQSxpRkFBaUY7QUFDakY7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSx5REFBeUQ7QUFDekQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7QUM1RGE7O0FBRWI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ2JBLE1BQU0sWUFBWSxHQUFHLENBQUMsSUFBZ0IsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBMkIsQ0FBQyxDQUFDO0FBQ3BILE1BQU0sWUFBWSxHQUFHLENBQUMsR0FBVyxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFFL0YsTUFBTSxHQUFHLEdBQUcsSUFBSSxXQUFXLEVBQUU7QUFDN0IsTUFBTSxHQUFHLEdBQUcsSUFBSSxXQUFXLEVBQUU7QUFDN0IsTUFBTSxPQUFPLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUU7QUFFcEM7OztHQUdHO0FBQ0gsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLFFBQWdCLEVBQUUsRUFBRTtJQUM5QyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsRUFBRSxLQUFLLEVBQUU7UUFDNUYsWUFBWTtRQUNaLFdBQVc7S0FDWixDQUFDO0FBQ0osQ0FBQztBQUVEOzs7R0FHRztBQUNILE1BQU0sTUFBTSxHQUFHLENBQUMsZUFBMEIsRUFBRSxJQUFrQixFQUFFLEVBQUU7SUFDaEUsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQ25DO1FBQ0UsSUFBSSxFQUFFLFFBQVE7UUFDZCxJQUFJO1FBQ0osVUFBVSxFQUFFLE1BQU07UUFDbEIsSUFBSSxFQUFFLFNBQVM7S0FDaEIsRUFDRCxlQUFlLEVBQ2YsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsRUFDaEMsSUFBSSxFQUNKLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUN2QjtBQUNILENBQUM7QUFFRCxNQUFNLE9BQU8sR0FBRyxLQUFLLEVBQUUsTUFBYyxFQUFFLFFBQWdCLEVBQUUsRUFBRTtJQUN6RCxNQUFNLGVBQWUsR0FBRyxNQUFNLGtCQUFrQixDQUFDLFFBQVEsQ0FBQztJQUMxRCxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDeEUsTUFBTSxHQUFHLEdBQUcsTUFBTSxNQUFNLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztJQUMvQyxNQUFNLEVBQUUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDcEUsTUFBTSxPQUFPLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7SUFFbEMsTUFBTSxVQUFVLEdBQUcsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQ25EO1FBQ0UsSUFBSSxFQUFFLFNBQVM7UUFDZixFQUFFO0tBQ0gsRUFDRCxHQUFHLEVBQ0gsT0FBTyxDQUNSO0lBRUQsTUFBTSxNQUFNLEdBQUcsSUFBSSxVQUFVLENBQUMsVUFBVSxDQUFDO0lBQ3pDLE1BQU0sTUFBTSxHQUFHLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDO0lBQ2xGLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUNuQixNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQy9CLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUVuRCxNQUFNLFNBQVMsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDO0lBQ3RDLE9BQU8sU0FBUztBQUNsQixDQUFDO0FBRUQ7Ozs7Ozs7Ozs7O0dBV0c7QUFDSCxNQUFNLE9BQU8sR0FBRyxLQUFLLEVBQUUsU0FBaUIsRUFBRSxRQUFnQixFQUFFLEVBQUU7SUFDNUQsTUFBTSxlQUFlLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQztJQUMvQyxNQUFNLElBQUksR0FBRyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDO0lBQ25ELE1BQU0sRUFBRSxHQUFHLGVBQWUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDekUsTUFBTSxVQUFVLEdBQUcsZUFBZSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFFbkUsTUFBTSxlQUFlLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxRQUFRLENBQUM7SUFDMUQsTUFBTSxHQUFHLEdBQUcsTUFBTSxNQUFNLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztJQUUvQyxJQUFJO1FBQ0YsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FDekQ7WUFDRSxJQUFJLEVBQUUsU0FBUztZQUNmLEVBQUU7U0FDSCxFQUNELEdBQUcsRUFDSCxVQUFVLENBQ1g7UUFFRCxNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDO1FBQzlDLE9BQU8sU0FBUztLQUNqQjtJQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ1YsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFXLENBQUM7S0FDN0I7QUFDSCxDQUFDO0FBRTBCOzs7Ozs7Ozs7Ozs7Ozs7QUNuRzNCLE1BQU0sR0FBRztJQUNQLGlCQUFpQixDQUE0QjtJQUM3QyxVQUFVLENBQXdCO0lBQ2xDLE1BQU0sQ0FBdUI7SUFDN0IsV0FBVyxDQUF1RDtJQUNsRSxlQUFlLENBQXVCO0lBRXRDLFlBQVksSUFBWTtRQUN0QixJQUFJLFFBQVEsR0FBRyxJQUFJLElBQUksRUFBRTtRQUN6QixJQUFJLFFBQVEsR0FBRyxFQUFFO1FBQ2pCLE1BQU0saUJBQWlCLEdBQUcsRUFBK0I7UUFFekQsTUFBTSxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRTtZQUM1QixRQUFRLEVBQUU7Z0JBQ1IsR0FBRztvQkFDRCxPQUFPLFFBQVE7Z0JBQ2pCLENBQUM7YUFDRjtZQUVELFFBQVEsRUFBRTtnQkFDUixHQUFHLENBQUMsSUFBSTtvQkFDTixRQUFRLEdBQUcsSUFBSTtnQkFDakIsQ0FBQzthQUNGO1lBRUQsaUJBQWlCLEVBQUU7Z0JBQ2pCLEdBQUcsQ0FBQyxJQUFJO29CQUNOLElBQUksSUFBSSxZQUFZLE1BQU0sRUFBRTt3QkFDMUIsS0FBSyxNQUFNLENBQUMsSUFBSSxJQUFJLEVBQUU7NEJBQ3BCLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FDOUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzs2QkFDL0I7eUJBQ0Y7cUJBQ0Y7Z0JBQ0gsQ0FBQztnQkFDRCxHQUFHO29CQUNELE9BQU8saUJBQWlCO2dCQUMxQixDQUFDO2FBQ0Y7WUFFRCxJQUFJLEVBQUU7Z0JBQ0osR0FBRztvQkFDRCxPQUFPLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxpQkFBaUIsRUFBRTtnQkFDbEQsQ0FBQzthQUNGO1lBRUQsSUFBSSxFQUFFO2dCQUNKLEtBQUssQ0FBQyxJQUEwRjtvQkFDOUYsTUFBTSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsR0FBRyxJQUFJO29CQUV0RSxJQUFJLEVBQUUsRUFBRTt3QkFDTixRQUFRLEdBQUcsRUFBRTtxQkFDZDtvQkFFRCxJQUFJLElBQUksRUFBRTt3QkFDUixRQUFRLEdBQUcsSUFBSTtxQkFDaEI7b0JBRUQsSUFBSSxJQUFJLEVBQUU7d0JBQ1IsS0FBSyxNQUFNLENBQUMsSUFBSSxJQUFJLEVBQUU7NEJBQ3BCLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRTtnQ0FDakQsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzs2QkFDL0I7eUJBQ0Y7cUJBQ0Y7b0JBRUQsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7d0JBQzNCLFFBQVE7d0JBQ1IsUUFBUTt3QkFDUixpQkFBaUI7cUJBQ2xCLENBQUM7Z0JBQ0osQ0FBQzthQUNGO1lBRUQsa0JBQWtCLEVBQUU7Z0JBQ2xCLEtBQUssQ0FBQyxLQUFLO29CQUNULElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7d0JBQzlDLE9BQU8sTUFBTSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztxQkFDdEM7b0JBRUQsSUFBSSxRQUFRO29CQUNaLElBQUk7d0JBQ0YsUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7cUJBQ2hEO29CQUFDLE9BQU8sS0FBSyxFQUFFO3dCQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO3dCQUNwQixPQUFPLEtBQUs7cUJBQ2I7b0JBRUQsSUFBSSxRQUFRLEtBQUssT0FBTyxFQUFFO3dCQUN4QixPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUM7d0JBQzVDLE9BQU8sS0FBSztxQkFDYjtvQkFFRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO3dCQUM3QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTs0QkFDdEQsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQzt5QkFDakM7d0JBRUQsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRTt3QkFDaEMsTUFBTSxJQUFJLENBQUMsa0JBQWtCLEVBQUU7cUJBQ2hDO29CQUVELE9BQU8sTUFBTSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztnQkFDdkMsQ0FBQzthQUNGO1lBRUQsS0FBSyxFQUFFO2dCQUNMLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBeUQ7b0JBQ25FLElBQUksRUFBRSxZQUFZLEVBQUUsR0FBRyxPQUFPLElBQUksRUFBRTtvQkFDcEMsTUFBTSxFQUFFLFlBQVksRUFBRSxHQUFHLE9BQU8sSUFBSSxFQUFFO29CQUV0Qyw4QkFBOEI7b0JBQzlCLElBQUksQ0FBQyxZQUFZLEVBQUU7d0JBQ2pCLFlBQVksR0FBRyxvQ0FBb0M7cUJBQ3BEO29CQUVELHdCQUF3QjtvQkFDeEIsTUFBTSxVQUFVLEdBQUcsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQztvQkFDdEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLFVBQVUsRUFBRSxDQUFDO29CQUMzQixJQUFJLFVBQVUsRUFBRTt3QkFDZCxPQUFPLFlBQVk7cUJBQ3BCO29CQUVELDJCQUEyQjtvQkFDM0IsSUFBSSxRQUFRO29CQUNaLElBQUk7d0JBQ0YsUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7cUJBQ2hEO29CQUFDLE9BQU8sS0FBSyxFQUFFO3dCQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO3dCQUNwQixPQUFPLEtBQUs7cUJBQ2I7b0JBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxRQUFRLENBQUM7b0JBRTFDLDBDQUEwQztvQkFDMUMsTUFBTSxNQUFNLEdBQUcsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTtvQkFFaEQsdUJBQXVCO29CQUN2QixNQUFNLGFBQWEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUM7d0JBQzNDLFFBQVE7d0JBQ1IsUUFBUTt3QkFDUixNQUFNO3dCQUNOLFlBQVk7d0JBQ1osWUFBWTtxQkFDYixDQUFDO29CQUVGLE9BQU8sYUFBYTtnQkFDdEIsQ0FBQzthQUNGO1NBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxVQUFVLFFBQWdCO1lBQ2pELE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQztRQUMzQixDQUFDO1FBRUQsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLO1lBQ2pCLE1BQU0sR0FBRyxHQUFHLDhDQUE4QztZQUMxRCxNQUFNLFFBQVEsR0FBRyxDQUFDLE1BQU0sY0FBYyxDQUFDLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQWE7WUFFckUsSUFBSSxRQUFRLENBQUMsVUFBVSxFQUFFO2dCQUN2QixPQUFPLFFBQVEsQ0FBQyxHQUFHO2FBQ3BCO1lBRUQsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ25ELENBQUM7UUFFRCxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssV0FBVyxZQUFxQjtZQUNyRCxJQUFJLENBQUMsWUFBWSxFQUFFO2dCQUNqQixZQUFZLEdBQUcsb0NBQW9DO2FBQ3BEO1lBRUQsTUFBTSxHQUFHLEdBQUcsQ0FBQyxNQUFNLGNBQWMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFhO1lBQ3pFLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFO2dCQUNuQixPQUFPLElBQUk7YUFDWjtZQUVELE9BQU8sS0FBSztRQUNkLENBQUM7UUFFRCxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssV0FBVyxRQUFnQztZQUNqRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxHQUFHLFFBQVE7WUFFM0UsSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDckMsTUFBTSxJQUFJLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQzthQUM5RDtZQUVELElBQUksSUFBSSxHQUFHLFdBQVcsUUFBUSxhQUFhLFFBQVEsV0FBVyxNQUFNLEVBQUU7WUFDdEUsSUFBSSxZQUFZLEVBQUU7Z0JBQ2hCLElBQUksSUFBSSxpQkFBaUIsWUFBWSxFQUFFO2FBQ3hDO1lBRUQsSUFBSSxZQUFZLEVBQUU7Z0JBQ2hCLElBQUksSUFBSSxpQkFBaUIsWUFBWSxFQUFFO2FBQ3hDO2lCQUFNO2dCQUNMLElBQUksSUFBSSxrREFBa0Q7YUFDM0Q7WUFFRCxNQUFNLEdBQUcsR0FBRyxxREFBcUQ7WUFDakUsTUFBTSxNQUFNLEdBQUcsTUFBTTtZQUVyQixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUM7WUFDOUIsTUFBTSxRQUFRLEdBQUcsQ0FBQyxNQUFNLGNBQWMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFhO1lBRXZGLElBQUksUUFBUSxDQUFDLFVBQVUsRUFBRTtnQkFDdkIsT0FBTyxRQUFRLENBQUMsR0FBRzthQUNwQjtZQUVELE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1FBQ3pELENBQUM7UUFFRCxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssV0FBVyxhQUFzQjtZQUMzRCxJQUFJLENBQUMsYUFBYSxFQUFFO2dCQUNsQixNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDO2FBQzNDO1lBRUQsTUFBTSxHQUFHLEdBQUcsZ0VBQWdFO1lBQzVFLE1BQU0sTUFBTSxHQUFHLE1BQU07WUFDckIsTUFBTSxJQUFJLEdBQUcsV0FBVyxhQUFhLEVBQUU7WUFFdkMsTUFBTSxRQUFRLEdBQUcsTUFBTSxjQUFjLENBQUMsSUFBSSxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7WUFDekUsT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTztRQUM3QyxDQUFDO1FBRUQsTUFBTSxjQUFjLEdBQUcsS0FBSyxXQUFXLE9BQWdCO1lBQ3JELElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbkIsTUFBTSxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsR0FBRyxPQUFPO1lBQy9CLE1BQU0sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDO1lBRXpDLE1BQU0sUUFBUSxHQUFHLE1BQU0sV0FBVyxDQUFDLE9BQU8sQ0FBQztZQUMzQyxFQUFFLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUVoQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxHQUFHLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLE1BQU0sUUFBUSxHQUFHLE1BQU0sRUFBRSxDQUFDO1lBRXpFLElBQUksUUFBUSxDQUFDLEVBQUUsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLEdBQUcsRUFBRTtnQkFDMUMsT0FBTyxRQUFRO2FBQ2hCO1lBRUQsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLHVCQUF1QixHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM3RSxDQUFDO1FBRUQsTUFBTSxXQUFXLEdBQUcsVUFBVSxPQUFnQjtZQUM1QyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssTUFBTSxFQUFFO2dCQUM3QixPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsbUNBQW1DLENBQUM7YUFDekU7WUFFRCxPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDdkIsQ0FBQztJQUNILENBQUM7Q0FDRjtBQUVELGlFQUFlLEdBQUc7Ozs7Ozs7Ozs7Ozs7OztBQzVQbEIsTUFBTSxxQkFBcUIsR0FBRyxDQUM1QixPQUFlLEVBQ2YsSUFBSSxHQUFHLE1BQU0sRUFDYixPQUFPLEdBQUcsS0FBSyxFQUNmLFVBQVUsR0FBRyxHQUFHLEVBQUUsR0FBRSxDQUFDLEVBQ3JCLGFBQWEsR0FBRyxHQUFHLEVBQUUsR0FBRSxDQUFDLEVBQ3hCLEVBQUU7SUFDRixNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBZ0I7SUFDekQsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQWdCO0lBQ2pFLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFnQjtJQUVqRSxNQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBZ0I7SUFDL0QsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQWdCO0lBQ3ZFLE1BQU0sVUFBVSxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFnQjtJQUV2RSxJQUFJLE1BQU07SUFDVixHQUFHLENBQUMsU0FBUyxHQUFHLElBQUk7SUFFcEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLEdBQUcsUUFBUTtJQUN2QyxRQUFRLElBQUksRUFBRTtRQUNaLEtBQUssU0FBUztZQUNaLE1BQU0sR0FBRyxTQUFTO1lBQ2xCLE1BQUs7UUFDUCxLQUFLLE9BQU87WUFDVixNQUFNLEdBQUcsT0FBTztZQUNoQixNQUFLO1FBQ1AsS0FBSyxTQUFTO1lBQ1osTUFBTSxHQUFHLE9BQU87WUFDaEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLEdBQUcsWUFBWTtZQUMzQyxNQUFLO1FBRVA7WUFDRSxNQUFNLEdBQUcsTUFBTTtZQUNmLE1BQUs7S0FDUjtJQUVELE9BQU8sQ0FBQyxXQUFXLEdBQUcsT0FBTztJQUM3QixPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsTUFBTSxJQUFJLE1BQU0sRUFBRSxDQUFDLENBQUM7SUFFN0YsVUFBVSxDQUFDLFdBQVcsR0FBRyxPQUFPO0lBQ2hDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLHNCQUFzQixNQUFNLElBQUksTUFBTSxFQUFFLENBQUMsQ0FBQztJQUVoRyxJQUFJLE9BQU8sRUFBRTtRQUNYLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVqRSxNQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNsRCxZQUFZLENBQUMsU0FBUyxHQUFHLFFBQVE7UUFDakMsWUFBWSxDQUFDLFdBQVcsR0FBRyxLQUFLO1FBRWhDLE1BQU0sZUFBZSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO1FBQ3JELGVBQWUsQ0FBQyxTQUFTLEdBQUcsUUFBUTtRQUNwQyxlQUFlLENBQUMsV0FBVyxHQUFHLFFBQVE7UUFFdEMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7UUFDN0IsR0FBRyxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUM7UUFFaEMsWUFBWSxDQUFDLE9BQU8sR0FBRyxHQUFHLEVBQUU7WUFDMUIsR0FBRyxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7WUFDN0IsR0FBRyxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUM7WUFDaEMsVUFBVSxFQUFFO1FBQ2QsQ0FBQztRQUVELGVBQWUsQ0FBQyxPQUFPLEdBQUcsR0FBRyxFQUFFO1lBQzdCLEdBQUcsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO1lBQzdCLEdBQUcsQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDO1lBQ2hDLGFBQWEsRUFBRTtRQUNqQixDQUFDO0tBQ0Y7QUFDSCxDQUFDO0FBRUQsaUVBQWUscUJBQXFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztVQ3RFcEM7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOzs7OztXQ3pCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDLFdBQVc7V0FDNUM7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsR0FBRztXQUNIO1dBQ0E7V0FDQSxDQUFDOzs7OztXQ1BEOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7V0NOQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7Ozs7V0NsQkE7O1dBRUE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOzs7OztXQ3JCQTs7Ozs7Ozs7Ozs7Ozs7O0FDQzhCO0FBQ1c7QUFDWDtBQUNpQztBQUUvRCxzQkFBc0I7QUFDdEIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsaUJBQWlCLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxFQUFFO0lBQ3JGLE1BQU0sb0JBQW9CLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBcUI7SUFDM0Ysb0JBQW9CLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxlQUFlLElBQUksS0FBSztJQUU5RCxvQkFBb0IsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxFQUFFLEVBQUUsRUFBRTtRQUNyQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7WUFDdkIsZUFBZSxFQUFHLEVBQUUsQ0FBQyxNQUEyQixDQUFDLE9BQU87U0FDekQsQ0FBQztJQUNKLENBQUM7SUFFRCxNQUFNLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFzQjtJQUN0RixNQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBc0I7SUFDaEYsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQXFCO0lBRXZFLElBQUksTUFBTSxHQUFHLEtBQUs7SUFDbEIsSUFBSSxXQUFXLEdBQUcsS0FBSztJQUV2QixJQUFJLE1BQU0sQ0FBQyxLQUFLLEtBQUssTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxNQUFNLENBQUMsSUFBSSxNQUFNLENBQUMsVUFBVSxDQUFDLDhCQUE4QixDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDbEgsTUFBTSxHQUFHLElBQUk7UUFDYixRQUFRLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBQzlDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsTUFBTTtLQUMzQjtTQUFNO1FBQ0wsUUFBUSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUNqRCxXQUFXLENBQUMsS0FBSyxHQUFHLE9BQU87S0FDNUI7SUFFRCxJQUFJLE1BQU0sQ0FBQyxFQUFFLEtBQUssS0FBSyxFQUFFO1FBQ3ZCLFdBQVcsR0FBRyxJQUFJO1FBRWxCLElBQUksTUFBTSxFQUFFO1lBQ1YsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQztTQUNoRDthQUFNO1lBQ0wsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztTQUMzQztRQUNELE9BQU8sQ0FBQyxPQUFPLEdBQUcsSUFBSTtLQUN2QjtTQUFNO1FBQ0wsT0FBTyxDQUFDLE9BQU8sR0FBRyxLQUFLO0tBQ3hCO0lBRUQsT0FBTyxDQUFDLFFBQVEsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFO1FBQ3hCLElBQUssRUFBRSxDQUFDLE1BQTJCLENBQUMsT0FBTyxFQUFFO1lBQzNDLFdBQVcsR0FBRyxJQUFJO1lBRWxCLElBQUksTUFBTSxFQUFFO2dCQUNWLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUM7YUFDaEQ7aUJBQU07Z0JBQ0wsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQzthQUMzQztTQUNGO2FBQU07WUFDTCxXQUFXLEdBQUcsS0FBSztZQUNuQixRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO1lBQzFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUM7U0FDaEQ7UUFDRCxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7WUFDdkIsRUFBRSxFQUFHLEVBQUUsQ0FBQyxNQUEyQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJO1NBQzNELENBQUM7SUFDSixDQUFDO0lBRUQsV0FBVyxDQUFDLFFBQVEsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFO1FBQzVCLE1BQU0sR0FBSSxFQUFFLENBQUMsTUFBMkIsQ0FBQyxLQUFLLEtBQUssTUFBTTtRQUV6RCxJQUFJLFdBQVcsRUFBRTtZQUNmLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7WUFDMUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQztZQUUvQyxJQUFJLE1BQU0sRUFBRTtnQkFDVixRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDO2FBQ2hEO2lCQUFNO2dCQUNMLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7YUFDM0M7U0FDRjtRQUVELFFBQVEsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDakQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFHLEVBQUUsQ0FBQyxNQUEyQixDQUFDLEtBQUssRUFBRSxDQUFDO0lBQzVFLENBQUM7SUFFRCxJQUFJLE1BQU0sQ0FBQyxXQUFXLEVBQUU7UUFDdEIsaUJBQWlCLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxXQUFXO0tBQzdDO0lBRUQsaUJBQWlCLENBQUMsUUFBUSxHQUFHLENBQUMsRUFBRSxFQUFFLEVBQUU7UUFDbEMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsV0FBVyxFQUFHLEVBQUUsQ0FBQyxNQUEyQixDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ2xGLENBQUM7QUFDSCxDQUFDLENBQUM7QUFFRixxQkFBcUI7QUFDckIsTUFBTSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixFQUFFLEdBQUcsRUFBRTtJQUMvQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQ3RCO1FBQ0UsZUFBZSxFQUFFO1lBQ2YsVUFBVSxFQUFFLEtBQUs7WUFDakIsU0FBUyxFQUFFLElBQUk7WUFDZixRQUFRLEVBQUUsRUFBRTtZQUNaLFFBQVEsRUFBRSxFQUFFO1lBQ1osRUFBRSxFQUFFLEVBQUU7WUFDTixFQUFFLEVBQUUsRUFBRTtZQUNOLEVBQUUsRUFBRSxFQUFFO1lBQ04sRUFBRSxFQUFFLEVBQUU7WUFDTixFQUFFLEVBQUUsRUFBRTtZQUNOLEVBQUUsRUFBRSxFQUFFO1NBQ1A7S0FDRixFQUNELENBQUMsTUFBTSxFQUFFLEVBQUU7UUFDVCxNQUFNLGVBQWUsR0FBRyxNQUFNLENBQUMsZUFBZTtRQUM5QyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQztRQUU1QixNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBb0I7UUFDeEUsTUFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQXFCO1FBQzlFLE1BQU0sYUFBYSxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFxQjtRQUVoRixNQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBcUI7UUFDeEUsTUFBTSxpQkFBaUIsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLHdCQUF3QixDQUFxQjtRQUUvRixNQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBcUI7UUFDeEUsTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQXFCO1FBQ3RFLE1BQU0sRUFBRSxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFxQjtRQUN0RSxNQUFNLEVBQUUsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFxQjtRQUN4RSxNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBcUI7UUFFOUQsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFDLHdCQUF3QixDQUFpQztRQUNyRyxNQUFNLGNBQWMsR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsNEJBQTRCLENBQWtDO1FBRS9HLFNBQVM7UUFDVCxNQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBbUI7UUFDbEUsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBZ0I7UUFDekUsTUFBTSxrQkFBa0IsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBcUI7UUFFbkYsUUFBUSxDQUFDLEtBQUssR0FBRyxlQUFlLENBQUMsUUFBUSxJQUFJLEVBQUU7UUFDL0MsUUFBUSxDQUFDLEtBQUssR0FBRyxlQUFlLENBQUMsUUFBUSxJQUFJLEVBQUU7UUFDL0MsRUFBRSxDQUFDLEtBQUssR0FBRyxlQUFlLENBQUMsRUFBRSxJQUFJLEVBQUU7UUFDbkMsRUFBRSxDQUFDLEtBQUssR0FBRyxlQUFlLENBQUMsRUFBRSxJQUFJLEVBQUU7UUFDbkMsRUFBRSxDQUFDLEtBQUssR0FBRyxlQUFlLENBQUMsRUFBRSxJQUFJLEVBQUU7UUFDbkMsRUFBRSxDQUFDLFdBQVcsR0FBRyxlQUFlLENBQUMsRUFBRSxJQUFJLHFCQUFxQjtRQUM1RCxFQUFFLENBQUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxFQUFFLElBQUkscUJBQXFCO1FBQzVELEVBQUUsQ0FBQyxXQUFXLEdBQUcsZUFBZSxDQUFDLEVBQUUsSUFBSSxxQkFBcUI7UUFDNUQsa0JBQWtCLENBQUMsT0FBTyxHQUFHLGVBQWUsQ0FBQyxTQUFTO1FBRXRELElBQUksZUFBZSxDQUFDLFFBQVEsS0FBSyxFQUFFLEVBQUU7WUFDbkMsdUVBQU0sQ0FBQyxtQkFBbUIsQ0FBQztZQUMzQixRQUFRLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQztZQUNwQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDO1NBQzlDO2FBQU07WUFDTCx1RUFBTSxDQUFDLG9CQUFvQixlQUFlLENBQUMsUUFBUSxFQUFFLEVBQUUsU0FBUyxDQUFDO1lBRWpFLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU07WUFDMUIsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQWdCO1lBQzVELFNBQVMsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDO1lBQ3BELElBQUksZUFBZSxDQUFDLFVBQVU7Z0JBQUUsU0FBUyxDQUFDLFNBQVMsR0FBRyxlQUFlOztnQkFDaEUsU0FBUyxDQUFDLFNBQVMsR0FBRyxtQkFBbUI7WUFFOUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7U0FDckI7UUFFRCxNQUFNLGdCQUFnQixHQUNwQixlQUFlLENBQUMsUUFBUSxLQUFLLEVBQUU7WUFDL0IsZUFBZSxDQUFDLFFBQVEsS0FBSyxFQUFFO1lBQy9CLGVBQWUsQ0FBQyxFQUFFLEtBQUssRUFBRTtZQUN6QixlQUFlLENBQUMsRUFBRSxLQUFLLHFCQUFxQjtZQUM1QyxlQUFlLENBQUMsRUFBRSxLQUFLLEVBQUU7WUFDekIsZUFBZSxDQUFDLEVBQUUsS0FBSyxxQkFBcUI7WUFDNUMsZUFBZSxDQUFDLEVBQUUsS0FBSyxFQUFFO1lBQ3pCLGVBQWUsQ0FBQyxFQUFFLEtBQUsscUJBQXFCO1FBRTlDLElBQUksZ0JBQWdCLEVBQUU7WUFDcEIsU0FBUyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO1NBQ3pDO1FBRUQsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQ2hDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFO1lBQ3BDLFNBQVMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztRQUMxQyxDQUFDLENBQUMsQ0FDSDtRQUVELGtCQUFrQixDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxDQUFDLENBQVEsRUFBRSxFQUFFO1lBQ3pELE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUEwQjtZQUUzQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsTUFBTSxDQUFDLEVBQUUsR0FBRyxFQUFFLGVBQWUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDN0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLE1BQU0sQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO1lBRW5ELGVBQWUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE9BQU87WUFDM0MsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO2dCQUN2QixlQUFlLEVBQUUsZUFBNkI7YUFDL0MsQ0FBQztRQUNKLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFDLENBQUMsQ0FBQyxjQUFjLEVBQUU7WUFFbEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTTtZQUM3QixVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNkLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU07WUFDL0IsQ0FBQyxFQUFFLEdBQUcsQ0FBQztZQUVQLElBQUksR0FBRyxDQUFDLEtBQUssRUFBRTtnQkFDYixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNO2dCQUMxQixNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQztnQkFDakQsU0FBUyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsbUJBQW1CLENBQUM7Z0JBQ3BELFNBQVMsQ0FBQyxTQUFTLEdBQUcsYUFBYTtnQkFDbkMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7Z0JBRXBCLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7b0JBQ2pELHdEQUFPLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDO29CQUM1Qix3REFBTyxDQUFDLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQztvQkFDNUIsd0RBQU8sQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUM7b0JBQzVCLHdEQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDO2lCQUNuQyxDQUFDO2dCQUVGLE1BQU0sYUFBYSxHQUFlO29CQUNoQyxTQUFTLEVBQUUsZUFBZSxDQUFDLFNBQVM7b0JBQ3BDLFFBQVEsRUFBRSxRQUFRLENBQUMsS0FBSztvQkFDeEIsRUFBRSxFQUFFLEVBQUUsQ0FBQyxXQUFXO29CQUNsQixFQUFFLEVBQUUsRUFBRSxDQUFDLFdBQVc7b0JBQ2xCLEVBQUUsRUFBRSxFQUFFLENBQUMsV0FBVztvQkFDbEIsVUFBVSxFQUFFLElBQUk7b0JBQ2hCLFFBQVEsRUFBRSxJQUFJO29CQUNkLEVBQUUsRUFBRSxJQUFJO29CQUNSLEVBQUUsRUFBRSxJQUFJO29CQUNSLEVBQUUsRUFBRSxJQUFJO2lCQUNUO2dCQUVELE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLGVBQWUsRUFBRSxhQUFhLEVBQUUsRUFBRSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDdEY7aUJBQU07Z0JBQ0wsTUFBTSxXQUFXLEdBQUc7b0JBQ2xCLFNBQVMsRUFBRSxlQUFlLENBQUMsU0FBUztvQkFDcEMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxLQUFLO29CQUN4QixFQUFFLEVBQUUsRUFBRSxDQUFDLFdBQVc7b0JBQ2xCLEVBQUUsRUFBRSxFQUFFLENBQUMsV0FBVztvQkFDbEIsRUFBRSxFQUFFLEVBQUUsQ0FBQyxXQUFXO29CQUNsQixVQUFVLEVBQUUsS0FBSztvQkFDakIsUUFBUSxFQUFFLFFBQVEsQ0FBQyxLQUFLO29CQUN4QixFQUFFLEVBQUUsRUFBRSxDQUFDLEtBQUs7b0JBQ1osRUFBRSxFQUFFLEVBQUUsQ0FBQyxLQUFLO29CQUNaLEVBQUUsRUFBRSxFQUFFLENBQUMsS0FBSztpQkFDYjtnQkFFRCxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxlQUFlLEVBQUUsV0FBVyxFQUFFLEVBQUUsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO2FBQ3BGO1FBQ0gsQ0FBQyxDQUFDO1FBRUYsWUFBWSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQzNDLENBQUMsQ0FBQyxjQUFjLEVBQUU7WUFFbEIsdUVBQU0sQ0FDSixlQUFlLEVBQ2YsU0FBUyxFQUNULElBQUksRUFDSixHQUFHLEVBQUU7Z0JBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ2xCLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO2dCQUN6QixNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLEdBQUcsRUFBRTtvQkFDcEQsUUFBUSxDQUFDLE1BQU0sRUFBRTtnQkFDbkIsQ0FBQyxDQUFDO1lBQ0osQ0FBQyxFQUNELEdBQUcsRUFBRTtnQkFDSCx1RUFBTSxDQUFDLFlBQVksQ0FBQztZQUN0QixDQUFDLENBQ0Y7UUFDSCxDQUFDLENBQUM7UUFFRixRQUFRLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDdkMsQ0FBQyxDQUFDLGNBQWMsRUFBRTtZQUVsQixJQUFJLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDL0IsSUFBSSxRQUFRLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssRUFBRSxFQUFFO29CQUMvRCxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUN6QixDQUFDLENBQUMsV0FBVyxHQUFHLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUM1QyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7d0JBQ1osQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJO29CQUNuQixDQUFDLENBQUM7b0JBRUYsUUFBUSxDQUFDLEtBQUssR0FBRyxFQUFFO29CQUNuQixHQUFHLENBQUMsS0FBSyxHQUFHLEVBQUU7b0JBRWQsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJO29CQUN4QixHQUFHLENBQUMsUUFBUSxHQUFHLElBQUk7aUJBQ3BCO2dCQUVELE9BQU07YUFDUDtRQUNILENBQUMsQ0FBQztRQUVGLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdEQsQ0FBQyxDQUFDLGNBQWMsRUFBRTtZQUVsQix1RUFBTSxDQUFDLDRCQUE0QixDQUFDO1lBRXBDLE1BQU0sT0FBTyxHQUFHLElBQUksb0RBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUdyQztZQUVELE9BQU8sQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQVksRUFBRSxFQUFFO2dCQUNqRCxJQUFJLEdBQUcsS0FBSyxLQUFLLEVBQUU7b0JBQ2pCLHVFQUFNLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDO2lCQUNuQztxQkFBTTtvQkFDTCx1RUFBTSxDQUFDLG9CQUFvQixFQUFFLFNBQVMsQ0FBQztvQkFDdkMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUM7b0JBQ3BDLEdBQUcsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDO29CQUMvQixhQUFhLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQztpQkFDMUM7WUFDSCxDQUFDLENBQUM7WUFFRixJQUFJLEdBQUcsR0FBRyxDQUFDO1lBQ1gsT0FBTyxDQUFDLGlCQUFpQixHQUFHLENBQUMsQ0FBUyxFQUFFLEVBQUU7Z0JBQ3hDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDO2dCQUMxQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxHQUFHLENBQUM7Z0JBQzlCLEdBQUcsRUFBRTtZQUNQLENBQUM7UUFDSCxDQUFDLENBQUM7UUFFRixVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTTtRQUMvQixDQUFDLEVBQUUsR0FBRyxDQUFDO0lBQ1QsQ0FBQyxDQUNGO0FBQ0gsQ0FBQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXV0by1sb2dpbi1lcnAvLi9zcmMvcGFnZXMvUG9wdXAvc3R5bGUuY3NzIiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwLy4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qcyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC8uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9nZXRVcmwuanMiLCJ3ZWJwYWNrOi8vYXV0by1sb2dpbi1lcnAvLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvc291cmNlTWFwcy5qcyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC8uL3NyYy9wYWdlcy9Qb3B1cC9zdHlsZS5jc3M/MGRmZSIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC8uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qcyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC8uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydEJ5U2VsZWN0b3IuanMiLCJ3ZWJwYWNrOi8vYXV0by1sb2dpbi1lcnAvLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanMiLCJ3ZWJwYWNrOi8vYXV0by1sb2dpbi1lcnAvLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanMiLCJ3ZWJwYWNrOi8vYXV0by1sb2dpbi1lcnAvLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qcyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC8uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlVGFnVHJhbnNmb3JtLmpzIiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwLy4vc3JjL3NlcnZpY2VzL2NyeXB0by50cyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC8uL3NyYy9zZXJ2aWNlcy9lcnAudHMiLCJ3ZWJwYWNrOi8vYXV0by1sb2dpbi1lcnAvLi9zcmMvdXRpbHMvZGlzcGxheU1lc3NhZ2VPblBvcHVwLnRzIiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwL3dlYnBhY2svcnVudGltZS9jb21wYXQgZ2V0IGRlZmF1bHQgZXhwb3J0Iiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC93ZWJwYWNrL3J1bnRpbWUvZ2xvYmFsIiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwL3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vYXV0by1sb2dpbi1lcnAvd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC93ZWJwYWNrL3J1bnRpbWUvcHVibGljUGF0aCIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC93ZWJwYWNrL3J1bnRpbWUvanNvbnAgY2h1bmsgbG9hZGluZyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC93ZWJwYWNrL3J1bnRpbWUvbm9uY2UiLCJ3ZWJwYWNrOi8vYXV0by1sb2dpbi1lcnAvLi9zcmMvcGFnZXMvUG9wdXAvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9HRVRfVVJMX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2dldFVybC5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF8wX19fID0gbmV3IFVSTChcImRhdGE6aW1hZ2Uvc3ZnK3htbCwlM2NzdmcgeG1sbnM9JTI3aHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmclMjcgZmlsbD0lMjdub25lJTI3IHZpZXdCb3g9JTI3MCAwIDIwIDIwJTI3JTNlJTNjcGF0aCBzdHJva2U9JTI3JTIzNmI3MjgwJTI3IHN0cm9rZS1saW5lY2FwPSUyN3JvdW5kJTI3IHN0cm9rZS1saW5lam9pbj0lMjdyb3VuZCUyNyBzdHJva2Utd2lkdGg9JTI3MS41JTI3IGQ9JTI3TTYgOGw0IDQgNC00JTI3LyUzZSUzYy9zdmclM2VcIiwgaW1wb3J0Lm1ldGEudXJsKTtcbnZhciBfX19DU1NfTE9BREVSX1VSTF9JTVBPUlRfMV9fXyA9IG5ldyBVUkwoXCJkYXRhOmltYWdlL3N2Zyt4bWwsJTNjc3ZnIHZpZXdCb3g9JTI3MCAwIDE2IDE2JTI3IGZpbGw9JTI3d2hpdGUlMjcgeG1sbnM9JTI3aHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmclMjclM2UlM2NwYXRoIGQ9JTI3TTEyLjIwNyA0Ljc5M2ExIDEgMCAwMTAgMS40MTRsLTUgNWExIDEgMCAwMS0xLjQxNCAwbC0yLTJhMSAxIDAgMDExLjQxNC0xLjQxNEw2LjUgOS4wODZsNC4yOTMtNC4yOTNhMSAxIDAgMDExLjQxNCAweiUyNy8lM2UlM2Mvc3ZnJTNlXCIsIGltcG9ydC5tZXRhLnVybCk7XG52YXIgX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzJfX18gPSBuZXcgVVJMKFwiZGF0YTppbWFnZS9zdmcreG1sLCUzY3N2ZyB2aWV3Qm94PSUyNzAgMCAxNiAxNiUyNyBmaWxsPSUyN3doaXRlJTI3IHhtbG5zPSUyN2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJTI3JTNlJTNjY2lyY2xlIGN4PSUyNzglMjcgY3k9JTI3OCUyNyByPSUyNzMlMjcvJTNlJTNjL3N2ZyUzZVwiLCBpbXBvcnQubWV0YS51cmwpO1xudmFyIF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF8zX19fID0gbmV3IFVSTChcImRhdGE6aW1hZ2Uvc3ZnK3htbCwlM2NzdmcgeG1sbnM9JTI3aHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmclMjcgZmlsbD0lMjdub25lJTI3IHZpZXdCb3g9JTI3MCAwIDE2IDE2JTI3JTNlJTNjcGF0aCBzdHJva2U9JTI3d2hpdGUlMjcgc3Ryb2tlLWxpbmVjYXA9JTI3cm91bmQlMjcgc3Ryb2tlLWxpbmVqb2luPSUyN3JvdW5kJTI3IHN0cm9rZS13aWR0aD0lMjcyJTI3IGQ9JTI3TTQgOGg4JTI3LyUzZSUzYy9zdmclM2VcIiwgaW1wb3J0Lm1ldGEudXJsKTtcbnZhciBfX19DU1NfTE9BREVSX1VSTF9JTVBPUlRfNF9fXyA9IG5ldyBVUkwoXCIuLi8uLi9hc3NldHMvaW1hZ2VzL2lpdGtncC1sb2dvLnN2Z1wiLCBpbXBvcnQubWV0YS51cmwpO1xudmFyIF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF81X19fID0gbmV3IFVSTChcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvYmcuanBnXCIsIGltcG9ydC5tZXRhLnVybCk7XG52YXIgX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzZfX18gPSBuZXcgVVJMKFwiLi4vLi4vYXNzZXRzL2ltYWdlcy9iZy1kYXJrLnBuZ1wiLCBpbXBvcnQubWV0YS51cmwpO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xudmFyIF9fX0NTU19MT0FERVJfVVJMX1JFUExBQ0VNRU5UXzBfX18gPSBfX19DU1NfTE9BREVSX0dFVF9VUkxfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF8wX19fKTtcbnZhciBfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF8xX19fID0gX19fQ1NTX0xPQURFUl9HRVRfVVJMX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX1VSTF9JTVBPUlRfMV9fXyk7XG52YXIgX19fQ1NTX0xPQURFUl9VUkxfUkVQTEFDRU1FTlRfMl9fXyA9IF9fX0NTU19MT0FERVJfR0VUX1VSTF9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzJfX18pO1xudmFyIF9fX0NTU19MT0FERVJfVVJMX1JFUExBQ0VNRU5UXzNfX18gPSBfX19DU1NfTE9BREVSX0dFVF9VUkxfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF8zX19fKTtcbnZhciBfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF80X19fID0gX19fQ1NTX0xPQURFUl9HRVRfVVJMX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX1VSTF9JTVBPUlRfNF9fXyk7XG52YXIgX19fQ1NTX0xPQURFUl9VUkxfUkVQTEFDRU1FTlRfNV9fXyA9IF9fX0NTU19MT0FERVJfR0VUX1VSTF9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzVfX18pO1xudmFyIF9fX0NTU19MT0FERVJfVVJMX1JFUExBQ0VNRU5UXzZfX18gPSBfX19DU1NfTE9BREVSX0dFVF9VUkxfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF82X19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBgLypcbiEgdGFpbHdpbmRjc3MgdjMuMy4zIHwgTUlUIExpY2Vuc2UgfCBodHRwczovL3RhaWx3aW5kY3NzLmNvbVxuKi8vKlxuMS4gUHJldmVudCBwYWRkaW5nIGFuZCBib3JkZXIgZnJvbSBhZmZlY3RpbmcgZWxlbWVudCB3aWR0aC4gKGh0dHBzOi8vZ2l0aHViLmNvbS9tb3pkZXZzL2Nzc3JlbWVkeS9pc3N1ZXMvNClcbjIuIEFsbG93IGFkZGluZyBhIGJvcmRlciB0byBhbiBlbGVtZW50IGJ5IGp1c3QgYWRkaW5nIGEgYm9yZGVyLXdpZHRoLiAoaHR0cHM6Ly9naXRodWIuY29tL3RhaWx3aW5kY3NzL3RhaWx3aW5kY3NzL3B1bGwvMTE2KVxuKi9cblxuKixcbjo6YmVmb3JlLFxuOjphZnRlciB7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7IC8qIDEgKi9cbiAgYm9yZGVyLXdpZHRoOiAwOyAvKiAyICovXG4gIGJvcmRlci1zdHlsZTogc29saWQ7IC8qIDIgKi9cbiAgYm9yZGVyLWNvbG9yOiAjZTVlN2ViOyAvKiAyICovXG59XG5cbjo6YmVmb3JlLFxuOjphZnRlciB7XG4gIC0tdHctY29udGVudDogJyc7XG59XG5cbi8qXG4xLiBVc2UgYSBjb25zaXN0ZW50IHNlbnNpYmxlIGxpbmUtaGVpZ2h0IGluIGFsbCBicm93c2Vycy5cbjIuIFByZXZlbnQgYWRqdXN0bWVudHMgb2YgZm9udCBzaXplIGFmdGVyIG9yaWVudGF0aW9uIGNoYW5nZXMgaW4gaU9TLlxuMy4gVXNlIGEgbW9yZSByZWFkYWJsZSB0YWIgc2l6ZS5cbjQuIFVzZSB0aGUgdXNlcidzIGNvbmZpZ3VyZWQgXFxgc2Fuc1xcYCBmb250LWZhbWlseSBieSBkZWZhdWx0LlxuNS4gVXNlIHRoZSB1c2VyJ3MgY29uZmlndXJlZCBcXGBzYW5zXFxgIGZvbnQtZmVhdHVyZS1zZXR0aW5ncyBieSBkZWZhdWx0LlxuNi4gVXNlIHRoZSB1c2VyJ3MgY29uZmlndXJlZCBcXGBzYW5zXFxgIGZvbnQtdmFyaWF0aW9uLXNldHRpbmdzIGJ5IGRlZmF1bHQuXG4qL1xuXG5odG1sIHtcbiAgbGluZS1oZWlnaHQ6IDEuNTsgLyogMSAqL1xuICAtd2Via2l0LXRleHQtc2l6ZS1hZGp1c3Q6IDEwMCU7IC8qIDIgKi9cbiAgLW1vei10YWItc2l6ZTogNDsgLyogMyAqL1xuICB0YWItc2l6ZTogNDsgLyogMyAqL1xuICBmb250LWZhbWlseTogdWktc2Fucy1zZXJpZiwgc3lzdGVtLXVpLCAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBcIkhlbHZldGljYSBOZXVlXCIsIEFyaWFsLCBcIk5vdG8gU2Fuc1wiLCBzYW5zLXNlcmlmLCBcIkFwcGxlIENvbG9yIEVtb2ppXCIsIFwiU2Vnb2UgVUkgRW1vamlcIiwgXCJTZWdvZSBVSSBTeW1ib2xcIiwgXCJOb3RvIENvbG9yIEVtb2ppXCI7IC8qIDQgKi9cbiAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBub3JtYWw7IC8qIDUgKi9cbiAgZm9udC12YXJpYXRpb24tc2V0dGluZ3M6IG5vcm1hbDsgLyogNiAqL1xufVxuXG4vKlxuMS4gUmVtb3ZlIHRoZSBtYXJnaW4gaW4gYWxsIGJyb3dzZXJzLlxuMi4gSW5oZXJpdCBsaW5lLWhlaWdodCBmcm9tIFxcYGh0bWxcXGAgc28gdXNlcnMgY2FuIHNldCB0aGVtIGFzIGEgY2xhc3MgZGlyZWN0bHkgb24gdGhlIFxcYGh0bWxcXGAgZWxlbWVudC5cbiovXG5cbmJvZHkge1xuICBtYXJnaW46IDA7IC8qIDEgKi9cbiAgbGluZS1oZWlnaHQ6IGluaGVyaXQ7IC8qIDIgKi9cbn1cblxuLypcbjEuIEFkZCB0aGUgY29ycmVjdCBoZWlnaHQgaW4gRmlyZWZveC5cbjIuIENvcnJlY3QgdGhlIGluaGVyaXRhbmNlIG9mIGJvcmRlciBjb2xvciBpbiBGaXJlZm94LiAoaHR0cHM6Ly9idWd6aWxsYS5tb3ppbGxhLm9yZy9zaG93X2J1Zy5jZ2k/aWQ9MTkwNjU1KVxuMy4gRW5zdXJlIGhvcml6b250YWwgcnVsZXMgYXJlIHZpc2libGUgYnkgZGVmYXVsdC5cbiovXG5cbmhyIHtcbiAgaGVpZ2h0OiAwOyAvKiAxICovXG4gIGNvbG9yOiBpbmhlcml0OyAvKiAyICovXG4gIGJvcmRlci10b3Atd2lkdGg6IDFweDsgLyogMyAqL1xufVxuXG4vKlxuQWRkIHRoZSBjb3JyZWN0IHRleHQgZGVjb3JhdGlvbiBpbiBDaHJvbWUsIEVkZ2UsIGFuZCBTYWZhcmkuXG4qL1xuXG5hYmJyOndoZXJlKFt0aXRsZV0pIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmUgZG90dGVkO1xufVxuXG4vKlxuUmVtb3ZlIHRoZSBkZWZhdWx0IGZvbnQgc2l6ZSBhbmQgd2VpZ2h0IGZvciBoZWFkaW5ncy5cbiovXG5cbmgxLFxuaDIsXG5oMyxcbmg0LFxuaDUsXG5oNiB7XG4gIGZvbnQtc2l6ZTogaW5oZXJpdDtcbiAgZm9udC13ZWlnaHQ6IGluaGVyaXQ7XG59XG5cbi8qXG5SZXNldCBsaW5rcyB0byBvcHRpbWl6ZSBmb3Igb3B0LWluIHN0eWxpbmcgaW5zdGVhZCBvZiBvcHQtb3V0LlxuKi9cblxuYSB7XG4gIGNvbG9yOiBpbmhlcml0O1xuICB0ZXh0LWRlY29yYXRpb246IGluaGVyaXQ7XG59XG5cbi8qXG5BZGQgdGhlIGNvcnJlY3QgZm9udCB3ZWlnaHQgaW4gRWRnZSBhbmQgU2FmYXJpLlxuKi9cblxuYixcbnN0cm9uZyB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkZXI7XG59XG5cbi8qXG4xLiBVc2UgdGhlIHVzZXIncyBjb25maWd1cmVkIFxcYG1vbm9cXGAgZm9udCBmYW1pbHkgYnkgZGVmYXVsdC5cbjIuIENvcnJlY3QgdGhlIG9kZCBcXGBlbVxcYCBmb250IHNpemluZyBpbiBhbGwgYnJvd3NlcnMuXG4qL1xuXG5jb2RlLFxua2JkLFxuc2FtcCxcbnByZSB7XG4gIGZvbnQtZmFtaWx5OiB1aS1tb25vc3BhY2UsIFNGTW9uby1SZWd1bGFyLCBNZW5sbywgTW9uYWNvLCBDb25zb2xhcywgXCJMaWJlcmF0aW9uIE1vbm9cIiwgXCJDb3VyaWVyIE5ld1wiLCBtb25vc3BhY2U7IC8qIDEgKi9cbiAgZm9udC1zaXplOiAxZW07IC8qIDIgKi9cbn1cblxuLypcbkFkZCB0aGUgY29ycmVjdCBmb250IHNpemUgaW4gYWxsIGJyb3dzZXJzLlxuKi9cblxuc21hbGwge1xuICBmb250LXNpemU6IDgwJTtcbn1cblxuLypcblByZXZlbnQgXFxgc3ViXFxgIGFuZCBcXGBzdXBcXGAgZWxlbWVudHMgZnJvbSBhZmZlY3RpbmcgdGhlIGxpbmUgaGVpZ2h0IGluIGFsbCBicm93c2Vycy5cbiovXG5cbnN1YixcbnN1cCB7XG4gIGZvbnQtc2l6ZTogNzUlO1xuICBsaW5lLWhlaWdodDogMDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB2ZXJ0aWNhbC1hbGlnbjogYmFzZWxpbmU7XG59XG5cbnN1YiB7XG4gIGJvdHRvbTogLTAuMjVlbTtcbn1cblxuc3VwIHtcbiAgdG9wOiAtMC41ZW07XG59XG5cbi8qXG4xLiBSZW1vdmUgdGV4dCBpbmRlbnRhdGlvbiBmcm9tIHRhYmxlIGNvbnRlbnRzIGluIENocm9tZSBhbmQgU2FmYXJpLiAoaHR0cHM6Ly9idWdzLmNocm9taXVtLm9yZy9wL2Nocm9taXVtL2lzc3Vlcy9kZXRhaWw/aWQ9OTk5MDg4LCBodHRwczovL2J1Z3Mud2Via2l0Lm9yZy9zaG93X2J1Zy5jZ2k/aWQ9MjAxMjk3KVxuMi4gQ29ycmVjdCB0YWJsZSBib3JkZXIgY29sb3IgaW5oZXJpdGFuY2UgaW4gYWxsIENocm9tZSBhbmQgU2FmYXJpLiAoaHR0cHM6Ly9idWdzLmNocm9taXVtLm9yZy9wL2Nocm9taXVtL2lzc3Vlcy9kZXRhaWw/aWQ9OTM1NzI5LCBodHRwczovL2J1Z3Mud2Via2l0Lm9yZy9zaG93X2J1Zy5jZ2k/aWQ9MTk1MDE2KVxuMy4gUmVtb3ZlIGdhcHMgYmV0d2VlbiB0YWJsZSBib3JkZXJzIGJ5IGRlZmF1bHQuXG4qL1xuXG50YWJsZSB7XG4gIHRleHQtaW5kZW50OiAwOyAvKiAxICovXG4gIGJvcmRlci1jb2xvcjogaW5oZXJpdDsgLyogMiAqL1xuICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlOyAvKiAzICovXG59XG5cbi8qXG4xLiBDaGFuZ2UgdGhlIGZvbnQgc3R5bGVzIGluIGFsbCBicm93c2Vycy5cbjIuIFJlbW92ZSB0aGUgbWFyZ2luIGluIEZpcmVmb3ggYW5kIFNhZmFyaS5cbjMuIFJlbW92ZSBkZWZhdWx0IHBhZGRpbmcgaW4gYWxsIGJyb3dzZXJzLlxuKi9cblxuYnV0dG9uLFxuaW5wdXQsXG5vcHRncm91cCxcbnNlbGVjdCxcbnRleHRhcmVhIHtcbiAgZm9udC1mYW1pbHk6IGluaGVyaXQ7IC8qIDEgKi9cbiAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBpbmhlcml0OyAvKiAxICovXG4gIGZvbnQtdmFyaWF0aW9uLXNldHRpbmdzOiBpbmhlcml0OyAvKiAxICovXG4gIGZvbnQtc2l6ZTogMTAwJTsgLyogMSAqL1xuICBmb250LXdlaWdodDogaW5oZXJpdDsgLyogMSAqL1xuICBsaW5lLWhlaWdodDogaW5oZXJpdDsgLyogMSAqL1xuICBjb2xvcjogaW5oZXJpdDsgLyogMSAqL1xuICBtYXJnaW46IDA7IC8qIDIgKi9cbiAgcGFkZGluZzogMDsgLyogMyAqL1xufVxuXG4vKlxuUmVtb3ZlIHRoZSBpbmhlcml0YW5jZSBvZiB0ZXh0IHRyYW5zZm9ybSBpbiBFZGdlIGFuZCBGaXJlZm94LlxuKi9cblxuYnV0dG9uLFxuc2VsZWN0IHtcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG59XG5cbi8qXG4xLiBDb3JyZWN0IHRoZSBpbmFiaWxpdHkgdG8gc3R5bGUgY2xpY2thYmxlIHR5cGVzIGluIGlPUyBhbmQgU2FmYXJpLlxuMi4gUmVtb3ZlIGRlZmF1bHQgYnV0dG9uIHN0eWxlcy5cbiovXG5cbmJ1dHRvbixcblt0eXBlPSdidXR0b24nXSxcblt0eXBlPSdyZXNldCddLFxuW3R5cGU9J3N1Ym1pdCddIHtcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBidXR0b247IC8qIDEgKi9cbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7IC8qIDIgKi9cbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTsgLyogMiAqL1xufVxuXG4vKlxuVXNlIHRoZSBtb2Rlcm4gRmlyZWZveCBmb2N1cyBzdHlsZSBmb3IgYWxsIGZvY3VzYWJsZSBlbGVtZW50cy5cbiovXG5cbjotbW96LWZvY3VzcmluZyB7XG4gIG91dGxpbmU6IGF1dG87XG59XG5cbi8qXG5SZW1vdmUgdGhlIGFkZGl0aW9uYWwgXFxgOmludmFsaWRcXGAgc3R5bGVzIGluIEZpcmVmb3guIChodHRwczovL2dpdGh1Yi5jb20vbW96aWxsYS9nZWNrby1kZXYvYmxvYi8yZjllYWNkOWQzZDk5NWM5MzdiNDI1MWE1NTU3ZDk1ZDQ5NGM5YmUxL2xheW91dC9zdHlsZS9yZXMvZm9ybXMuY3NzI0w3MjgtTDczNylcbiovXG5cbjotbW96LXVpLWludmFsaWQge1xuICBib3gtc2hhZG93OiBub25lO1xufVxuXG4vKlxuQWRkIHRoZSBjb3JyZWN0IHZlcnRpY2FsIGFsaWdubWVudCBpbiBDaHJvbWUgYW5kIEZpcmVmb3guXG4qL1xuXG5wcm9ncmVzcyB7XG4gIHZlcnRpY2FsLWFsaWduOiBiYXNlbGluZTtcbn1cblxuLypcbkNvcnJlY3QgdGhlIGN1cnNvciBzdHlsZSBvZiBpbmNyZW1lbnQgYW5kIGRlY3JlbWVudCBidXR0b25zIGluIFNhZmFyaS5cbiovXG5cbjo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixcbjo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7XG4gIGhlaWdodDogYXV0bztcbn1cblxuLypcbjEuIENvcnJlY3QgdGhlIG9kZCBhcHBlYXJhbmNlIGluIENocm9tZSBhbmQgU2FmYXJpLlxuMi4gQ29ycmVjdCB0aGUgb3V0bGluZSBzdHlsZSBpbiBTYWZhcmkuXG4qL1xuXG5bdHlwZT0nc2VhcmNoJ10ge1xuICAtd2Via2l0LWFwcGVhcmFuY2U6IHRleHRmaWVsZDsgLyogMSAqL1xuICBvdXRsaW5lLW9mZnNldDogLTJweDsgLyogMiAqL1xufVxuXG4vKlxuUmVtb3ZlIHRoZSBpbm5lciBwYWRkaW5nIGluIENocm9tZSBhbmQgU2FmYXJpIG9uIG1hY09TLlxuKi9cblxuOjotd2Via2l0LXNlYXJjaC1kZWNvcmF0aW9uIHtcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xufVxuXG4vKlxuMS4gQ29ycmVjdCB0aGUgaW5hYmlsaXR5IHRvIHN0eWxlIGNsaWNrYWJsZSB0eXBlcyBpbiBpT1MgYW5kIFNhZmFyaS5cbjIuIENoYW5nZSBmb250IHByb3BlcnRpZXMgdG8gXFxgaW5oZXJpdFxcYCBpbiBTYWZhcmkuXG4qL1xuXG46Oi13ZWJraXQtZmlsZS11cGxvYWQtYnV0dG9uIHtcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBidXR0b247IC8qIDEgKi9cbiAgZm9udDogaW5oZXJpdDsgLyogMiAqL1xufVxuXG4vKlxuQWRkIHRoZSBjb3JyZWN0IGRpc3BsYXkgaW4gQ2hyb21lIGFuZCBTYWZhcmkuXG4qL1xuXG5zdW1tYXJ5IHtcbiAgZGlzcGxheTogbGlzdC1pdGVtO1xufVxuXG4vKlxuUmVtb3ZlcyB0aGUgZGVmYXVsdCBzcGFjaW5nIGFuZCBib3JkZXIgZm9yIGFwcHJvcHJpYXRlIGVsZW1lbnRzLlxuKi9cblxuYmxvY2txdW90ZSxcbmRsLFxuZGQsXG5oMSxcbmgyLFxuaDMsXG5oNCxcbmg1LFxuaDYsXG5ocixcbmZpZ3VyZSxcbnAsXG5wcmUge1xuICBtYXJnaW46IDA7XG59XG5cbmZpZWxkc2V0IHtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xufVxuXG5sZWdlbmQge1xuICBwYWRkaW5nOiAwO1xufVxuXG5vbCxcbnVsLFxubWVudSB7XG4gIGxpc3Qtc3R5bGU6IG5vbmU7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZzogMDtcbn1cblxuLypcblJlc2V0IGRlZmF1bHQgc3R5bGluZyBmb3IgZGlhbG9ncy5cbiovXG5kaWFsb2cge1xuICBwYWRkaW5nOiAwO1xufVxuXG4vKlxuUHJldmVudCByZXNpemluZyB0ZXh0YXJlYXMgaG9yaXpvbnRhbGx5IGJ5IGRlZmF1bHQuXG4qL1xuXG50ZXh0YXJlYSB7XG4gIHJlc2l6ZTogdmVydGljYWw7XG59XG5cbi8qXG4xLiBSZXNldCB0aGUgZGVmYXVsdCBwbGFjZWhvbGRlciBvcGFjaXR5IGluIEZpcmVmb3guIChodHRwczovL2dpdGh1Yi5jb20vdGFpbHdpbmRsYWJzL3RhaWx3aW5kY3NzL2lzc3Vlcy8zMzAwKVxuMi4gU2V0IHRoZSBkZWZhdWx0IHBsYWNlaG9sZGVyIGNvbG9yIHRvIHRoZSB1c2VyJ3MgY29uZmlndXJlZCBncmF5IDQwMCBjb2xvci5cbiovXG5cbmlucHV0OjpwbGFjZWhvbGRlcixcbnRleHRhcmVhOjpwbGFjZWhvbGRlciB7XG4gIG9wYWNpdHk6IDE7IC8qIDEgKi9cbiAgY29sb3I6ICM5Y2EzYWY7IC8qIDIgKi9cbn1cblxuLypcblNldCB0aGUgZGVmYXVsdCBjdXJzb3IgZm9yIGJ1dHRvbnMuXG4qL1xuXG5idXR0b24sXG5bcm9sZT1cImJ1dHRvblwiXSB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLypcbk1ha2Ugc3VyZSBkaXNhYmxlZCBidXR0b25zIGRvbid0IGdldCB0aGUgcG9pbnRlciBjdXJzb3IuXG4qL1xuOmRpc2FibGVkIHtcbiAgY3Vyc29yOiBkZWZhdWx0O1xufVxuXG4vKlxuMS4gTWFrZSByZXBsYWNlZCBlbGVtZW50cyBcXGBkaXNwbGF5OiBibG9ja1xcYCBieSBkZWZhdWx0LiAoaHR0cHM6Ly9naXRodWIuY29tL21vemRldnMvY3NzcmVtZWR5L2lzc3Vlcy8xNClcbjIuIEFkZCBcXGB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlXFxgIHRvIGFsaWduIHJlcGxhY2VkIGVsZW1lbnRzIG1vcmUgc2Vuc2libHkgYnkgZGVmYXVsdC4gKGh0dHBzOi8vZ2l0aHViLmNvbS9qZW5zaW1tb25zL2Nzc3JlbWVkeS9pc3N1ZXMvMTQjaXNzdWVjb21tZW50LTYzNDkzNDIxMClcbiAgIFRoaXMgY2FuIHRyaWdnZXIgYSBwb29ybHkgY29uc2lkZXJlZCBsaW50IGVycm9yIGluIHNvbWUgdG9vbHMgYnV0IGlzIGluY2x1ZGVkIGJ5IGRlc2lnbi5cbiovXG5cbmltZyxcbnN2ZyxcbnZpZGVvLFxuY2FudmFzLFxuYXVkaW8sXG5pZnJhbWUsXG5lbWJlZCxcbm9iamVjdCB7XG4gIGRpc3BsYXk6IGJsb2NrOyAvKiAxICovXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7IC8qIDIgKi9cbn1cblxuLypcbkNvbnN0cmFpbiBpbWFnZXMgYW5kIHZpZGVvcyB0byB0aGUgcGFyZW50IHdpZHRoIGFuZCBwcmVzZXJ2ZSB0aGVpciBpbnRyaW5zaWMgYXNwZWN0IHJhdGlvLiAoaHR0cHM6Ly9naXRodWIuY29tL21vemRldnMvY3NzcmVtZWR5L2lzc3Vlcy8xNClcbiovXG5cbmltZyxcbnZpZGVvIHtcbiAgbWF4LXdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IGF1dG87XG59XG5cbi8qIE1ha2UgZWxlbWVudHMgd2l0aCB0aGUgSFRNTCBoaWRkZW4gYXR0cmlidXRlIHN0YXkgaGlkZGVuIGJ5IGRlZmF1bHQgKi9cbltoaWRkZW5dIHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuW3R5cGU9J3RleHQnXSxpbnB1dDp3aGVyZSg6bm90KFt0eXBlXSkpLFt0eXBlPSdlbWFpbCddLFt0eXBlPSd1cmwnXSxbdHlwZT0ncGFzc3dvcmQnXSxbdHlwZT0nbnVtYmVyJ10sW3R5cGU9J2RhdGUnXSxbdHlwZT0nZGF0ZXRpbWUtbG9jYWwnXSxbdHlwZT0nbW9udGgnXSxbdHlwZT0nc2VhcmNoJ10sW3R5cGU9J3RlbCddLFt0eXBlPSd0aW1lJ10sW3R5cGU9J3dlZWsnXSxbbXVsdGlwbGVdLHRleHRhcmVhLHNlbGVjdCB7XG4gIGFwcGVhcmFuY2U6IG5vbmU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIGJvcmRlci1jb2xvcjogIzZiNzI4MDtcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XG4gIGJvcmRlci1yYWRpdXM6IDBweDtcbiAgcGFkZGluZy10b3A6IDAuNXJlbTtcbiAgcGFkZGluZy1yaWdodDogMC43NXJlbTtcbiAgcGFkZGluZy1ib3R0b206IDAuNXJlbTtcbiAgcGFkZGluZy1sZWZ0OiAwLjc1cmVtO1xuICBmb250LXNpemU6IDFyZW07XG4gIGxpbmUtaGVpZ2h0OiAxLjVyZW07XG4gIC0tdHctc2hhZG93OiAwIDAgIzAwMDA7XG59XG5cblt0eXBlPSd0ZXh0J106Zm9jdXMsIGlucHV0OndoZXJlKDpub3QoW3R5cGVdKSk6Zm9jdXMsIFt0eXBlPSdlbWFpbCddOmZvY3VzLCBbdHlwZT0ndXJsJ106Zm9jdXMsIFt0eXBlPSdwYXNzd29yZCddOmZvY3VzLCBbdHlwZT0nbnVtYmVyJ106Zm9jdXMsIFt0eXBlPSdkYXRlJ106Zm9jdXMsIFt0eXBlPSdkYXRldGltZS1sb2NhbCddOmZvY3VzLCBbdHlwZT0nbW9udGgnXTpmb2N1cywgW3R5cGU9J3NlYXJjaCddOmZvY3VzLCBbdHlwZT0ndGVsJ106Zm9jdXMsIFt0eXBlPSd0aW1lJ106Zm9jdXMsIFt0eXBlPSd3ZWVrJ106Zm9jdXMsIFttdWx0aXBsZV06Zm9jdXMsIHRleHRhcmVhOmZvY3VzLCBzZWxlY3Q6Zm9jdXMge1xuICBvdXRsaW5lOiAycHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIG91dGxpbmUtb2Zmc2V0OiAycHg7XG4gIC0tdHctcmluZy1pbnNldDogdmFyKC0tdHctZW1wdHksLyohKi8gLyohKi8pO1xuICAtLXR3LXJpbmctb2Zmc2V0LXdpZHRoOiAwcHg7XG4gIC0tdHctcmluZy1vZmZzZXQtY29sb3I6ICNmZmY7XG4gIC0tdHctcmluZy1jb2xvcjogIzI1NjNlYjtcbiAgLS10dy1yaW5nLW9mZnNldC1zaGFkb3c6IHZhcigtLXR3LXJpbmctaW5zZXQpIDAgMCAwIHZhcigtLXR3LXJpbmctb2Zmc2V0LXdpZHRoKSB2YXIoLS10dy1yaW5nLW9mZnNldC1jb2xvcik7XG4gIC0tdHctcmluZy1zaGFkb3c6IHZhcigtLXR3LXJpbmctaW5zZXQpIDAgMCAwIGNhbGMoMXB4ICsgdmFyKC0tdHctcmluZy1vZmZzZXQtd2lkdGgpKSB2YXIoLS10dy1yaW5nLWNvbG9yKTtcbiAgYm94LXNoYWRvdzogdmFyKC0tdHctcmluZy1vZmZzZXQtc2hhZG93KSwgdmFyKC0tdHctcmluZy1zaGFkb3cpLCB2YXIoLS10dy1zaGFkb3cpO1xuICBib3JkZXItY29sb3I6ICMyNTYzZWI7XG59XG5cbmlucHV0OjpwbGFjZWhvbGRlcix0ZXh0YXJlYTo6cGxhY2Vob2xkZXIge1xuICBjb2xvcjogIzZiNzI4MDtcbiAgb3BhY2l0eTogMTtcbn1cblxuOjotd2Via2l0LWRhdGV0aW1lLWVkaXQtZmllbGRzLXdyYXBwZXIge1xuICBwYWRkaW5nOiAwO1xufVxuXG46Oi13ZWJraXQtZGF0ZS1hbmQtdGltZS12YWx1ZSB7XG4gIG1pbi1oZWlnaHQ6IDEuNWVtO1xufVxuXG46Oi13ZWJraXQtZGF0ZXRpbWUtZWRpdCw6Oi13ZWJraXQtZGF0ZXRpbWUtZWRpdC15ZWFyLWZpZWxkLDo6LXdlYmtpdC1kYXRldGltZS1lZGl0LW1vbnRoLWZpZWxkLDo6LXdlYmtpdC1kYXRldGltZS1lZGl0LWRheS1maWVsZCw6Oi13ZWJraXQtZGF0ZXRpbWUtZWRpdC1ob3VyLWZpZWxkLDo6LXdlYmtpdC1kYXRldGltZS1lZGl0LW1pbnV0ZS1maWVsZCw6Oi13ZWJraXQtZGF0ZXRpbWUtZWRpdC1zZWNvbmQtZmllbGQsOjotd2Via2l0LWRhdGV0aW1lLWVkaXQtbWlsbGlzZWNvbmQtZmllbGQsOjotd2Via2l0LWRhdGV0aW1lLWVkaXQtbWVyaWRpZW0tZmllbGQge1xuICBwYWRkaW5nLXRvcDogMDtcbiAgcGFkZGluZy1ib3R0b206IDA7XG59XG5cbnNlbGVjdCB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCgke19fX0NTU19MT0FERVJfVVJMX1JFUExBQ0VNRU5UXzBfX199KTtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogcmlnaHQgMC41cmVtIGNlbnRlcjtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1zaXplOiAxLjVlbSAxLjVlbTtcbiAgcGFkZGluZy1yaWdodDogMi41cmVtO1xuICBwcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0O1xufVxuXG5bbXVsdGlwbGVdLFtzaXplXTp3aGVyZShzZWxlY3Q6bm90KFtzaXplPVwiMVwiXSkpIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogaW5pdGlhbDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogaW5pdGlhbDtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IHVuc2V0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGluaXRpYWw7XG4gIHBhZGRpbmctcmlnaHQ6IDAuNzVyZW07XG4gIHByaW50LWNvbG9yLWFkanVzdDogdW5zZXQ7XG59XG5cblt0eXBlPSdjaGVja2JveCddLFt0eXBlPSdyYWRpbyddIHtcbiAgYXBwZWFyYW5jZTogbm9uZTtcbiAgcGFkZGluZzogMDtcbiAgcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBiYWNrZ3JvdW5kLW9yaWdpbjogYm9yZGVyLWJveDtcbiAgdXNlci1zZWxlY3Q6IG5vbmU7XG4gIGZsZXgtc2hyaW5rOiAwO1xuICBoZWlnaHQ6IDFyZW07XG4gIHdpZHRoOiAxcmVtO1xuICBjb2xvcjogIzI1NjNlYjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgYm9yZGVyLWNvbG9yOiAjNmI3MjgwO1xuICBib3JkZXItd2lkdGg6IDFweDtcbiAgLS10dy1zaGFkb3c6IDAgMCAjMDAwMDtcbn1cblxuW3R5cGU9J2NoZWNrYm94J10ge1xuICBib3JkZXItcmFkaXVzOiAwcHg7XG59XG5cblt0eXBlPSdyYWRpbyddIHtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbn1cblxuW3R5cGU9J2NoZWNrYm94J106Zm9jdXMsW3R5cGU9J3JhZGlvJ106Zm9jdXMge1xuICBvdXRsaW5lOiAycHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIG91dGxpbmUtb2Zmc2V0OiAycHg7XG4gIC0tdHctcmluZy1pbnNldDogdmFyKC0tdHctZW1wdHksLyohKi8gLyohKi8pO1xuICAtLXR3LXJpbmctb2Zmc2V0LXdpZHRoOiAycHg7XG4gIC0tdHctcmluZy1vZmZzZXQtY29sb3I6ICNmZmY7XG4gIC0tdHctcmluZy1jb2xvcjogIzI1NjNlYjtcbiAgLS10dy1yaW5nLW9mZnNldC1zaGFkb3c6IHZhcigtLXR3LXJpbmctaW5zZXQpIDAgMCAwIHZhcigtLXR3LXJpbmctb2Zmc2V0LXdpZHRoKSB2YXIoLS10dy1yaW5nLW9mZnNldC1jb2xvcik7XG4gIC0tdHctcmluZy1zaGFkb3c6IHZhcigtLXR3LXJpbmctaW5zZXQpIDAgMCAwIGNhbGMoMnB4ICsgdmFyKC0tdHctcmluZy1vZmZzZXQtd2lkdGgpKSB2YXIoLS10dy1yaW5nLWNvbG9yKTtcbiAgYm94LXNoYWRvdzogdmFyKC0tdHctcmluZy1vZmZzZXQtc2hhZG93KSwgdmFyKC0tdHctcmluZy1zaGFkb3cpLCB2YXIoLS10dy1zaGFkb3cpO1xufVxuXG5bdHlwZT0nY2hlY2tib3gnXTpjaGVja2VkLFt0eXBlPSdyYWRpbyddOmNoZWNrZWQge1xuICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBjdXJyZW50Q29sb3I7XG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJSAxMDAlO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG59XG5cblt0eXBlPSdjaGVja2JveCddOmNoZWNrZWQge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJHtfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF8xX19ffSk7XG59XG5cblt0eXBlPSdyYWRpbyddOmNoZWNrZWQge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJHtfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF8yX19ffSk7XG59XG5cblt0eXBlPSdjaGVja2JveCddOmNoZWNrZWQ6aG92ZXIsW3R5cGU9J2NoZWNrYm94J106Y2hlY2tlZDpmb2N1cyxbdHlwZT0ncmFkaW8nXTpjaGVja2VkOmhvdmVyLFt0eXBlPSdyYWRpbyddOmNoZWNrZWQ6Zm9jdXMge1xuICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBjdXJyZW50Q29sb3I7XG59XG5cblt0eXBlPSdjaGVja2JveCddOmluZGV0ZXJtaW5hdGUge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJHtfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF8zX19ffSk7XG4gIGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGJhY2tncm91bmQtY29sb3I6IGN1cnJlbnRDb2xvcjtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbn1cblxuW3R5cGU9J2NoZWNrYm94J106aW5kZXRlcm1pbmF0ZTpob3ZlcixbdHlwZT0nY2hlY2tib3gnXTppbmRldGVybWluYXRlOmZvY3VzIHtcbiAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgYmFja2dyb3VuZC1jb2xvcjogY3VycmVudENvbG9yO1xufVxuXG5bdHlwZT0nZmlsZSddIHtcbiAgYmFja2dyb3VuZDogdW5zZXQ7XG4gIGJvcmRlci1jb2xvcjogaW5oZXJpdDtcbiAgYm9yZGVyLXdpZHRoOiAwO1xuICBib3JkZXItcmFkaXVzOiAwO1xuICBwYWRkaW5nOiAwO1xuICBmb250LXNpemU6IHVuc2V0O1xuICBsaW5lLWhlaWdodDogaW5oZXJpdDtcbn1cblxuW3R5cGU9J2ZpbGUnXTpmb2N1cyB7XG4gIG91dGxpbmU6IDFweCBzb2xpZCBCdXR0b25UZXh0O1xuICBvdXRsaW5lOiAxcHggYXV0byAtd2Via2l0LWZvY3VzLXJpbmctY29sb3I7XG59XG4gICoge1xuICAgIHNjcm9sbGJhci13aWR0aDogbm9uZTtcbiAgICAtd2Via2l0LWZvbnQtc21vb3RoaW5nOiBhbnRpYWxpYXNlZDtcbiAgICAtbW96LW9zeC1mb250LXNtb290aGluZzogZ3JheXNjYWxlO1xuICAgIHNjcm9sbC1iZWhhdmlvcjogYXV0byAhaW1wb3J0YW50O1xuICB9XG5cbiAgYm9keSB7XG4gICAgY29sb3Itc2NoZW1lOiBsaWdodCBkYXJrO1xuICAgIGZvbnQtZmFtaWx5OiBzeXN0ZW0tdWksIHNhbnMtc2VyaWY7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgbGluZS1oZWlnaHQ6IDEuNztcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgaGVpZ2h0OiA2MDBweDtcbiAgICB3aWR0aDogMzQ4cHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAtLXR3LWJnLW9wYWNpdHk6IDE7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIyOSAyMzEgMjM1IC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xuICAgIC0tdHctdGV4dC1vcGFjaXR5OiAxO1xuICAgIGNvbG9yOiByZ2IoMzEgNDEgNTUgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbiAgfVxuXG4gIDppcyguZGFyayBib2R5KSB7XG4gIC0tdHctYmctb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1IDI1IDI1IC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xuICAtLXR3LXRleHQtb3BhY2l0eTogMTtcbiAgY29sb3I6IHJnYigyMjkgMjMxIDIzNSAvIHZhcigtLXR3LXRleHQtb3BhY2l0eSkpO1xufVxuXG4gIFt0eXBlPSd0ZXh0J10sXG4gIFt0eXBlPSdwYXNzd29yZCddLFxuICBbdHlwZT0nbnVtYmVyJ10sXG4gIFttdWx0aXBsZV0sXG4gIHRleHRhcmVhLFxuICBzZWxlY3Qge1xuICB3aWR0aDogMTAwJTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBib3JkZXItcmFkaXVzOiAwLjM3NXJlbTtcbiAgLS10dy1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYigwIDAgMCAvIDAuMDUpO1xuICAtLXR3LXNoYWRvdy1jb2xvcmVkOiAwIDFweCAycHggMCB2YXIoLS10dy1zaGFkb3ctY29sb3IpO1xuICBib3gtc2hhZG93OiB2YXIoLS10dy1yaW5nLW9mZnNldC1zaGFkb3csIDAgMCAjMDAwMCksIHZhcigtLXR3LXJpbmctc2hhZG93LCAwIDAgIzAwMDApLCB2YXIoLS10dy1zaGFkb3cpO1xufVxuXG4gIFt0eXBlPSd0ZXh0J106Zm9jdXMsXG4gIFt0eXBlPSdwYXNzd29yZCddOmZvY3VzLFxuICBbdHlwZT0nbnVtYmVyJ106Zm9jdXMsXG4gIFttdWx0aXBsZV06Zm9jdXMsXG4gIHRleHRhcmVhOmZvY3VzLFxuICBzZWxlY3Q6Zm9jdXMge1xuICAtLXR3LWJvcmRlci1vcGFjaXR5OiAxO1xuICBib3JkZXItY29sb3I6IHJnYig5OSAxMDIgMjQxIC8gdmFyKC0tdHctYm9yZGVyLW9wYWNpdHkpKTtcbiAgLS10dy1yaW5nLW9wYWNpdHk6IDE7XG4gIC0tdHctcmluZy1jb2xvcjogcmdiKDk5IDEwMiAyNDEgLyB2YXIoLS10dy1yaW5nLW9wYWNpdHkpKTtcbn1cblxuICBbdHlwZT0ndGV4dCddOmRpc2FibGVkLFxuICBbdHlwZT0ncGFzc3dvcmQnXTpkaXNhYmxlZCxcbiAgW3R5cGU9J251bWJlciddOmRpc2FibGVkLFxuICBbbXVsdGlwbGVdOmRpc2FibGVkLFxuICB0ZXh0YXJlYTpkaXNhYmxlZCxcbiAgc2VsZWN0OmRpc2FibGVkIHtcbiAgY3Vyc29yOiBub3QtYWxsb3dlZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDAgMCAwIC8gMC4xKTtcbn1cblxuICA6aXMoLmRhcmsgW3R5cGU9J3RleHQnXTpkaXNhYmxlZCksOmlzKC5kYXJrIFxuICBbdHlwZT0ncGFzc3dvcmQnXTpkaXNhYmxlZCksOmlzKC5kYXJrIFxuICBbdHlwZT0nbnVtYmVyJ106ZGlzYWJsZWQpLDppcyguZGFyayBcbiAgW211bHRpcGxlXTpkaXNhYmxlZCksOmlzKC5kYXJrIFxuICB0ZXh0YXJlYTpkaXNhYmxlZCksOmlzKC5kYXJrIFxuICBzZWxlY3Q6ZGlzYWJsZWQpIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDc0IDc0IDc0IC8gMC44KTtcbn1cbiAgc2VsZWN0IHtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbn1cbiAgW3R5cGU9J2NoZWNrYm94J10sXG4gIFt0eXBlPSdyYWRpbyddIHtcbiAgaGVpZ2h0OiAxcmVtO1xuICB3aWR0aDogMXJlbTtcbiAgYm9yZGVyLXJhZGl1czogOTk5OXB4O1xuICAtLXR3LWJvcmRlci1vcGFjaXR5OiAxO1xuICBib3JkZXItY29sb3I6IHJnYigyMDkgMjEzIDIxOSAvIHZhcigtLXR3LWJvcmRlci1vcGFjaXR5KSk7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUgMjU1IDI1NSAvIDAuMik7XG4gIC0tdHctdGV4dC1vcGFjaXR5OiAxO1xuICBjb2xvcjogcmdiKDc5IDcwIDIyOSAvIHZhcigtLXR3LXRleHQtb3BhY2l0eSkpO1xufVxuICBbdHlwZT0nY2hlY2tib3gnXTpmb2N1cyxcbiAgW3R5cGU9J3JhZGlvJ106Zm9jdXMge1xuICAtLXR3LXJpbmctb2Zmc2V0LXNoYWRvdzogdmFyKC0tdHctcmluZy1pbnNldCkgMCAwIDAgdmFyKC0tdHctcmluZy1vZmZzZXQtd2lkdGgpIHZhcigtLXR3LXJpbmctb2Zmc2V0LWNvbG9yKTtcbiAgLS10dy1yaW5nLXNoYWRvdzogdmFyKC0tdHctcmluZy1pbnNldCkgMCAwIDAgY2FsYygxcHggKyB2YXIoLS10dy1yaW5nLW9mZnNldC13aWR0aCkpIHZhcigtLXR3LXJpbmctY29sb3IpO1xuICBib3gtc2hhZG93OiB2YXIoLS10dy1yaW5nLW9mZnNldC1zaGFkb3cpLCB2YXIoLS10dy1yaW5nLXNoYWRvdyksIHZhcigtLXR3LXNoYWRvdywgMCAwICMwMDAwKTtcbiAgLS10dy1yaW5nLW9wYWNpdHk6IDE7XG4gIC0tdHctcmluZy1jb2xvcjogcmdiKDk5IDEwMiAyNDEgLyB2YXIoLS10dy1yaW5nLW9wYWNpdHkpKTtcbiAgLS10dy1yaW5nLW9mZnNldC13aWR0aDogMHB4O1xufVxuICAucmVxdWlyZWQtYXN0ZXJpc2s6OmFmdGVyIHtcbiAgbWFyZ2luLWxlZnQ6IDAuMTI1cmVtO1xuICAtLXR3LXRleHQtb3BhY2l0eTogMTtcbiAgY29sb3I6IHJnYigyMzkgNjggNjggLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbiAgLS10dy1jb250ZW50OiAnKic7XG4gIGNvbnRlbnQ6IHZhcigtLXR3LWNvbnRlbnQpO1xufVxuXG4gIC8qIG1haW4gbGF5b3V0IChmdWxsIHBvcHVwKSAqL1xuICAuYm94LWNvbnRhaW5lciB7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBzdHJldGNoO1xufVxuICAuYm94LWNvbnRhaW5lci5yaWdodC1vcGVuIC5ib3gxLWNvbnRlbnQge1xuICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgZmxleDogMDtcbiAgb3BhY2l0eTogMDtcbn1cbiAgLmJveC1jb250YWluZXIucmlnaHQtb3BlbiAuYm94MS1zaWRlIHtcbiAgZmxleDogMDtcbiAgb3BhY2l0eTogMDtcbn1cbiAgLmJveC1jb250YWluZXIucmlnaHQtb3BlbiAuYm94Mi1zaWRlIHtcbiAgZmxleDogMTtcbiAgb3BhY2l0eTogMTtcbn1cbiAgLmJveC1jb250YWluZXIucmlnaHQtb3BlbiAuYm94Mi1jb250ZW50IHtcbiAgZmxleDogNTtcbiAgcGFkZGluZzogMXJlbTtcbiAgb3BhY2l0eTogMTtcbn1cbiAgLmJveDEtY29udGVudCxcbiAgLmJveDEtc2lkZSxcbiAgLmJveDItY29udGVudCxcbiAgLmJveDItc2lkZSB7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHRyYW5zaXRpb24tcHJvcGVydHk6IGFsbDtcbiAgdHJhbnNpdGlvbi1kdXJhdGlvbjogMzAwbXM7XG4gIHRyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC40LCAwLCAwLjIsIDEpO1xufVxuICAuYm94MS1zaWRlLFxuICAuYm94Mi1zaWRlIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG4gIC5ib3gxLWNvbnRlbnQge1xuICBmbGV4OiA1LjQ7XG4gIG9wYWNpdHk6IDE7XG59XG4gIC5ib3gxLXNpZGUge1xuICAtLXR3LWJnLW9wYWNpdHk6IDE7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUgMjU1IDI1NSAvIHZhcigtLXR3LWJnLW9wYWNpdHkpKTtcbn1cbiAgOmlzKC5kYXJrIC5ib3gxLXNpZGUpIHtcbiAgLS10dy1iZy1vcGFjaXR5OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMzYgMzcgMzggLyB2YXIoLS10dy1iZy1vcGFjaXR5KSk7XG59XG4gIC5ib3gxLXNpZGUgeyAvKiB0byBhZGQgYmx1ciwgQGFwcGx5IGJnLXdoaXRlLzQwIGJhY2tkcm9wLWJsdXItbWQgZGFyazpiZy1bIzI0MjUyNl0vNDA7IH0gKi8gdG9wOiAwLjI1cmVtOyBib3R0b206IDAuMjVyZW07IG1hcmdpbi1sZWZ0OiAxcmVtOyBtYXJnaW4tcmlnaHQ6IDFyZW07IG1hcmdpbi1ib3R0b206IDFyZW07IGhlaWdodDogMTAwJTsgZmxleDogMC42OyBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7IGJvcmRlci1yYWRpdXM6IDAuMzc1cmVtOyAtLXR3LXNoYWRvdzogMCAzcHggMnB4IC0xcHggcmdiYSgwLDAsMCwwLjEpOyAtLXR3LXNoYWRvdy1jb2xvcmVkOiAwIDNweCAycHggLTFweCB2YXIoLS10dy1zaGFkb3ctY29sb3IpOyBib3gtc2hhZG93OiB2YXIoLS10dy1yaW5nLW9mZnNldC1zaGFkb3csIDAgMCAjMDAwMCksIHZhcigtLXR3LXJpbmctc2hhZG93LCAwIDAgIzAwMDApLCB2YXIoLS10dy1zaGFkb3cpO1xuICB9XG4gIC5ib3gyLXNpZGUge1xuICBmbGV4OiAwO1xuICBvcGFjaXR5OiAwO1xufVxuICAuYm94Mi1jb250ZW50IHtcbiAgLS10dy1iZy1vcGFjaXR5OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1IDI1NSAyNTUgLyB2YXIoLS10dy1iZy1vcGFjaXR5KSk7XG59XG4gIDppcyguZGFyayAuYm94Mi1jb250ZW50KSB7XG4gIC0tdHctYmctb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDM2IDM3IDM4IC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xufVxuICAuYm94Mi1jb250ZW50IHsgLyogdG8gYWRkIGJsdXIsIEBhcHBseSBiZy13aGl0ZS80MCBiYWNrZHJvcC1ibHVyLW1kIGRhcms6YmctWyMyNDI1MjZdLzQwOyB9ICovIGJvdHRvbTogMHB4OyBsZWZ0OiAwcHg7IHJpZ2h0OiAwcHg7IG1hcmdpbi1ib3R0b206IDBweDsgZGlzcGxheTogZmxleDsgZmxleDogMDsgZmxleC1kaXJlY3Rpb246IGNvbHVtbjsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIH1cbiAgLmJveDItY29udGVudCA+IDpub3QoW2hpZGRlbl0pIH4gOm5vdChbaGlkZGVuXSkge1xuICAtLXR3LXNwYWNlLXktcmV2ZXJzZTogMDtcbiAgbWFyZ2luLXRvcDogY2FsYygxcmVtICogY2FsYygxIC0gdmFyKC0tdHctc3BhY2UteS1yZXZlcnNlKSkpO1xuICBtYXJnaW4tYm90dG9tOiBjYWxjKDFyZW0gKiB2YXIoLS10dy1zcGFjZS15LXJldmVyc2UpKTtcbn1cbiAgLmJveDItY29udGVudCB7XG4gIG9wYWNpdHk6IDA7XG4gIC0tdHctc2hhZG93OiAwIDFweCAycHggMCByZ2IoMCAwIDAgLyAwLjA1KTtcbiAgLS10dy1zaGFkb3ctY29sb3JlZDogMCAxcHggMnB4IDAgdmFyKC0tdHctc2hhZG93LWNvbG9yKTtcbiAgYm94LXNoYWRvdzogdmFyKC0tdHctcmluZy1vZmZzZXQtc2hhZG93LCAwIDAgIzAwMDApLCB2YXIoLS10dy1yaW5nLXNoYWRvdywgMCAwICMwMDAwKSwgdmFyKC0tdHctc2hhZG93KTtcbn1cblxuICAvKiBGb3JtICovXG4gIC5mb3JtLXRleHRib3gge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuICAuZm9ybS10ZXh0Ym94ID4gbGFiZWwsXG4gIC5mb3JtLXRleHRib3gtbGFiZWwge1xuICBtYXJnaW4tYm90dG9tOiAwLjI1cmVtO1xuICBkaXNwbGF5OiBibG9jaztcbiAgZm9udC1zaXplOiAwLjg3NXJlbTtcbiAgbGluZS1oZWlnaHQ6IDEuMjVyZW07XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIC0tdHctdGV4dC1vcGFjaXR5OiAxO1xuICBjb2xvcjogcmdiKDU1IDY1IDgxIC8gdmFyKC0tdHctdGV4dC1vcGFjaXR5KSk7XG59XG4gIDppcyguZGFyayAuZm9ybS10ZXh0Ym94ID4gbGFiZWwpLDppcyguZGFyayBcbiAgLmZvcm0tdGV4dGJveC1sYWJlbCkge1xuICAtLXR3LXRleHQtb3BhY2l0eTogMTtcbiAgY29sb3I6IHJnYigyMjkgMjMxIDIzNSAvIHZhcigtLXR3LXRleHQtb3BhY2l0eSkpO1xufVxuICAuZm9ybS10ZXh0Ym94ID4gZGl2IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwJTtcbn1cbiAgLmZvcm0tdGV4dGJveCA+IGRpdiA+IGRpdiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMHB4O1xuICB0b3A6IDBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMi41cmVtO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYm9yZGVyLXJpZ2h0LXdpZHRoOiAxcHg7XG4gIC0tdHctYm9yZGVyLW9wYWNpdHk6IDE7XG4gIGJvcmRlci1jb2xvcjogcmdiKDIwOSAyMTMgMjE5IC8gdmFyKC0tdHctYm9yZGVyLW9wYWNpdHkpKTtcbn1cbiAgOmlzKC5kYXJrIC5mb3JtLXRleHRib3ggPiBkaXYgPiBkaXYpIHtcbiAgYm9yZGVyLWNvbG9yOiByZ2IoMjA5IDIxMyAyMTkgLyAwLjEpO1xufVxuICAuZm9ybS10ZXh0Ym94ID4gZGl2ID4gZGl2ID4gc3ZnIHtcbiAgaGVpZ2h0OiAxcmVtO1xuICB3aWR0aDogMXJlbTtcbiAgZmlsbDogY3VycmVudENvbG9yO1xufVxuICA6aXMoLmRhcmsgLmZvcm0tdGV4dGJveCA+IGRpdiA+IGRpdiA+IHN2Zykge1xuICBmaWxsOiAjZTJlOGYwO1xufVxuICAuZm9ybS10ZXh0Ym94ID4gZGl2ID4gaW5wdXQge1xuICB3aWR0aDogMTAwJTtcbiAgLS10dy1ib3JkZXItb3BhY2l0eTogMTtcbiAgYm9yZGVyLWNvbG9yOiByZ2IoMjA5IDIxMyAyMTkgLyB2YXIoLS10dy1ib3JkZXItb3BhY2l0eSkpO1xuICBwYWRkaW5nLWxlZnQ6IDNyZW07XG4gIGZvbnQtc2l6ZTogMC43NXJlbTtcbiAgbGluZS1oZWlnaHQ6IDFyZW07XG59XG4gIC5mb3JtLXRleHRib3ggPiBkaXYgPiBpbnB1dDo6cGxhY2Vob2xkZXIge1xuICAtLXR3LXBsYWNlaG9sZGVyLW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoMTU2IDE2MyAxNzUgLyB2YXIoLS10dy1wbGFjZWhvbGRlci1vcGFjaXR5KSk7XG59XG4gIC5mb3JtLXRleHRib3ggPiBkaXYgPiBpbnB1dDpkaXNhYmxlZCB7XG4gIC0tdHctc2hhZG93OiAwIDAgIzAwMDA7XG4gIC0tdHctc2hhZG93LWNvbG9yZWQ6IDAgMCAjMDAwMDtcbiAgYm94LXNoYWRvdzogdmFyKC0tdHctcmluZy1vZmZzZXQtc2hhZG93LCAwIDAgIzAwMDApLCB2YXIoLS10dy1yaW5nLXNoYWRvdywgMCAwICMwMDAwKSwgdmFyKC0tdHctc2hhZG93KTtcbn1cbiAgOmlzKC5kYXJrIC5mb3JtLXRleHRib3ggPiBkaXYgPiBpbnB1dCkge1xuICBib3JkZXItY29sb3I6IHJnYigyMDkgMjEzIDIxOSAvIDAuMSk7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUgMjU1IDI1NSAvIDAuMDUpO1xufVxuXG4gIC8qIE1lc3NhZ2UgKi9cbiAgLmFjdGlvbiB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMC4xMjVyZW07XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigwIDAgMCAvIDAuMSk7XG4gIHBhZGRpbmctdG9wOiAwLjI1cmVtO1xuICBwYWRkaW5nLWJvdHRvbTogMC4yNXJlbTtcbiAgcGFkZGluZy1sZWZ0OiAwLjVyZW07XG4gIHBhZGRpbmctcmlnaHQ6IDAuNXJlbTtcbn1cbiAgLmluZm8sXG4gIC53YXJuaW5nLFxuICAuZXJyb3IsXG4gIC5zdWNjZXNzIHtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxMDAlO1xuICBtYXgtaGVpZ2h0OiAycmVtO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBnYXA6IDAuNXJlbTtcbiAgYm9yZGVyLXJhZGl1czogMC4zNzVyZW07XG4gIC0tdHctYmctb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE0OCAxNjMgMTg0IC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xuICBwYWRkaW5nLXRvcDogMC41cmVtO1xuICBwYWRkaW5nLWJvdHRvbTogMC41cmVtO1xuICBwYWRkaW5nLWxlZnQ6IDAuNzVyZW07XG4gIHBhZGRpbmctcmlnaHQ6IDAuNzVyZW07XG4gIGZvbnQtd2VpZ2h0OiA0MDA7XG4gIC0tdHctdGV4dC1vcGFjaXR5OiAxO1xuICBjb2xvcjogcmdiKDAgMCAwIC8gdmFyKC0tdHctdGV4dC1vcGFjaXR5KSk7XG59XG4gIC5pbmZvID4gc3ZnLFxuICAud2FybmluZyA+IHN2ZyxcbiAgLmVycm9yID4gc3ZnLFxuICAuc3VjY2VzcyA+IHN2ZyB7XG4gIGhlaWdodDogMXJlbTtcbiAgd2lkdGg6IDFyZW07XG4gIGZpbGw6IGN1cnJlbnRDb2xvcjtcbn1cbiAgLndhcm5pbmcge1xuICBkaXNwbGF5OiBmbGV4O1xuICBoZWlnaHQ6IDEwMCU7XG4gIG1heC1oZWlnaHQ6IDJyZW07XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGdhcDogMC41cmVtO1xuICBib3JkZXItcmFkaXVzOiAwLjM3NXJlbTtcbiAgLS10dy1iZy1vcGFjaXR5OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTQ4IDE2MyAxODQgLyB2YXIoLS10dy1iZy1vcGFjaXR5KSk7XG4gIHBhZGRpbmctdG9wOiAwLjVyZW07XG4gIHBhZGRpbmctYm90dG9tOiAwLjVyZW07XG4gIHBhZGRpbmctbGVmdDogMC43NXJlbTtcbiAgcGFkZGluZy1yaWdodDogMC43NXJlbTtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoMCAwIDAgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbiAgLndhcm5pbmcgPiBzdmcge1xuICBoZWlnaHQ6IDFyZW07XG4gIHdpZHRoOiAxcmVtO1xuICBmaWxsOiBjdXJyZW50Q29sb3I7XG59XG4gIC53YXJuaW5nIHtcbiAgLS10dy1iZy1vcGFjaXR5OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjUzIDIyNCA3MSAvIHZhcigtLXR3LWJnLW9wYWNpdHkpKTtcbn1cbiAgLmVycm9yIHtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxMDAlO1xuICBtYXgtaGVpZ2h0OiAycmVtO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBnYXA6IDAuNXJlbTtcbiAgYm9yZGVyLXJhZGl1czogMC4zNzVyZW07XG4gIC0tdHctYmctb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE0OCAxNjMgMTg0IC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xuICBwYWRkaW5nLXRvcDogMC41cmVtO1xuICBwYWRkaW5nLWJvdHRvbTogMC41cmVtO1xuICBwYWRkaW5nLWxlZnQ6IDAuNzVyZW07XG4gIHBhZGRpbmctcmlnaHQ6IDAuNzVyZW07XG4gIGZvbnQtd2VpZ2h0OiA0MDA7XG4gIC0tdHctdGV4dC1vcGFjaXR5OiAxO1xuICBjb2xvcjogcmdiKDAgMCAwIC8gdmFyKC0tdHctdGV4dC1vcGFjaXR5KSk7XG59XG4gIC5lcnJvciA+IHN2ZyB7XG4gIGhlaWdodDogMXJlbTtcbiAgd2lkdGg6IDFyZW07XG4gIGZpbGw6IGN1cnJlbnRDb2xvcjtcbn1cbiAgLmVycm9yIHtcbiAgLS10dy1iZy1vcGFjaXR5OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjUyIDE2NSAxNjUgLyB2YXIoLS10dy1iZy1vcGFjaXR5KSk7XG59XG4gIC5zdWNjZXNzIHtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxMDAlO1xuICBtYXgtaGVpZ2h0OiAycmVtO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBnYXA6IDAuNXJlbTtcbiAgYm9yZGVyLXJhZGl1czogMC4zNzVyZW07XG4gIC0tdHctYmctb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE0OCAxNjMgMTg0IC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xuICBwYWRkaW5nLXRvcDogMC41cmVtO1xuICBwYWRkaW5nLWJvdHRvbTogMC41cmVtO1xuICBwYWRkaW5nLWxlZnQ6IDAuNzVyZW07XG4gIHBhZGRpbmctcmlnaHQ6IDAuNzVyZW07XG4gIGZvbnQtd2VpZ2h0OiA0MDA7XG4gIC0tdHctdGV4dC1vcGFjaXR5OiAxO1xuICBjb2xvcjogcmdiKDAgMCAwIC8gdmFyKC0tdHctdGV4dC1vcGFjaXR5KSk7XG59XG4gIC5zdWNjZXNzID4gc3ZnIHtcbiAgaGVpZ2h0OiAxcmVtO1xuICB3aWR0aDogMXJlbTtcbiAgZmlsbDogY3VycmVudENvbG9yO1xufVxuICAuc3VjY2VzcyB7XG4gIC0tdHctYmctb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDEzNCAyMzkgMTcyIC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xufVxuXG4qLCA6OmJlZm9yZSwgOjphZnRlciB7XG4gIC0tdHctYm9yZGVyLXNwYWNpbmcteDogMDtcbiAgLS10dy1ib3JkZXItc3BhY2luZy15OiAwO1xuICAtLXR3LXRyYW5zbGF0ZS14OiAwO1xuICAtLXR3LXRyYW5zbGF0ZS15OiAwO1xuICAtLXR3LXJvdGF0ZTogMDtcbiAgLS10dy1za2V3LXg6IDA7XG4gIC0tdHctc2tldy15OiAwO1xuICAtLXR3LXNjYWxlLXg6IDE7XG4gIC0tdHctc2NhbGUteTogMTtcbiAgLS10dy1wYW4teDogIDtcbiAgLS10dy1wYW4teTogIDtcbiAgLS10dy1waW5jaC16b29tOiAgO1xuICAtLXR3LXNjcm9sbC1zbmFwLXN0cmljdG5lc3M6IHByb3hpbWl0eTtcbiAgLS10dy1ncmFkaWVudC1mcm9tLXBvc2l0aW9uOiAgO1xuICAtLXR3LWdyYWRpZW50LXZpYS1wb3NpdGlvbjogIDtcbiAgLS10dy1ncmFkaWVudC10by1wb3NpdGlvbjogIDtcbiAgLS10dy1vcmRpbmFsOiAgO1xuICAtLXR3LXNsYXNoZWQtemVybzogIDtcbiAgLS10dy1udW1lcmljLWZpZ3VyZTogIDtcbiAgLS10dy1udW1lcmljLXNwYWNpbmc6ICA7XG4gIC0tdHctbnVtZXJpYy1mcmFjdGlvbjogIDtcbiAgLS10dy1yaW5nLWluc2V0OiAgO1xuICAtLXR3LXJpbmctb2Zmc2V0LXdpZHRoOiAwcHg7XG4gIC0tdHctcmluZy1vZmZzZXQtY29sb3I6ICNmZmY7XG4gIC0tdHctcmluZy1jb2xvcjogcmdiKDU5IDEzMCAyNDYgLyAwLjUpO1xuICAtLXR3LXJpbmctb2Zmc2V0LXNoYWRvdzogMCAwICMwMDAwO1xuICAtLXR3LXJpbmctc2hhZG93OiAwIDAgIzAwMDA7XG4gIC0tdHctc2hhZG93OiAwIDAgIzAwMDA7XG4gIC0tdHctc2hhZG93LWNvbG9yZWQ6IDAgMCAjMDAwMDtcbiAgLS10dy1ibHVyOiAgO1xuICAtLXR3LWJyaWdodG5lc3M6ICA7XG4gIC0tdHctY29udHJhc3Q6ICA7XG4gIC0tdHctZ3JheXNjYWxlOiAgO1xuICAtLXR3LWh1ZS1yb3RhdGU6ICA7XG4gIC0tdHctaW52ZXJ0OiAgO1xuICAtLXR3LXNhdHVyYXRlOiAgO1xuICAtLXR3LXNlcGlhOiAgO1xuICAtLXR3LWRyb3Atc2hhZG93OiAgO1xuICAtLXR3LWJhY2tkcm9wLWJsdXI6ICA7XG4gIC0tdHctYmFja2Ryb3AtYnJpZ2h0bmVzczogIDtcbiAgLS10dy1iYWNrZHJvcC1jb250cmFzdDogIDtcbiAgLS10dy1iYWNrZHJvcC1ncmF5c2NhbGU6ICA7XG4gIC0tdHctYmFja2Ryb3AtaHVlLXJvdGF0ZTogIDtcbiAgLS10dy1iYWNrZHJvcC1pbnZlcnQ6ICA7XG4gIC0tdHctYmFja2Ryb3Atb3BhY2l0eTogIDtcbiAgLS10dy1iYWNrZHJvcC1zYXR1cmF0ZTogIDtcbiAgLS10dy1iYWNrZHJvcC1zZXBpYTogIDtcbn1cblxuOjpiYWNrZHJvcCB7XG4gIC0tdHctYm9yZGVyLXNwYWNpbmcteDogMDtcbiAgLS10dy1ib3JkZXItc3BhY2luZy15OiAwO1xuICAtLXR3LXRyYW5zbGF0ZS14OiAwO1xuICAtLXR3LXRyYW5zbGF0ZS15OiAwO1xuICAtLXR3LXJvdGF0ZTogMDtcbiAgLS10dy1za2V3LXg6IDA7XG4gIC0tdHctc2tldy15OiAwO1xuICAtLXR3LXNjYWxlLXg6IDE7XG4gIC0tdHctc2NhbGUteTogMTtcbiAgLS10dy1wYW4teDogIDtcbiAgLS10dy1wYW4teTogIDtcbiAgLS10dy1waW5jaC16b29tOiAgO1xuICAtLXR3LXNjcm9sbC1zbmFwLXN0cmljdG5lc3M6IHByb3hpbWl0eTtcbiAgLS10dy1ncmFkaWVudC1mcm9tLXBvc2l0aW9uOiAgO1xuICAtLXR3LWdyYWRpZW50LXZpYS1wb3NpdGlvbjogIDtcbiAgLS10dy1ncmFkaWVudC10by1wb3NpdGlvbjogIDtcbiAgLS10dy1vcmRpbmFsOiAgO1xuICAtLXR3LXNsYXNoZWQtemVybzogIDtcbiAgLS10dy1udW1lcmljLWZpZ3VyZTogIDtcbiAgLS10dy1udW1lcmljLXNwYWNpbmc6ICA7XG4gIC0tdHctbnVtZXJpYy1mcmFjdGlvbjogIDtcbiAgLS10dy1yaW5nLWluc2V0OiAgO1xuICAtLXR3LXJpbmctb2Zmc2V0LXdpZHRoOiAwcHg7XG4gIC0tdHctcmluZy1vZmZzZXQtY29sb3I6ICNmZmY7XG4gIC0tdHctcmluZy1jb2xvcjogcmdiKDU5IDEzMCAyNDYgLyAwLjUpO1xuICAtLXR3LXJpbmctb2Zmc2V0LXNoYWRvdzogMCAwICMwMDAwO1xuICAtLXR3LXJpbmctc2hhZG93OiAwIDAgIzAwMDA7XG4gIC0tdHctc2hhZG93OiAwIDAgIzAwMDA7XG4gIC0tdHctc2hhZG93LWNvbG9yZWQ6IDAgMCAjMDAwMDtcbiAgLS10dy1ibHVyOiAgO1xuICAtLXR3LWJyaWdodG5lc3M6ICA7XG4gIC0tdHctY29udHJhc3Q6ICA7XG4gIC0tdHctZ3JheXNjYWxlOiAgO1xuICAtLXR3LWh1ZS1yb3RhdGU6ICA7XG4gIC0tdHctaW52ZXJ0OiAgO1xuICAtLXR3LXNhdHVyYXRlOiAgO1xuICAtLXR3LXNlcGlhOiAgO1xuICAtLXR3LWRyb3Atc2hhZG93OiAgO1xuICAtLXR3LWJhY2tkcm9wLWJsdXI6ICA7XG4gIC0tdHctYmFja2Ryb3AtYnJpZ2h0bmVzczogIDtcbiAgLS10dy1iYWNrZHJvcC1jb250cmFzdDogIDtcbiAgLS10dy1iYWNrZHJvcC1ncmF5c2NhbGU6ICA7XG4gIC0tdHctYmFja2Ryb3AtaHVlLXJvdGF0ZTogIDtcbiAgLS10dy1iYWNrZHJvcC1pbnZlcnQ6ICA7XG4gIC0tdHctYmFja2Ryb3Atb3BhY2l0eTogIDtcbiAgLS10dy1iYWNrZHJvcC1zYXR1cmF0ZTogIDtcbiAgLS10dy1iYWNrZHJvcC1zZXBpYTogIDtcbn1cbi5jb250YWluZXIge1xuICB3aWR0aDogMTAwJTtcbn1cbkBtZWRpYSAobWluLXdpZHRoOiA2NDBweCkge1xuXG4gIC5jb250YWluZXIge1xuICAgIG1heC13aWR0aDogNjQwcHg7XG4gIH1cbn1cbkBtZWRpYSAobWluLXdpZHRoOiA3NjhweCkge1xuXG4gIC5jb250YWluZXIge1xuICAgIG1heC13aWR0aDogNzY4cHg7XG4gIH1cbn1cbkBtZWRpYSAobWluLXdpZHRoOiAxMDI0cHgpIHtcblxuICAuY29udGFpbmVyIHtcbiAgICBtYXgtd2lkdGg6IDEwMjRweDtcbiAgfVxufVxuQG1lZGlhIChtaW4td2lkdGg6IDEyODBweCkge1xuXG4gIC5jb250YWluZXIge1xuICAgIG1heC13aWR0aDogMTI4MHB4O1xuICB9XG59XG5AbWVkaWEgKG1pbi13aWR0aDogMTUzNnB4KSB7XG5cbiAgLmNvbnRhaW5lciB7XG4gICAgbWF4LXdpZHRoOiAxNTM2cHg7XG4gIH1cbn1cbi8qIENvbXBvbmVudHMgKi9cbi5saW5rLXRleHQge1xuICAtLXR3LXRleHQtb3BhY2l0eTogMTtcbiAgY29sb3I6IHJnYig3OSA3MCAyMjkgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbi5saW5rLXRleHQ6aG92ZXIge1xuICAtLXR3LXRleHQtb3BhY2l0eTogMTtcbiAgY29sb3I6IHJnYig5OSAxMDIgMjQxIC8gdmFyKC0tdHctdGV4dC1vcGFjaXR5KSk7XG59XG46aXMoLmRhcmsgLmxpbmstdGV4dCkge1xuICAtLXR3LXRleHQtb3BhY2l0eTogMTtcbiAgY29sb3I6IHJnYigxMjkgMTQwIDI0OCAvIHZhcigtLXR3LXRleHQtb3BhY2l0eSkpO1xufVxuOmlzKC5kYXJrIC5saW5rLXRleHQ6aG92ZXIpIHtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoOTkgMTAyIDI0MSAvIHZhcigtLXR3LXRleHQtb3BhY2l0eSkpO1xufVxuLnN2Zy1idG4tcHJpbWFyeSxcbiAgLnN2Zy1idG4tc2Vjb25kYXJ5IHtcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBnYXA6IDAuNXJlbTtcbiAgYm9yZGVyLXJhZGl1czogMC4zNzVyZW07XG4gIGJvcmRlci13aWR0aDogMXB4O1xuICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAtLXR3LWJnLW9wYWNpdHk6IDE7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYig3OSA3MCAyMjkgLyB2YXIoLS10dy1iZy1vcGFjaXR5KSk7XG4gIHBhZGRpbmctdG9wOiAwLjVyZW07XG4gIHBhZGRpbmctYm90dG9tOiAwLjVyZW07XG4gIHBhZGRpbmctbGVmdDogMXJlbTtcbiAgcGFkZGluZy1yaWdodDogMXJlbTtcbiAgZm9udC1zaXplOiAwLjc1cmVtO1xuICBsaW5lLWhlaWdodDogMXJlbTtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoMjU1IDI1NSAyNTUgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbiAgLS10dy1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYigwIDAgMCAvIDAuMDUpO1xuICAtLXR3LXNoYWRvdy1jb2xvcmVkOiAwIDFweCAycHggMCB2YXIoLS10dy1zaGFkb3ctY29sb3IpO1xuICBib3gtc2hhZG93OiB2YXIoLS10dy1yaW5nLW9mZnNldC1zaGFkb3csIDAgMCAjMDAwMCksIHZhcigtLXR3LXJpbmctc2hhZG93LCAwIDAgIzAwMDApLCB2YXIoLS10dy1zaGFkb3cpO1xufVxuLnN2Zy1idG4tcHJpbWFyeTpkaXNhYmxlZCxcbiAgLnN2Zy1idG4tc2Vjb25kYXJ5OmRpc2FibGVkIHtcbiAgY3Vyc29yOiBub3QtYWxsb3dlZDtcbiAgLS10dy1iZy1vcGFjaXR5OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTY1IDE4MCAyNTIgLyB2YXIoLS10dy1iZy1vcGFjaXR5KSk7XG59XG4uc3ZnLWJ0bi1wcmltYXJ5ID4gc3ZnLFxuICAuc3ZnLWJ0bi1zZWNvbmRhcnkgPiBzdmcge1xuICBoZWlnaHQ6IDFyZW07XG4gIHdpZHRoOiAxcmVtO1xuICBmaWxsOiAjZmZmO1xufVxuLnN2Zy1idG4tc2Vjb25kYXJ5IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDc1IDg1IDk5IC8gMC40KTtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoMTcgMjQgMzkgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbi5zdmctYnRuLXNlY29uZGFyeTpob3ZlciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYig3NSA4NSA5OSAvIDAuMyk7XG59XG46aXMoLmRhcmsgLnN2Zy1idG4tc2Vjb25kYXJ5KSB7XG4gIC0tdHctYmctb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDUxIDY1IDg1IC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xuICAtLXR3LXRleHQtb3BhY2l0eTogMTtcbiAgY29sb3I6IHJnYigyMDkgMjEzIDIxOSAvIHZhcigtLXR3LXRleHQtb3BhY2l0eSkpO1xufVxuLnN2Zy1idG4tc2Vjb25kYXJ5ID4gc3ZnIHtcbiAgaGVpZ2h0OiAxcmVtO1xuICB3aWR0aDogMXJlbTtcbiAgZmlsbDogIzExMTgyNztcbn1cbjppcyguZGFyayAuc3ZnLWJ0bi1zZWNvbmRhcnkgPiBzdmcpIHtcbiAgZmlsbDogI2QxZDVkYjtcbn1cbi8qIHBhbmVsICovXG4uYm94LXRvZ2dsZS1idG4ge1xuICAtLXR3LWJnLW9wYWNpdHk6IDE7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUgMjU1IDI1NSAvIHZhcigtLXR3LWJnLW9wYWNpdHkpKTtcbn1cbjppcyguZGFyayAuYm94LXRvZ2dsZS1idG4pIHtcbiAgLS10dy1iZy1vcGFjaXR5OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMzYgMzcgMzggLyB2YXIoLS10dy1iZy1vcGFjaXR5KSk7XG59XG4uYm94LXRvZ2dsZS1idG4geyAvKiB0byBhZGQgYmx1ciwgQGFwcGx5IGJnLXdoaXRlLzQwIGJhY2tkcm9wLWJsdXItbWQgZGFyazpiZy1bIzI0MjUyNl0vNDA7IH0gKi8gZGlzcGxheTogZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7IGdhcDogMC41cmVtOyBib3JkZXItcmFkaXVzOiAwLjM3NXJlbTsgYm9yZGVyLXdpZHRoOiAxcHg7IGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7IHBhZGRpbmctdG9wOiAwLjVyZW07IHBhZGRpbmctYm90dG9tOiAwLjVyZW07IHBhZGRpbmctbGVmdDogMXJlbTsgcGFkZGluZy1yaWdodDogMXJlbTsgZm9udC1zaXplOiAwLjc1cmVtOyBsaW5lLWhlaWdodDogMXJlbTsgZm9udC13ZWlnaHQ6IDUwMDsgLS10dy10ZXh0LW9wYWNpdHk6IDE7IGNvbG9yOiByZ2IoMCAwIDAgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTsgLS10dy1zaGFkb3c6IDAgMTBweCAxNXB4IC0zcHggcmdiKDAgMCAwIC8gMC4xKSwgMCA0cHggNnB4IC00cHggcmdiKDAgMCAwIC8gMC4xKTsgLS10dy1zaGFkb3ctY29sb3JlZDogMCAxMHB4IDE1cHggLTNweCB2YXIoLS10dy1zaGFkb3ctY29sb3IpLCAwIDRweCA2cHggLTRweCB2YXIoLS10dy1zaGFkb3ctY29sb3IpOyBib3gtc2hhZG93OiB2YXIoLS10dy1yaW5nLW9mZnNldC1zaGFkb3csIDAgMCAjMDAwMCksIHZhcigtLXR3LXJpbmctc2hhZG93LCAwIDAgIzAwMDApLCB2YXIoLS10dy1zaGFkb3cpOyAtLXR3LWJhY2tkcm9wLWJsdXI6IGJsdXIoMTJweCk7IGJhY2tkcm9wLWZpbHRlcjogdmFyKC0tdHctYmFja2Ryb3AtYmx1cikgdmFyKC0tdHctYmFja2Ryb3AtYnJpZ2h0bmVzcykgdmFyKC0tdHctYmFja2Ryb3AtY29udHJhc3QpIHZhcigtLXR3LWJhY2tkcm9wLWdyYXlzY2FsZSkgdmFyKC0tdHctYmFja2Ryb3AtaHVlLXJvdGF0ZSkgdmFyKC0tdHctYmFja2Ryb3AtaW52ZXJ0KSB2YXIoLS10dy1iYWNrZHJvcC1vcGFjaXR5KSB2YXIoLS10dy1iYWNrZHJvcC1zYXR1cmF0ZSkgdmFyKC0tdHctYmFja2Ryb3Atc2VwaWEpO1xuICB9XG4uYm94LXRvZ2dsZS1idG46aG92ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1IDI1NSAyNTUgLyAwLjQpO1xufVxuOmlzKC5kYXJrIC5ib3gtdG9nZ2xlLWJ0bikge1xuICAtLXR3LXRleHQtb3BhY2l0eTogMTtcbiAgY29sb3I6IHJnYigyNTUgMjU1IDI1NSAvIHZhcigtLXR3LXRleHQtb3BhY2l0eSkpO1xufVxuOmlzKC5kYXJrIC5ib3gtdG9nZ2xlLWJ0bik6aG92ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMCAwIDAgLyAwLjQpO1xufVxuLmJveC10b2dnbGUtYnRuID4gc3ZnIHtcbiAgaGVpZ2h0OiAxcmVtO1xuICB3aWR0aDogMXJlbTtcbiAgZmlsbDogY3VycmVudENvbG9yO1xufVxuLmJveC10b2dnbGUtYnRuID4gc3BhbiB7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG59XG4uYm94LXRvZ2dsZS1idG4tcGFuZWwtaXRlbSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiAxMDAlO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgZ2FwOiAwLjVyZW07XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwLjM3NXJlbTtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMC4zNzVyZW07XG59XG4uYm94LXRvZ2dsZS1idG4tcGFuZWwtaXRlbSA+IHN2ZyB7XG4gIGhlaWdodDogMXJlbTtcbiAgd2lkdGg6IDFyZW07XG4gIGZpbGw6ICMwMDA7XG59XG46aXMoLmRhcmsgLmJveC10b2dnbGUtYnRuLXBhbmVsLWl0ZW0gPiBzdmcpIHtcbiAgZmlsbDogIzExMTgyNztcbn1cbi5ib3gtdG9nZ2xlLWJ0bi1wYW5lbC1pdGVtID4gc3BhbiB7XG4gIHBhZGRpbmctdG9wOiAwLjI1cmVtO1xuICBwYWRkaW5nLWJvdHRvbTogMC4yNXJlbTtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoMCAwIDAgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbjppcyguZGFyayAuYm94LXRvZ2dsZS1idG4tcGFuZWwtaXRlbSA+IHNwYW4pIHtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoMTcgMjQgMzkgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbi5wYW5lbC1jb250YWluZXIge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDFyZW07XG4gIHJpZ2h0OiAxcmVtO1xuICB0b3A6IDFyZW07XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXg6IDEgMSAwJTtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgcGFkZGluZy1ib3R0b206IDAuNXJlbTtcbn1cbi5wYW5lbCB7XG4gIC0tdHctYmctb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1NSAyNTUgMjU1IC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xufVxuOmlzKC5kYXJrIC5wYW5lbCkge1xuICAtLXR3LWJnLW9wYWNpdHk6IDE7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigzNiAzNyAzOCAvIHZhcigtLXR3LWJnLW9wYWNpdHkpKTtcbn1cbi5wYW5lbCB7IC8qIHRvIGFkZCBibHVyLCBAYXBwbHkgYmctd2hpdGUvNDAgYmFja2Ryb3AtYmx1ci1tZCBkYXJrOmJnLVsjMjQyNTI2XS80MDsgfSAqLyBoZWlnaHQ6IDEwMCU7IG1heC1oZWlnaHQ6IDQ5MHB4OyB3aWR0aDogMTAwJTsgZmxleC1zaHJpbms6IDA7IGZsZXgtZ3JvdzogMDsgZmxleC1iYXNpczogMTAwJTsgc2Nyb2xsLXNuYXAtYWxpZ246IHN0YXJ0OyBvdmVyZmxvdy15OiBhdXRvOyBib3JkZXItcmFkaXVzOiAwLjM3NXJlbTsgcGFkZGluZy1ib3R0b206IDAuNXJlbTsgLS10dy1zaGFkb3c6IDAgM3B4IDJweCAtMXB4IHJnYmEoMCwwLDAsMC4xKTsgLS10dy1zaGFkb3ctY29sb3JlZDogMCAzcHggMnB4IC0xcHggdmFyKC0tdHctc2hhZG93LWNvbG9yKTsgYm94LXNoYWRvdzogdmFyKC0tdHctcmluZy1vZmZzZXQtc2hhZG93LCAwIDAgIzAwMDApLCB2YXIoLS10dy1yaW5nLXNoYWRvdywgMCAwICMwMDAwKSwgdmFyKC0tdHctc2hhZG93KTtcbiAgfVxuLnBhbmVsOmZpcnN0LW9mLXR5cGUge1xuICBwYWRkaW5nLWJvdHRvbTogMHB4O1xufVxuLnBhbmVsLWhlYWRlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLWJvdHRvbS13aWR0aDogMXB4O1xuICBib3JkZXItYm90dG9tLWNvbG9yOiByZ2IoMTU2IDE2MyAxNzUgLyAwLjQpO1xufVxuLnBhbmVsLWhlYWRlci1zdGFydCxcbiAgLnBhbmVsLWhlYWRlci1lbmQge1xuICBtYXJnaW46IDAuMjVyZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiA0MHB4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMC4zNzVyZW07XG4gIGZvbnQtZmFtaWx5OiB1aS1tb25vc3BhY2UsIFNGTW9uby1SZWd1bGFyLCBNZW5sbywgTW9uYWNvLCBDb25zb2xhcywgXCJMaWJlcmF0aW9uIE1vbm9cIiwgXCJDb3VyaWVyIE5ld1wiLCBtb25vc3BhY2U7XG59XG4ucGFuZWwtaGVhZGVyLXN0YXJ0OmhvdmVyLFxuICAucGFuZWwtaGVhZGVyLWVuZDpob3ZlciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigxNTYgMTYzIDE3NSAvIDAuMyk7XG59XG46aXMoLmRhcmsgLnBhbmVsLWhlYWRlci1zdGFydDpob3ZlciksOmlzKC5kYXJrIFxuICAucGFuZWwtaGVhZGVyLWVuZDpob3Zlcikge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1IDI1NSAyNTUgLyAwLjMpO1xufVxuLnBhbmVsLWhlYWRlci1taWRkbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4OiAxIDEgMCU7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmb250LXdlaWdodDogNTAwO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xufVxuLnBhbmVsLWhlYWRlci1zdGFydCA+IHN2ZyxcbiAgLnBhbmVsLWhlYWRlci1lbmQgPiBzdmcge1xuICBoZWlnaHQ6IDFyZW07XG4gIHdpZHRoOiAxcmVtO1xuICBmaWxsOiAjNDc1NTY5O1xufVxuOmlzKC5kYXJrIC5wYW5lbC1oZWFkZXItc3RhcnQgPiBzdmcpLDppcyguZGFyayBcbiAgLnBhbmVsLWhlYWRlci1lbmQgPiBzdmcpIHtcbiAgZmlsbDogI2UyZThmMDtcbn1cbi5wYW5lbC1ncm91cC1sYWJlbCB7XG4gIG1hcmdpbi1sZWZ0OiAwLjc1cmVtO1xuICBtYXJnaW4tcmlnaHQ6IDAuNzVyZW07XG4gIG1hcmdpbi10b3A6IDAuNXJlbTtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoNzUgODUgOTkgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbjppcyguZGFyayAucGFuZWwtZ3JvdXAtbGFiZWwpIHtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoMTU2IDE2MyAxNzUgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbi5wYW5lbC1ncm91cC1kaXZpZGVyIHtcbiAgbWFyZ2luLXRvcDogMC4xMjVyZW07XG4gIG1hcmdpbi1ib3R0b206IDAuMTI1cmVtO1xuICBib3JkZXItY29sb3I6IHJnYigxNTYgMTYzIDE3NSAvIDAuNCk7XG59XG46aXMoLmRhcmsgLnBhbmVsLWdyb3VwLWRpdmlkZXIpIHtcbiAgYm9yZGVyLWNvbG9yOiByZ2IoMjI5IDIzMSAyMzUgLyAwLjQpO1xufVxuLnBhbmVsLWdyb3VwLWl0ZW0ge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGhlaWdodDogMzJweDtcbiAgd2lkdGg6IDEwMCU7XG4gIHRyYW5zaXRpb24tcHJvcGVydHk6IGNvbG9yLCBiYWNrZ3JvdW5kLWNvbG9yLCBib3JkZXItY29sb3IsIHRleHQtZGVjb3JhdGlvbi1jb2xvciwgZmlsbCwgc3Ryb2tlLCBvcGFjaXR5LCBib3gtc2hhZG93LCB0cmFuc2Zvcm0sIGZpbHRlciwgYmFja2Ryb3AtZmlsdGVyO1xuICB0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuNCwgMCwgMC4yLCAxKTtcbiAgdHJhbnNpdGlvbi1kdXJhdGlvbjogMTUwbXM7XG59XG4ucGFuZWwtZ3JvdXAtaXRlbTpob3ZlciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigxNTYgMTYzIDE3NSAvIDAuMyk7XG59XG46aXMoLmRhcmsgLnBhbmVsLWdyb3VwLWl0ZW06aG92ZXIpIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE1NiAxNjMgMTc1IC8gMC40KTtcbn1cbi5wYW5lbC1ncm91cC1pdGVtLXN0YXJ0LFxuICAucGFuZWwtZ3JvdXAtaXRlbS1lbmQge1xuICBkaXNwbGF5OiBmbGV4O1xuICB3aWR0aDogNDBweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHBhZGRpbmc6IDAuMjVyZW07XG59XG4ucGFuZWwtZ3JvdXAtaXRlbS1zdGFydCA+IHN2ZyxcbiAgLnBhbmVsLWdyb3VwLWl0ZW0tZW5kID4gc3ZnIHtcbiAgaGVpZ2h0OiAxcmVtO1xuICB3aWR0aDogMXJlbTtcbiAgZmlsbDogIzBmMTcyYTtcbn1cbjppcyguZGFyayAucGFuZWwtZ3JvdXAtaXRlbS1zdGFydCA+IHN2ZyksOmlzKC5kYXJrIFxuICAucGFuZWwtZ3JvdXAtaXRlbS1lbmQgPiBzdmcpIHtcbiAgZmlsbDogI2UyZThmMDtcbn1cbi5wYW5lbC1ncm91cC1pdGVtLWVuZCA+IHN2ZyB7XG4gIGZpbGw6ICM0NzU1Njk7XG59XG46aXMoLmRhcmsgLnBhbmVsLWdyb3VwLWl0ZW0tZW5kID4gc3ZnKSB7XG4gIGZpbGw6ICM5NGEzYjg7XG59XG4ucGFuZWwtZ3JvdXAtaXRlbS1taWRkbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4OiAxIDEgMCU7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuLnBhbmVsLWdyb3VwLWl0ZW0tbWlkZGxlID4gaDIge1xuICBmb250LXdlaWdodDogNDAwO1xufVxuLmFic29sdXRlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xufVxuLnJlbGF0aXZlIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmluc2V0LTAge1xuICBpbnNldDogMHB4O1xufVxuLmxlZnQtMCB7XG4gIGxlZnQ6IDBweDtcbn1cbi5sZWZ0LTUge1xuICBsZWZ0OiAxLjI1cmVtO1xufVxuLnRvcC0wIHtcbiAgdG9wOiAwcHg7XG59XG4ubXgtYXV0byB7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG59XG4uLW1sLTcge1xuICBtYXJnaW4tbGVmdDogLTEuNzVyZW07XG59XG4uLW1yLTcge1xuICBtYXJnaW4tcmlnaHQ6IC0xLjc1cmVtO1xufVxuLm1sLTIge1xuICBtYXJnaW4tbGVmdDogMC41cmVtO1xufVxuLmJsb2NrIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4uZmxleCB7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG4uaC0xMiB7XG4gIGhlaWdodDogM3JlbTtcbn1cbi5oLTIwIHtcbiAgaGVpZ2h0OiA1cmVtO1xufVxuLmgtNCB7XG4gIGhlaWdodDogMXJlbTtcbn1cbi5oLTUge1xuICBoZWlnaHQ6IDEuMjVyZW07XG59XG4uaC1mdWxsIHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuLnctMTAge1xuICB3aWR0aDogMi41cmVtO1xufVxuLnctMTIge1xuICB3aWR0aDogM3JlbTtcbn1cbi53LTIwIHtcbiAgd2lkdGg6IDVyZW07XG59XG4udy00IHtcbiAgd2lkdGg6IDFyZW07XG59XG4udy01IHtcbiAgd2lkdGg6IDEuMjVyZW07XG59XG4udy1mdWxsIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5Aa2V5ZnJhbWVzIHNwaW4ge1xuXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgzNjBkZWcpO1xuICB9XG59XG4uYW5pbWF0ZS1cXFxcW3NwaW5fMFxcXFwuMnNfbGluZWFyX2luZmluaXRlXFxcXF0ge1xuICBhbmltYXRpb246IHNwaW4gMC4ycyBsaW5lYXIgaW5maW5pdGU7XG59XG4uY3Vyc29yLXBvaW50ZXIge1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG4uZmxleC1yb3cge1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xufVxuLmZsZXgtY29sIHtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cbi5pdGVtcy1jZW50ZXIge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmp1c3RpZnktZW5kIHtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbn1cbi5qdXN0aWZ5LWNlbnRlciB7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuLmp1c3RpZnktYmV0d2VlbiB7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cbi5nYXAtMSB7XG4gIGdhcDogMC4yNXJlbTtcbn1cbi5nYXAtMiB7XG4gIGdhcDogMC41cmVtO1xufVxuLnNwYWNlLXktMSA+IDpub3QoW2hpZGRlbl0pIH4gOm5vdChbaGlkZGVuXSkge1xuICAtLXR3LXNwYWNlLXktcmV2ZXJzZTogMDtcbiAgbWFyZ2luLXRvcDogY2FsYygwLjI1cmVtICogY2FsYygxIC0gdmFyKC0tdHctc3BhY2UteS1yZXZlcnNlKSkpO1xuICBtYXJnaW4tYm90dG9tOiBjYWxjKDAuMjVyZW0gKiB2YXIoLS10dy1zcGFjZS15LXJldmVyc2UpKTtcbn1cbi5yb3VuZGVkLWZ1bGwge1xuICBib3JkZXItcmFkaXVzOiA5OTk5cHg7XG59XG4ucm91bmRlZC1ibCB7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDAuMjVyZW07XG59XG4ucm91bmRlZC10bCB7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDAuMjVyZW07XG59XG4uYm9yZGVyIHtcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XG59XG4uYm9yZGVyLTAge1xuICBib3JkZXItd2lkdGg6IDBweDtcbn1cbi5ib3JkZXItdHJhbnNwYXJlbnQge1xuICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuLmJnLXNreS01MDBcXFxcLzQwIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE0IDE2NSAyMzMgLyAwLjQpO1xufVxuLmJnLXRyYW5zcGFyZW50IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG4uYmctd2hpdGUge1xuICAtLXR3LWJnLW9wYWNpdHk6IDE7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUgMjU1IDI1NSAvIHZhcigtLXR3LWJnLW9wYWNpdHkpKTtcbn1cbi5iZy1cXFxcW3VybFxcXFwoXFxcXCdcXFxcLlxcXFwuXFxcXC9cXFxcLlxcXFwuXFxcXC9hc3NldHNcXFxcL2ltYWdlc1xcXFwvaWl0a2dwLWxvZ29cXFxcLnN2Z1xcXFwnXFxcXClcXFxcXSB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCgke19fX0NTU19MT0FERVJfVVJMX1JFUExBQ0VNRU5UXzRfX199KTtcbn1cbi5iZy1jb250YWluIHtcbiAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xufVxuLmJnLW5vLXJlcGVhdCB7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG59XG4uZmlsbC1jdXJyZW50IHtcbiAgZmlsbDogY3VycmVudENvbG9yO1xufVxuLmZpbGwtc2xhdGUtNjAwIHtcbiAgZmlsbDogIzQ3NTU2OTtcbn1cbi5maWxsLXNsYXRlLTkwMCB7XG4gIGZpbGw6ICMwZjE3MmE7XG59XG4ucC00IHtcbiAgcGFkZGluZzogMXJlbTtcbn1cbi5wbC0yIHtcbiAgcGFkZGluZy1sZWZ0OiAwLjVyZW07XG59XG4ucGwtXFxcXFs0MHB4XFxcXF0ge1xuICBwYWRkaW5nLWxlZnQ6IDQwcHg7XG59XG4ucHItMyB7XG4gIHBhZGRpbmctcmlnaHQ6IDAuNzVyZW07XG59XG4udGV4dC1jZW50ZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4udGV4dC1sZyB7XG4gIGZvbnQtc2l6ZTogMS4xMjVyZW07XG4gIGxpbmUtaGVpZ2h0OiAxLjc1cmVtO1xufVxuLnRleHQteHMge1xuICBmb250LXNpemU6IDAuNzVyZW07XG4gIGxpbmUtaGVpZ2h0OiAxcmVtO1xufVxuLmZvbnQtbWVkaXVtIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi5mb250LXNlbWlib2xkIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbi50ZXh0LWdyYXktNjAwIHtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoNzUgODUgOTkgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbi50ZXh0LWdyYXktNzAwIHtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoNTUgNjUgODEgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbi50ZXh0LWdyYXktOTAwIHtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoMTcgMjQgMzkgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cbi5vcGFjaXR5LTI1IHtcbiAgb3BhY2l0eTogMC4yNTtcbn1cbi5vcGFjaXR5LTc1IHtcbiAgb3BhY2l0eTogMC43NTtcbn1cbi5zaGFkb3ctbm9uZSB7XG4gIC0tdHctc2hhZG93OiAwIDAgIzAwMDA7XG4gIC0tdHctc2hhZG93LWNvbG9yZWQ6IDAgMCAjMDAwMDtcbiAgYm94LXNoYWRvdzogdmFyKC0tdHctcmluZy1vZmZzZXQtc2hhZG93LCAwIDAgIzAwMDApLCB2YXIoLS10dy1yaW5nLXNoYWRvdywgMCAwICMwMDAwKSwgdmFyKC0tdHctc2hhZG93KTtcbn1cbi5vdXRsaW5lLW5vbmUge1xuICBvdXRsaW5lOiAycHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIG91dGxpbmUtb2Zmc2V0OiAycHg7XG59XG4ucmluZy0wIHtcbiAgLS10dy1yaW5nLW9mZnNldC1zaGFkb3c6IHZhcigtLXR3LXJpbmctaW5zZXQpIDAgMCAwIHZhcigtLXR3LXJpbmctb2Zmc2V0LXdpZHRoKSB2YXIoLS10dy1yaW5nLW9mZnNldC1jb2xvcik7XG4gIC0tdHctcmluZy1zaGFkb3c6IHZhcigtLXR3LXJpbmctaW5zZXQpIDAgMCAwIGNhbGMoMHB4ICsgdmFyKC0tdHctcmluZy1vZmZzZXQtd2lkdGgpKSB2YXIoLS10dy1yaW5nLWNvbG9yKTtcbiAgYm94LXNoYWRvdzogdmFyKC0tdHctcmluZy1vZmZzZXQtc2hhZG93KSwgdmFyKC0tdHctcmluZy1zaGFkb3cpLCB2YXIoLS10dy1zaGFkb3csIDAgMCAjMDAwMCk7XG59XG5cbi5iZy10aGVtZSB7XG4gIGJhY2tncm91bmQ6IHJnYigxODEsIDIxNCwgMjQzKSB1cmwoJHtfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF81X19ffSkgZml4ZWQgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xufVxuXG4uYmctdGhlbWUtZGFyayB7XG4gIGJhY2tncm91bmQ6IHJnYigxMCwgMTcsIDIzKSB1cmwoJHtfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF82X19ffSkgZml4ZWQgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xufVxuXG4uaG92ZXJcXFxcOmJnLWdyYXktNDAwXFxcXC8zMDpob3ZlciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigxNTYgMTYzIDE3NSAvIDAuMyk7XG59XG5cbi5mb2N1c1xcXFw6Ym9yZGVyLTA6Zm9jdXMge1xuICBib3JkZXItd2lkdGg6IDBweDtcbn1cblxuLmZvY3VzXFxcXDpvdXRsaW5lLW5vbmU6Zm9jdXMge1xuICBvdXRsaW5lOiAycHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIG91dGxpbmUtb2Zmc2V0OiAycHg7XG59XG5cbi5mb2N1c1xcXFw6cmluZy0wOmZvY3VzIHtcbiAgLS10dy1yaW5nLW9mZnNldC1zaGFkb3c6IHZhcigtLXR3LXJpbmctaW5zZXQpIDAgMCAwIHZhcigtLXR3LXJpbmctb2Zmc2V0LXdpZHRoKSB2YXIoLS10dy1yaW5nLW9mZnNldC1jb2xvcik7XG4gIC0tdHctcmluZy1zaGFkb3c6IHZhcigtLXR3LXJpbmctaW5zZXQpIDAgMCAwIGNhbGMoMHB4ICsgdmFyKC0tdHctcmluZy1vZmZzZXQtd2lkdGgpKSB2YXIoLS10dy1yaW5nLWNvbG9yKTtcbiAgYm94LXNoYWRvdzogdmFyKC0tdHctcmluZy1vZmZzZXQtc2hhZG93KSwgdmFyKC0tdHctcmluZy1zaGFkb3cpLCB2YXIoLS10dy1zaGFkb3csIDAgMCAjMDAwMCk7XG59XG5cbjppcyguZGFyayAuZGFya1xcXFw6YmctXFxcXFtcXFxcIzE5MTkxOVxcXFxdKSB7XG4gIC0tdHctYmctb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1IDI1IDI1IC8gdmFyKC0tdHctYmctb3BhY2l0eSkpO1xufVxuXG46aXMoLmRhcmsgLmRhcmtcXFxcOmJnLXNsYXRlLTIwMCkge1xuICAtLXR3LWJnLW9wYWNpdHk6IDE7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyMjYgMjMyIDI0MCAvIHZhcigtLXR3LWJnLW9wYWNpdHkpKTtcbn1cblxuOmlzKC5kYXJrIC5kYXJrXFxcXDpmaWxsLXNsYXRlLTIwMCkge1xuICBmaWxsOiAjZTJlOGYwO1xufVxuXG46aXMoLmRhcmsgLmRhcmtcXFxcOmZpbGwtc2xhdGUtNDAwKSB7XG4gIGZpbGw6ICM5NGEzYjg7XG59XG5cbjppcyguZGFyayAuZGFya1xcXFw6dGV4dC1ncmF5LTIwMCkge1xuICAtLXR3LXRleHQtb3BhY2l0eTogMTtcbiAgY29sb3I6IHJnYigyMjkgMjMxIDIzNSAvIHZhcigtLXR3LXRleHQtb3BhY2l0eSkpO1xufVxuXG46aXMoLmRhcmsgLmRhcmtcXFxcOnRleHQtZ3JheS00MDApIHtcbiAgLS10dy10ZXh0LW9wYWNpdHk6IDE7XG4gIGNvbG9yOiByZ2IoMTU2IDE2MyAxNzUgLyB2YXIoLS10dy10ZXh0LW9wYWNpdHkpKTtcbn1cblxuOmlzKC5kYXJrIC5kYXJrXFxcXDpob3ZlclxcXFw6YmctZ3JheS00MDBcXFxcLzQwOmhvdmVyKSB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigxNTYgMTYzIDE3NSAvIDAuNCk7XG59XG5gLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9wYWdlcy9Qb3B1cC9zdHlsZS5jc3NcIixcIjxubyBzb3VyY2U+XCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUFBOztDQUFjLENBQWQ7OztDQUFjOztBQUFkOzs7RUFBQSxzQkFBYyxFQUFkLE1BQWM7RUFBZCxlQUFjLEVBQWQsTUFBYztFQUFkLG1CQUFjLEVBQWQsTUFBYztFQUFkLHFCQUFjLEVBQWQsTUFBYztBQUFBOztBQUFkOztFQUFBLGdCQUFjO0FBQUE7O0FBQWQ7Ozs7Ozs7Q0FBYzs7QUFBZDtFQUFBLGdCQUFjLEVBQWQsTUFBYztFQUFkLDhCQUFjLEVBQWQsTUFBYztFQUFkLGdCQUFjLEVBQWQsTUFBYztFQUFkLFdBQWMsRUFBZCxNQUFjO0VBQWQsNE5BQWMsRUFBZCxNQUFjO0VBQWQsNkJBQWMsRUFBZCxNQUFjO0VBQWQsK0JBQWMsRUFBZCxNQUFjO0FBQUE7O0FBQWQ7OztDQUFjOztBQUFkO0VBQUEsU0FBYyxFQUFkLE1BQWM7RUFBZCxvQkFBYyxFQUFkLE1BQWM7QUFBQTs7QUFBZDs7OztDQUFjOztBQUFkO0VBQUEsU0FBYyxFQUFkLE1BQWM7RUFBZCxjQUFjLEVBQWQsTUFBYztFQUFkLHFCQUFjLEVBQWQsTUFBYztBQUFBOztBQUFkOztDQUFjOztBQUFkO0VBQUEsaUNBQWM7QUFBQTs7QUFBZDs7Q0FBYzs7QUFBZDs7Ozs7O0VBQUEsa0JBQWM7RUFBZCxvQkFBYztBQUFBOztBQUFkOztDQUFjOztBQUFkO0VBQUEsY0FBYztFQUFkLHdCQUFjO0FBQUE7O0FBQWQ7O0NBQWM7O0FBQWQ7O0VBQUEsbUJBQWM7QUFBQTs7QUFBZDs7O0NBQWM7O0FBQWQ7Ozs7RUFBQSwrR0FBYyxFQUFkLE1BQWM7RUFBZCxjQUFjLEVBQWQsTUFBYztBQUFBOztBQUFkOztDQUFjOztBQUFkO0VBQUEsY0FBYztBQUFBOztBQUFkOztDQUFjOztBQUFkOztFQUFBLGNBQWM7RUFBZCxjQUFjO0VBQWQsa0JBQWM7RUFBZCx3QkFBYztBQUFBOztBQUFkO0VBQUEsZUFBYztBQUFBOztBQUFkO0VBQUEsV0FBYztBQUFBOztBQUFkOzs7O0NBQWM7O0FBQWQ7RUFBQSxjQUFjLEVBQWQsTUFBYztFQUFkLHFCQUFjLEVBQWQsTUFBYztFQUFkLHlCQUFjLEVBQWQsTUFBYztBQUFBOztBQUFkOzs7O0NBQWM7O0FBQWQ7Ozs7O0VBQUEsb0JBQWMsRUFBZCxNQUFjO0VBQWQsOEJBQWMsRUFBZCxNQUFjO0VBQWQsZ0NBQWMsRUFBZCxNQUFjO0VBQWQsZUFBYyxFQUFkLE1BQWM7RUFBZCxvQkFBYyxFQUFkLE1BQWM7RUFBZCxvQkFBYyxFQUFkLE1BQWM7RUFBZCxjQUFjLEVBQWQsTUFBYztFQUFkLFNBQWMsRUFBZCxNQUFjO0VBQWQsVUFBYyxFQUFkLE1BQWM7QUFBQTs7QUFBZDs7Q0FBYzs7QUFBZDs7RUFBQSxvQkFBYztBQUFBOztBQUFkOzs7Q0FBYzs7QUFBZDs7OztFQUFBLDBCQUFjLEVBQWQsTUFBYztFQUFkLDZCQUFjLEVBQWQsTUFBYztFQUFkLHNCQUFjLEVBQWQsTUFBYztBQUFBOztBQUFkOztDQUFjOztBQUFkO0VBQUEsYUFBYztBQUFBOztBQUFkOztDQUFjOztBQUFkO0VBQUEsZ0JBQWM7QUFBQTs7QUFBZDs7Q0FBYzs7QUFBZDtFQUFBLHdCQUFjO0FBQUE7O0FBQWQ7O0NBQWM7O0FBQWQ7O0VBQUEsWUFBYztBQUFBOztBQUFkOzs7Q0FBYzs7QUFBZDtFQUFBLDZCQUFjLEVBQWQsTUFBYztFQUFkLG9CQUFjLEVBQWQsTUFBYztBQUFBOztBQUFkOztDQUFjOztBQUFkO0VBQUEsd0JBQWM7QUFBQTs7QUFBZDs7O0NBQWM7O0FBQWQ7RUFBQSwwQkFBYyxFQUFkLE1BQWM7RUFBZCxhQUFjLEVBQWQsTUFBYztBQUFBOztBQUFkOztDQUFjOztBQUFkO0VBQUEsa0JBQWM7QUFBQTs7QUFBZDs7Q0FBYzs7QUFBZDs7Ozs7Ozs7Ozs7OztFQUFBLFNBQWM7QUFBQTs7QUFBZDtFQUFBLFNBQWM7RUFBZCxVQUFjO0FBQUE7O0FBQWQ7RUFBQSxVQUFjO0FBQUE7O0FBQWQ7OztFQUFBLGdCQUFjO0VBQWQsU0FBYztFQUFkLFVBQWM7QUFBQTs7QUFBZDs7Q0FBYztBQUFkO0VBQUEsVUFBYztBQUFBOztBQUFkOztDQUFjOztBQUFkO0VBQUEsZ0JBQWM7QUFBQTs7QUFBZDs7O0NBQWM7O0FBQWQ7O0VBQUEsVUFBYyxFQUFkLE1BQWM7RUFBZCxjQUFjLEVBQWQsTUFBYztBQUFBOztBQUFkOztDQUFjOztBQUFkOztFQUFBLGVBQWM7QUFBQTs7QUFBZDs7Q0FBYztBQUFkO0VBQUEsZUFBYztBQUFBOztBQUFkOzs7O0NBQWM7O0FBQWQ7Ozs7Ozs7O0VBQUEsY0FBYyxFQUFkLE1BQWM7RUFBZCxzQkFBYyxFQUFkLE1BQWM7QUFBQTs7QUFBZDs7Q0FBYzs7QUFBZDs7RUFBQSxlQUFjO0VBQWQsWUFBYztBQUFBOztBQUFkLHdFQUFjO0FBQWQ7RUFBQSxhQUFjO0FBQUE7O0FBQWQ7RUFBQSxnQkFBYztFQUFkLHNCQUFjO0VBQWQscUJBQWM7RUFBZCxpQkFBYztFQUFkLGtCQUFjO0VBQWQsbUJBQWM7RUFBZCxzQkFBYztFQUFkLHNCQUFjO0VBQWQscUJBQWM7RUFBZCxlQUFjO0VBQWQsbUJBQWM7RUFBZCxzQkFBYztBQUFBOztBQUFkO0VBQUEsOEJBQWM7RUFBZCxtQkFBYztFQUFkLDRDQUFjO0VBQWQsMkJBQWM7RUFBZCw0QkFBYztFQUFkLHdCQUFjO0VBQWQsMkdBQWM7RUFBZCx5R0FBYztFQUFkLGlGQUFjO0VBQWQ7QUFBYzs7QUFBZDtFQUFBLGNBQWM7RUFBZDtBQUFjOztBQUFkO0VBQUE7QUFBYzs7QUFBZDtFQUFBO0FBQWM7O0FBQWQ7RUFBQSxjQUFjO0VBQWQ7QUFBYzs7QUFBZDtFQUFBLHlEQUFjO0VBQWQsd0NBQWM7RUFBZCw0QkFBYztFQUFkLDRCQUFjO0VBQWQscUJBQWM7RUFBZDtBQUFjOztBQUFkO0VBQUEseUJBQWM7RUFBZCw0QkFBYztFQUFkLHdCQUFjO0VBQWQsd0JBQWM7RUFBZCxzQkFBYztFQUFkO0FBQWM7O0FBQWQ7RUFBQSxnQkFBYztFQUFkLFVBQWM7RUFBZCx5QkFBYztFQUFkLHFCQUFjO0VBQWQsc0JBQWM7RUFBZCw2QkFBYztFQUFkLGlCQUFjO0VBQWQsY0FBYztFQUFkLFlBQWM7RUFBZCxXQUFjO0VBQWQsY0FBYztFQUFkLHNCQUFjO0VBQWQscUJBQWM7RUFBZCxpQkFBYztFQUFkO0FBQWM7O0FBQWQ7RUFBQTtBQUFjOztBQUFkO0VBQUE7QUFBYzs7QUFBZDtFQUFBLDhCQUFjO0VBQWQsbUJBQWM7RUFBZCw0Q0FBYztFQUFkLDJCQUFjO0VBQWQsNEJBQWM7RUFBZCx3QkFBYztFQUFkLDJHQUFjO0VBQWQseUdBQWM7RUFBZDtBQUFjOztBQUFkO0VBQUEseUJBQWM7RUFBZCw4QkFBYztFQUFkLDBCQUFjO0VBQWQsMkJBQWM7RUFBZDtBQUFjOztBQUFkO0VBQUE7QUFBYzs7QUFBZDtFQUFBO0FBQWM7O0FBQWQ7RUFBQSx5QkFBYztFQUFkO0FBQWM7O0FBQWQ7RUFBQSx5REFBYztFQUFkLHlCQUFjO0VBQWQsOEJBQWM7RUFBZCwwQkFBYztFQUFkLDJCQUFjO0VBQWQ7QUFBYzs7QUFBZDtFQUFBLHlCQUFjO0VBQWQ7QUFBYzs7QUFBZDtFQUFBLGlCQUFjO0VBQWQscUJBQWM7RUFBZCxlQUFjO0VBQWQsZ0JBQWM7RUFBZCxVQUFjO0VBQWQsZ0JBQWM7RUFBZDtBQUFjOztBQUFkO0VBQUEsNkJBQWM7RUFBZDtBQUFjO0VBQWQ7SUFBQSxxQkFBYztJQUFkLG1DQUFjO0lBQWQsa0NBQWM7SUFBZCxnQ0FBYztFQUFBOztFQUFkO0lBQUEsd0JBQWM7SUFBZCxrQ0FBYztJQUFkLGdCQUFjO0lBQWQsZUFBYztJQUFkLGdCQUFjO0lBQWQsa0JBQWM7SUFBZCxhQUFjO0lBQWQsWUFBYztJQUFkLGdCQUFjO0lBQWQsa0JBQWM7SUFBZCx5REFBYztJQUFkLG9CQUFjO0lBQWQsNkNBQWM7RUFBQTs7RUFBZDtFQUFBLGtCQUFjO0VBQWQsc0RBQWM7RUFBZCxvQkFBYztFQUFkO0FBQWM7O0VBQWQ7Ozs7OztFQUFBLFdBQWM7RUFBZCxlQUFjO0VBQWQsdUJBQWM7RUFBZCwwQ0FBYztFQUFkLHVEQUFjO0VBQWQ7QUFBYzs7RUFBZDs7Ozs7O0VBQUEsc0JBQWM7RUFBZCx3REFBYztFQUFkLG9CQUFjO0VBQWQ7QUFBYzs7RUFBZDs7Ozs7O0VBQUEsbUJBQWM7RUFBZDtBQUFjOztFQUFkOzs7Ozs7RUFBQTtBQUFjO0VBQWQ7RUFBQTtBQUFjO0VBQWQ7O0VBQUEsWUFBYztFQUFkLFdBQWM7RUFBZCxxQkFBYztFQUFkLHNCQUFjO0VBQWQseURBQWM7RUFBZCx3Q0FBYztFQUFkLG9CQUFjO0VBQWQ7QUFBYztFQUFkOztFQUFBLDJHQUFjO0VBQWQseUdBQWM7RUFBZCw0RkFBYztFQUFkLG9CQUFjO0VBQWQseURBQWM7RUFBZDtBQUFjO0VBQWQ7RUFBQSxxQkFBYztFQUFkLG9CQUFjO0VBQWQsOENBQWM7RUFBZCxpQkFBYztFQUFkO0FBQWM7O0VBQWQsNkJBQWM7RUFBZDtFQUFBLGlCQUFjO0VBQWQsa0JBQWM7RUFBZCxhQUFjO0VBQWQsWUFBYztFQUFkLFdBQWM7RUFBZCxzQkFBYztFQUFkO0FBQWM7RUFBZDtFQUFBLG9CQUFjO0VBQWQsT0FBYztFQUFkO0FBQWM7RUFBZDtFQUFBLE9BQWM7RUFBZDtBQUFjO0VBQWQ7RUFBQSxPQUFjO0VBQWQ7QUFBYztFQUFkO0VBQUEsT0FBYztFQUFkLGFBQWM7RUFBZDtBQUFjO0VBQWQ7Ozs7RUFBQSxnQkFBYztFQUFkLHdCQUFjO0VBQWQsMEJBQWM7RUFBZDtBQUFjO0VBQWQ7O0VBQUEsYUFBYztFQUFkLG1CQUFjO0VBQWQ7QUFBYztFQUFkO0VBQUEsU0FBYztFQUFkO0FBQWM7RUFBZDtFQUFBLGtCQUFjO0VBQWQ7QUFBYztFQUFkO0VBQUEsa0JBQWM7RUFBZDtBQUFjO0VBQWQsYUFBQSw2RUFBYyxFQUFkLFlBQWMsRUFBZCxlQUFjLEVBQWQsaUJBQWMsRUFBZCxrQkFBYyxFQUFkLG1CQUFjLEVBQWQsWUFBYyxFQUFkLFNBQWMsRUFBZCwyQkFBYyxFQUFkLHVCQUFjLEVBQWQsMkNBQWMsRUFBZCwwREFBYyxFQUFkLHVHQUFjO0VBQUE7RUFBZDtFQUFBLE9BQWM7RUFBZDtBQUFjO0VBQWQ7RUFBQSxrQkFBYztFQUFkO0FBQWM7RUFBZDtFQUFBLGtCQUFjO0VBQWQ7QUFBYztFQUFkLGdCQUFBLDZFQUFjLEVBQWQsV0FBYyxFQUFkLFNBQWMsRUFBZCxVQUFjLEVBQWQsa0JBQWMsRUFBZCxhQUFjLEVBQWQsT0FBYyxFQUFkLHNCQUFjLEVBQWQsdUJBQWM7RUFBQTtFQUFkO0VBQUEsdUJBQWM7RUFBZCw0REFBYztFQUFkO0FBQWM7RUFBZDtFQUFBLFVBQWM7RUFBZCwwQ0FBYztFQUFkLHVEQUFjO0VBQWQ7QUFBYzs7RUFBZCxTQUFjO0VBQWQ7RUFBQSxhQUFjO0VBQWQ7QUFBYztFQUFkOztFQUFBLHNCQUFjO0VBQWQsY0FBYztFQUFkLG1CQUFjO0VBQWQsb0JBQWM7RUFBZCxnQkFBYztFQUFkLG9CQUFjO0VBQWQ7QUFBYztFQUFkOztFQUFBLG9CQUFjO0VBQWQ7QUFBYztFQUFkO0VBQUEsa0JBQWM7RUFBZDtBQUFjO0VBQWQ7RUFBQSxrQkFBYztFQUFkLFNBQWM7RUFBZCxRQUFjO0VBQWQsYUFBYztFQUFkLFlBQWM7RUFBZCxhQUFjO0VBQWQsbUJBQWM7RUFBZCx1QkFBYztFQUFkLHVCQUFjO0VBQWQsc0JBQWM7RUFBZDtBQUFjO0VBQWQ7RUFBQTtBQUFjO0VBQWQ7RUFBQSxZQUFjO0VBQWQsV0FBYztFQUFkO0FBQWM7RUFBZDtFQUFBO0FBQWM7RUFBZDtFQUFBLFdBQWM7RUFBZCxzQkFBYztFQUFkLHlEQUFjO0VBQWQsa0JBQWM7RUFBZCxrQkFBYztFQUFkO0FBQWM7RUFBZDtFQUFBLDJCQUFjO0VBQWQ7QUFBYztFQUFkO0VBQUEsc0JBQWM7RUFBZCw4QkFBYztFQUFkO0FBQWM7RUFBZDtFQUFBLG9DQUFjO0VBQWQ7QUFBYzs7RUFBZCxZQUFjO0VBQWQ7RUFBQSxlQUFjO0VBQWQsdUJBQWM7RUFBZCxrQ0FBYztFQUFkLG9CQUFjO0VBQWQsdUJBQWM7RUFBZCxvQkFBYztFQUFkO0FBQWM7RUFBZDs7OztFQUFBLGFBQWM7RUFBZCxZQUFjO0VBQWQsZ0JBQWM7RUFBZCxtQkFBYztFQUFkLFdBQWM7RUFBZCx1QkFBYztFQUFkLGtCQUFjO0VBQWQseURBQWM7RUFBZCxtQkFBYztFQUFkLHNCQUFjO0VBQWQscUJBQWM7RUFBZCxzQkFBYztFQUFkLGdCQUFjO0VBQWQsb0JBQWM7RUFBZDtBQUFjO0VBQWQ7Ozs7RUFBQSxZQUFjO0VBQWQsV0FBYztFQUFkO0FBQWM7RUFBZDtFQUFBLGFBQWM7RUFBZCxZQUFjO0VBQWQsZ0JBQWM7RUFBZCxtQkFBYztFQUFkLFdBQWM7RUFBZCx1QkFBYztFQUFkLGtCQUFjO0VBQWQseURBQWM7RUFBZCxtQkFBYztFQUFkLHNCQUFjO0VBQWQscUJBQWM7RUFBZCxzQkFBYztFQUFkLGdCQUFjO0VBQWQsb0JBQWM7RUFBZDtBQUFjO0VBQWQ7RUFBQSxZQUFjO0VBQWQsV0FBYztFQUFkO0FBQWM7RUFBZDtFQUFBLGtCQUFjO0VBQWQ7QUFBYztFQUFkO0VBQUEsYUFBYztFQUFkLFlBQWM7RUFBZCxnQkFBYztFQUFkLG1CQUFjO0VBQWQsV0FBYztFQUFkLHVCQUFjO0VBQWQsa0JBQWM7RUFBZCx5REFBYztFQUFkLG1CQUFjO0VBQWQsc0JBQWM7RUFBZCxxQkFBYztFQUFkLHNCQUFjO0VBQWQsZ0JBQWM7RUFBZCxvQkFBYztFQUFkO0FBQWM7RUFBZDtFQUFBLFlBQWM7RUFBZCxXQUFjO0VBQWQ7QUFBYztFQUFkO0VBQUEsa0JBQWM7RUFBZDtBQUFjO0VBQWQ7RUFBQSxhQUFjO0VBQWQsWUFBYztFQUFkLGdCQUFjO0VBQWQsbUJBQWM7RUFBZCxXQUFjO0VBQWQsdUJBQWM7RUFBZCxrQkFBYztFQUFkLHlEQUFjO0VBQWQsbUJBQWM7RUFBZCxzQkFBYztFQUFkLHFCQUFjO0VBQWQsc0JBQWM7RUFBZCxnQkFBYztFQUFkLG9CQUFjO0VBQWQ7QUFBYztFQUFkO0VBQUEsWUFBYztFQUFkLFdBQWM7RUFBZDtBQUFjO0VBQWQ7RUFBQSxrQkFBYztFQUFkO0FBQWM7O0FBQWQ7RUFBQSx3QkFBYztFQUFkLHdCQUFjO0VBQWQsbUJBQWM7RUFBZCxtQkFBYztFQUFkLGNBQWM7RUFBZCxjQUFjO0VBQWQsY0FBYztFQUFkLGVBQWM7RUFBZCxlQUFjO0VBQWQsYUFBYztFQUFkLGFBQWM7RUFBZCxrQkFBYztFQUFkLHNDQUFjO0VBQWQsOEJBQWM7RUFBZCw2QkFBYztFQUFkLDRCQUFjO0VBQWQsZUFBYztFQUFkLG9CQUFjO0VBQWQsc0JBQWM7RUFBZCx1QkFBYztFQUFkLHdCQUFjO0VBQWQsa0JBQWM7RUFBZCwyQkFBYztFQUFkLDRCQUFjO0VBQWQsc0NBQWM7RUFBZCxrQ0FBYztFQUFkLDJCQUFjO0VBQWQsc0JBQWM7RUFBZCw4QkFBYztFQUFkLFlBQWM7RUFBZCxrQkFBYztFQUFkLGdCQUFjO0VBQWQsaUJBQWM7RUFBZCxrQkFBYztFQUFkLGNBQWM7RUFBZCxnQkFBYztFQUFkLGFBQWM7RUFBZCxtQkFBYztFQUFkLHFCQUFjO0VBQWQsMkJBQWM7RUFBZCx5QkFBYztFQUFkLDBCQUFjO0VBQWQsMkJBQWM7RUFBZCx1QkFBYztFQUFkLHdCQUFjO0VBQWQseUJBQWM7RUFBZDtBQUFjOztBQUFkO0VBQUEsd0JBQWM7RUFBZCx3QkFBYztFQUFkLG1CQUFjO0VBQWQsbUJBQWM7RUFBZCxjQUFjO0VBQWQsY0FBYztFQUFkLGNBQWM7RUFBZCxlQUFjO0VBQWQsZUFBYztFQUFkLGFBQWM7RUFBZCxhQUFjO0VBQWQsa0JBQWM7RUFBZCxzQ0FBYztFQUFkLDhCQUFjO0VBQWQsNkJBQWM7RUFBZCw0QkFBYztFQUFkLGVBQWM7RUFBZCxvQkFBYztFQUFkLHNCQUFjO0VBQWQsdUJBQWM7RUFBZCx3QkFBYztFQUFkLGtCQUFjO0VBQWQsMkJBQWM7RUFBZCw0QkFBYztFQUFkLHNDQUFjO0VBQWQsa0NBQWM7RUFBZCwyQkFBYztFQUFkLHNCQUFjO0VBQWQsOEJBQWM7RUFBZCxZQUFjO0VBQWQsa0JBQWM7RUFBZCxnQkFBYztFQUFkLGlCQUFjO0VBQWQsa0JBQWM7RUFBZCxjQUFjO0VBQWQsZ0JBQWM7RUFBZCxhQUFjO0VBQWQsbUJBQWM7RUFBZCxxQkFBYztFQUFkLDJCQUFjO0VBQWQseUJBQWM7RUFBZCwwQkFBYztFQUFkLDJCQUFjO0VBQWQsdUJBQWM7RUFBZCx3QkFBYztFQUFkLHlCQUFjO0VBQWQ7QUFBYztBQUNkO0VBQUE7QUFBb0I7QUFBcEI7O0VBQUE7SUFBQTtFQUFvQjtBQUFBO0FBQXBCOztFQUFBO0lBQUE7RUFBb0I7QUFBQTtBQUFwQjs7RUFBQTtJQUFBO0VBQW9CO0FBQUE7QUFBcEI7O0VBQUE7SUFBQTtFQUFvQjtBQUFBO0FBQXBCOztFQUFBO0lBQUE7RUFBb0I7QUFBQTtBQStJbEIsZUFBZTtBQUViO0VBQUEsb0JBQTRGO0VBQTVGO0FBQTRGO0FBQTVGO0VBQUEsb0JBQTRGO0VBQTVGO0FBQTRGO0FBQTVGO0VBQUEsb0JBQTRGO0VBQTVGO0FBQTRGO0FBQTVGO0VBQUEsb0JBQTRGO0VBQTVGO0FBQTRGO0FBSTVGOztFQUFBLG9CQUE2TTtFQUE3TSxtQkFBNk07RUFBN00sdUJBQTZNO0VBQTdNLFdBQTZNO0VBQTdNLHVCQUE2TTtFQUE3TSxpQkFBNk07RUFBN00seUJBQTZNO0VBQTdNLGtCQUE2TTtFQUE3TSx1REFBNk07RUFBN00sbUJBQTZNO0VBQTdNLHNCQUE2TTtFQUE3TSxrQkFBNk07RUFBN00sbUJBQTZNO0VBQTdNLGtCQUE2TTtFQUE3TSxpQkFBNk07RUFBN00sZ0JBQTZNO0VBQTdNLG9CQUE2TTtFQUE3TSxnREFBNk07RUFBN00sMENBQTZNO0VBQTdNLHVEQUE2TTtFQUE3TTtBQUE2TTtBQUE3TTs7RUFBQSxtQkFBNk07RUFBN00sa0JBQTZNO0VBQTdNO0FBQTZNO0FBSTdNOztFQUFBLFlBQXlCO0VBQXpCLFdBQXlCO0VBQXpCO0FBQXlCO0FBR3pCO0VBQUEscUNBQTZGO0VBQTdGLG9CQUE2RjtFQUE3RjtBQUE2RjtBQUE3RjtFQUFBO0FBQTZGO0FBQTdGO0VBQUEsa0JBQTZGO0VBQTdGLHNEQUE2RjtFQUE3RixvQkFBNkY7RUFBN0Y7QUFBNkY7QUFHN0Y7RUFBQSxZQUErQztFQUEvQyxXQUErQztFQUEvQztBQUErQztBQUEvQztFQUFBO0FBQStDO0FBR2pELFVBQVU7QUFFUjtFQUFBLGtCQUF5TjtFQUF6TjtBQUF5TjtBQUF6TjtFQUFBLGtCQUF5TjtFQUF6TjtBQUF5TjtBQUF6TixrQkFBQSw2RUFBeU4sRUFBek4sYUFBeU4sRUFBek4sbUJBQXlOLEVBQXpOLHVCQUF5TixFQUF6TixXQUF5TixFQUF6Tix1QkFBeU4sRUFBek4saUJBQXlOLEVBQXpOLHlCQUF5TixFQUF6TixtQkFBeU4sRUFBek4sc0JBQXlOLEVBQXpOLGtCQUF5TixFQUF6TixtQkFBeU4sRUFBek4sa0JBQXlOLEVBQXpOLGlCQUF5TixFQUF6TixnQkFBeU4sRUFBek4sb0JBQXlOLEVBQXpOLDBDQUF5TixFQUF6TiwrRUFBeU4sRUFBek4sbUdBQXlOLEVBQXpOLHVHQUF5TixFQUF6Tiw4QkFBeU4sRUFBek4sdVFBQXlOO0VBQUE7QUFBek47RUFBQTtBQUF5TjtBQUF6TjtFQUFBLG9CQUF5TjtFQUF6TjtBQUF5TjtBQUF6TjtFQUFBO0FBQXlOO0FBR3pOO0VBQUEsWUFBMkI7RUFBM0IsV0FBMkI7RUFBM0I7QUFBMkI7QUFHM0I7RUFBQTtBQUFnQjtBQUdoQjtFQUFBLGFBQWlFO0VBQWpFLFdBQWlFO0VBQWpFLG1CQUFpRTtFQUFqRSx1QkFBaUU7RUFBakUsV0FBaUU7RUFBakUsb0NBQWlFO0VBQWpFO0FBQWlFO0FBR2pFO0VBQUEsWUFBNEM7RUFBNUMsV0FBNEM7RUFBNUM7QUFBNEM7QUFBNUM7RUFBQTtBQUE0QztBQUc1QztFQUFBLG9CQUErRDtFQUEvRCx1QkFBK0Q7RUFBL0QsZ0JBQStEO0VBQS9ELHlCQUErRDtFQUEvRCxvQkFBK0Q7RUFBL0Q7QUFBK0Q7QUFBL0Q7RUFBQSxvQkFBK0Q7RUFBL0Q7QUFBK0Q7QUFHL0Q7RUFBQSxrQkFBaUY7RUFBakYsVUFBaUY7RUFBakYsV0FBaUY7RUFBakYsU0FBaUY7RUFBakYsaUJBQWlGO0VBQWpGLGtCQUFpRjtFQUFqRixhQUFpRjtFQUFqRixZQUFpRjtFQUFqRixtQkFBaUY7RUFBakYsZ0JBQWlGO0VBQWpGO0FBQWlGO0FBR2pGO0VBQUEsa0JBQW1LO0VBQW5LO0FBQW1LO0FBQW5LO0VBQUEsa0JBQW1LO0VBQW5LO0FBQW1LO0FBQW5LLFNBQUEsNkVBQW1LLEVBQW5LLFlBQW1LLEVBQW5LLGlCQUFtSyxFQUFuSyxXQUFtSyxFQUFuSyxjQUFtSyxFQUFuSyxZQUFtSyxFQUFuSyxnQkFBbUssRUFBbkssd0JBQW1LLEVBQW5LLGdCQUFtSyxFQUFuSyx1QkFBbUssRUFBbkssc0JBQW1LLEVBQW5LLDJDQUFtSyxFQUFuSywwREFBbUssRUFBbkssdUdBQW1LO0VBQUE7QUFHbks7RUFBQTtBQUFXO0FBR1g7RUFBQSxrQkFBa0U7RUFBbEUsYUFBa0U7RUFBbEUsWUFBa0U7RUFBbEUsV0FBa0U7RUFBbEUsd0JBQWtFO0VBQWxFO0FBQWtFO0FBSWxFOztFQUFBLGVBQXFIO0VBQXJILGFBQXFIO0VBQXJILFdBQXFIO0VBQXJILG1CQUFxSDtFQUFySCx1QkFBcUg7RUFBckgsdUJBQXFIO0VBQXJIO0FBQXFIO0FBQXJIOztFQUFBO0FBQXFIO0FBQXJIOztFQUFBO0FBQXFIO0FBR3JIO0VBQUEsYUFBb0U7RUFBcEUsWUFBb0U7RUFBcEUsbUJBQW9FO0VBQXBFLHVCQUFvRTtFQUFwRSxnQkFBb0U7RUFBcEU7QUFBb0U7QUFJcEU7O0VBQUEsWUFBaUQ7RUFBakQsV0FBaUQ7RUFBakQ7QUFBaUQ7QUFBakQ7O0VBQUE7QUFBaUQ7QUFHakQ7RUFBQSxvQkFBd0U7RUFBeEUscUJBQXdFO0VBQXhFLGtCQUF3RTtFQUF4RSxpQkFBd0U7RUFBeEUsZUFBd0U7RUFBeEUsb0JBQXdFO0VBQXhFO0FBQXdFO0FBQXhFO0VBQUEsb0JBQXdFO0VBQXhFO0FBQXdFO0FBR3hFO0VBQUEsb0JBQXdEO0VBQXhELHVCQUF3RDtFQUF4RDtBQUF3RDtBQUF4RDtFQUFBO0FBQXdEO0FBR3hEO0VBQUEsa0JBQThGO0VBQTlGLGFBQThGO0VBQTlGLFlBQThGO0VBQTlGLFdBQThGO0VBQTlGLHdKQUE4RjtFQUE5Rix3REFBOEY7RUFBOUY7QUFBOEY7QUFBOUY7RUFBQTtBQUE4RjtBQUE5RjtFQUFBO0FBQThGO0FBSTlGOztFQUFBLGFBQW9EO0VBQXBELFdBQW9EO0VBQXBELG1CQUFvRDtFQUFwRCx1QkFBb0Q7RUFBcEQ7QUFBb0Q7QUFJcEQ7O0VBQUEsWUFBaUQ7RUFBakQsV0FBaUQ7RUFBakQ7QUFBaUQ7QUFBakQ7O0VBQUE7QUFBaUQ7QUFHakQ7RUFBQTtBQUF5QztBQUF6QztFQUFBO0FBQXlDO0FBR3pDO0VBQUEsYUFBMEM7RUFBMUMsWUFBMEM7RUFBMUMsc0JBQTBDO0VBQTFDO0FBQTBDO0FBRzFDO0VBQUE7QUFBa0I7QUFuT3RCO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUEsaUJBQW1CO0VBQW5CO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7O0VBQUE7SUFBQTtFQUFtQjtBQUFBO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQSx1QkFBbUI7RUFBbkIsK0RBQW1CO0VBQW5CO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBLGtCQUFtQjtFQUFuQjtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQSxtQkFBbUI7RUFBbkI7QUFBbUI7QUFBbkI7RUFBQSxrQkFBbUI7RUFBbkI7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBO0FBQW1CO0FBQW5CO0VBQUEsb0JBQW1CO0VBQW5CO0FBQW1CO0FBQW5CO0VBQUEsb0JBQW1CO0VBQW5CO0FBQW1CO0FBQW5CO0VBQUEsb0JBQW1CO0VBQW5CO0FBQW1CO0FBQW5CO0VBQUE7QUFBbUI7QUFBbkI7RUFBQTtBQUFtQjtBQUFuQjtFQUFBLHNCQUFtQjtFQUFuQiw4QkFBbUI7RUFBbkI7QUFBbUI7QUFBbkI7RUFBQSw4QkFBbUI7RUFBbkI7QUFBbUI7QUFBbkI7RUFBQSwyR0FBbUI7RUFBbkIseUdBQW1CO0VBQW5CO0FBQW1COztBQUVuQjtFQUNFLG1GQUE2RTtFQUM3RSxzQkFBc0I7RUFDdEIsNEJBQTRCO0FBQzlCOztBQUVBO0VBQ0UsZ0ZBQStFO0VBQy9FLHNCQUFzQjtFQUN0Qiw0QkFBNEI7QUFDOUI7O0FBZEE7RUFBQTtDQ0FBOztBREFBO0VBQUE7Q0NBQTs7QURBQTtFQUFBLCtCQ0FBO0VEQUE7Q0NBQTs7QURBQTtFQUFBLDRHQ0FBO0VEQUEsMEdDQUE7RURBQTtDQ0FBOztBREFBO0VBQUEsbUJDQUE7RURBQTtDQ0FBOztBREFBO0VBQUEsbUJDQUE7RURBQTtDQ0FBOztBREFBO0VBQUE7Q0NBQTs7QURBQTtFQUFBO0NDQUE7O0FEQUE7RUFBQSxxQkNBQTtFREFBO0NDQUE7O0FEQUE7RUFBQSxxQkNBQTtFREFBO0NDQUE7O0FEQUE7RUFBQTtDQ0FBXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIkB0YWlsd2luZCBiYXNlO1xcbkB0YWlsd2luZCBjb21wb25lbnRzO1xcbkB0YWlsd2luZCB1dGlsaXRpZXM7XFxuXFxuLmJnLXRoZW1lIHtcXG4gIGJhY2tncm91bmQ6IHJnYigxODEsIDIxNCwgMjQzKSB1cmwoJy4uLy4uL2Fzc2V0cy9pbWFnZXMvYmcuanBnJykgZml4ZWQgY2VudGVyO1xcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XFxufVxcblxcbi5iZy10aGVtZS1kYXJrIHtcXG4gIGJhY2tncm91bmQ6IHJnYigxMCwgMTcsIDIzKSB1cmwoJy4uLy4uL2Fzc2V0cy9pbWFnZXMvYmctZGFyay5wbmcnKSBmaXhlZCBjZW50ZXI7XFxuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcXG59XFxuXFxuQGxheWVyIGJhc2Uge1xcbiAgKiB7XFxuICAgIHNjcm9sbGJhci13aWR0aDogbm9uZTtcXG4gICAgLXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XFxuICAgIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XFxuICAgIHNjcm9sbC1iZWhhdmlvcjogYXV0byAhaW1wb3J0YW50O1xcbiAgfVxcblxcbiAgYm9keSB7XFxuICAgIGNvbG9yLXNjaGVtZTogbGlnaHQgZGFyaztcXG4gICAgZm9udC1mYW1pbHk6IHN5c3RlbS11aSwgc2Fucy1zZXJpZjtcXG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcXG4gICAgZm9udC1zaXplOiAxM3B4O1xcbiAgICBsaW5lLWhlaWdodDogMS43O1xcbiAgICBAYXBwbHkgcmVsYXRpdmUgaC1bNjAwcHhdIHctWzM0OHB4XSBvdmVyZmxvdy1oaWRkZW4gYmctZ3JheS0yMDAgdGV4dC1ncmF5LTgwMCBkYXJrOmJnLVsjMTkxOTE5XSBkYXJrOnRleHQtZ3JheS0yMDA7XFxuICB9XFxuXFxuICBbdHlwZT0ndGV4dCddLFxcbiAgW3R5cGU9J3Bhc3N3b3JkJ10sXFxuICBbdHlwZT0nbnVtYmVyJ10sXFxuICBbbXVsdGlwbGVdLFxcbiAgdGV4dGFyZWEsXFxuICBzZWxlY3Qge1xcbiAgICBAYXBwbHkgdy1mdWxsIGN1cnNvci1wb2ludGVyIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6YmctYmxhY2svMTAgZGFyazpkaXNhYmxlZDpiZy1bIzRBNEE0QV0vODA7XFxuICB9XFxuICBzZWxlY3Qge1xcbiAgICBAYXBwbHkgZm9udC1ub3JtYWw7XFxuICB9XFxuICBbdHlwZT0nY2hlY2tib3gnXSxcXG4gIFt0eXBlPSdyYWRpbyddIHtcXG4gICAgQGFwcGx5IGgtNCB3LTQgcm91bmRlZC1mdWxsIGJvcmRlci1ncmF5LTMwMCBiZy13aGl0ZS8yMCB0ZXh0LWluZGlnby02MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpyaW5nLW9mZnNldC0wO1xcbiAgfVxcblxcbiAgLmJnLWNhcmQge1xcbiAgICBAYXBwbHkgYmctd2hpdGUgZGFyazpiZy1bIzI0MjUyNl07IC8qIHRvIGFkZCBibHVyLCBAYXBwbHkgYmctd2hpdGUvNDAgYmFja2Ryb3AtYmx1ci1tZCBkYXJrOmJnLVsjMjQyNTI2XS80MDsgfSAqL1xcbiAgfVxcbiAgLnJlcXVpcmVkLWFzdGVyaXNrIHtcXG4gICAgQGFwcGx5IGFmdGVyOm1sLTAuNSBhZnRlcjp0ZXh0LXJlZC01MDAgYWZ0ZXI6Y29udGVudC1bJyonXTtcXG4gIH1cXG5cXG4gIC8qIG1haW4gbGF5b3V0IChmdWxsIHBvcHVwKSAqL1xcbiAgLmJveC1jb250YWluZXIge1xcbiAgICBAYXBwbHkgbXgtYXV0byBmbGV4IGgtZnVsbCB3LWZ1bGwgZmxleC1jb2wgaXRlbXMtc3RyZXRjaDtcXG4gIH1cXG4gIC5ib3gtY29udGFpbmVyLnJpZ2h0LW9wZW4gLmJveDEtY29udGVudCB7XFxuICAgIEBhcHBseSBwb2ludGVyLWV2ZW50cy1ub25lIGZsZXgtWzBdIG9wYWNpdHktMDtcXG4gIH1cXG4gIC5ib3gtY29udGFpbmVyLnJpZ2h0LW9wZW4gLmJveDEtc2lkZSB7XFxuICAgIEBhcHBseSBmbGV4LVswXSBvcGFjaXR5LTA7XFxuICB9XFxuICAuYm94LWNvbnRhaW5lci5yaWdodC1vcGVuIC5ib3gyLXNpZGUge1xcbiAgICBAYXBwbHkgZmxleC1bMV0gb3BhY2l0eS0xMDA7XFxuICB9XFxuICAuYm94LWNvbnRhaW5lci5yaWdodC1vcGVuIC5ib3gyLWNvbnRlbnQge1xcbiAgICBAYXBwbHkgZmxleC1bNV0gcC00IG9wYWNpdHktMTAwO1xcbiAgfVxcbiAgLmJveDEtY29udGVudCxcXG4gIC5ib3gxLXNpZGUsXFxuICAuYm94Mi1jb250ZW50LFxcbiAgLmJveDItc2lkZSB7XFxuICAgIEBhcHBseSBvdmVyZmxvdy1oaWRkZW4gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0O1xcbiAgfVxcbiAgLmJveDEtc2lkZSxcXG4gIC5ib3gyLXNpZGUge1xcbiAgICBAYXBwbHkgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXI7XFxuICB9XFxuICAuYm94MS1jb250ZW50IHtcXG4gICAgQGFwcGx5IGZsZXgtWzUuNF0gb3BhY2l0eS0xMDA7XFxuICB9XFxuICAuYm94MS1zaWRlIHtcXG4gICAgQGFwcGx5IGJnLWNhcmQgaW5zZXQteS0xIG14LTQgbWItNCBoLWZ1bGwgZmxleC1bMC42XSBqdXN0aWZ5LXN0YXJ0IHJvdW5kZWQtbWQgc2hhZG93LVswXzNweF8ycHhfLTFweF9yZ2JhKDAsMCwwLDAuMSldO1xcbiAgfVxcbiAgLmJveDItc2lkZSB7XFxuICAgIEBhcHBseSBmbGV4LVswXSBvcGFjaXR5LTA7XFxuICB9XFxuICAuYm94Mi1jb250ZW50IHtcXG4gICAgQGFwcGx5IGJnLWNhcmQgYm90dG9tLTAgbGVmdC0wIHJpZ2h0LTAgbWItMCBmbGV4IGZsZXgtWzBdIGZsZXgtY29sIGp1c3RpZnktY2VudGVyIHNwYWNlLXktNCBvcGFjaXR5LTAgc2hhZG93LXNtO1xcbiAgfVxcblxcbiAgLyogRm9ybSAqL1xcbiAgLmZvcm0tdGV4dGJveCB7XFxuICAgIEBhcHBseSBmbGV4IGZsZXgtY29sO1xcbiAgfVxcbiAgLmZvcm0tdGV4dGJveCA+IGxhYmVsLFxcbiAgLmZvcm0tdGV4dGJveC1sYWJlbCB7XFxuICAgIEBhcHBseSBtYi0xIGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0yMDA7XFxuICB9XFxuICAuZm9ybS10ZXh0Ym94ID4gZGl2IHtcXG4gICAgQGFwcGx5IHJlbGF0aXZlIHctZnVsbDtcXG4gIH1cXG4gIC5mb3JtLXRleHRib3ggPiBkaXYgPiBkaXYge1xcbiAgICBAYXBwbHkgYWJzb2x1dGUgbGVmdC0wIHRvcC0wIGZsZXggaC1mdWxsIHctMTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlci1yLVsxcHhdIGJvcmRlci1ncmF5LTMwMCBkYXJrOmJvcmRlci1ncmF5LTMwMC8xMDtcXG4gIH1cXG4gIC5mb3JtLXRleHRib3ggPiBkaXYgPiBkaXYgPiBzdmcge1xcbiAgICBAYXBwbHkgaC00IHctNCBmaWxsLWN1cnJlbnQgZGFyazpmaWxsLXNsYXRlLTIwMDtcXG4gIH1cXG4gIC5mb3JtLXRleHRib3ggPiBkaXYgPiBpbnB1dCB7XFxuICAgIEBhcHBseSB3LWZ1bGwgYm9yZGVyLWdyYXktMzAwIHBsLTEyIHRleHQteHMgcGxhY2Vob2xkZXItZ3JheS00MDAgZGlzYWJsZWQ6c2hhZG93LW5vbmUgZGFyazpib3JkZXItZ3JheS0zMDAvMTAgZGFyazpiZy13aGl0ZS81O1xcbiAgfVxcblxcbiAgLyogTWVzc2FnZSAqL1xcbiAgLmFjdGlvbiB7XFxuICAgIEBhcHBseSBjdXJzb3ItcG9pbnRlciByb3VuZGVkLXNtIGJnLWJsYWNrLzEwIHB5LTEgcHgtMjtcXG4gIH1cXG4gIC5pbmZvLFxcbiAgLndhcm5pbmcsXFxuICAuZXJyb3IsXFxuICAuc3VjY2VzcyB7XFxuICAgIEBhcHBseSBmbGV4IGgtZnVsbCBtYXgtaC04IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLW1kIGJnLXNsYXRlLTQwMCBweS0yIHB4LTMgZm9udC1ub3JtYWwgdGV4dC1ibGFjaztcXG4gIH1cXG4gIC5pbmZvID4gc3ZnLFxcbiAgLndhcm5pbmcgPiBzdmcsXFxuICAuZXJyb3IgPiBzdmcsXFxuICAuc3VjY2VzcyA+IHN2ZyB7XFxuICAgIEBhcHBseSBoLTQgdy00IGZpbGwtY3VycmVudDtcXG4gIH1cXG4gIC53YXJuaW5nIHtcXG4gICAgQGFwcGx5IGluZm8gYmcteWVsbG93LTMwMDtcXG4gIH1cXG4gIC5lcnJvciB7XFxuICAgIEBhcHBseSBpbmZvIGJnLXJlZC0zMDA7XFxuICB9XFxuICAuc3VjY2VzcyB7XFxuICAgIEBhcHBseSBpbmZvIGJnLWdyZWVuLTMwMDtcXG4gIH1cXG59XFxuXFxuQGxheWVyIGNvbXBvbmVudHMge1xcbiAgLyogQ29tcG9uZW50cyAqL1xcbiAgLmxpbmstdGV4dCB7XFxuICAgIEBhcHBseSB0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tNTAwIGRhcms6dGV4dC1pbmRpZ28tNDAwIGRhcms6aG92ZXI6dGV4dC1pbmRpZ28tNTAwO1xcbiAgfVxcbiAgLnN2Zy1idG4tcHJpbWFyeSxcXG4gIC5zdmctYnRuLXNlY29uZGFyeSB7XFxuICAgIEBhcHBseSBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGJnLWluZGlnby02MDAgcHktMiBweC00IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBzaGFkb3ctc20gZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIGRpc2FibGVkOmJnLWluZGlnby0zMDA7XFxuICB9XFxuICAuc3ZnLWJ0bi1wcmltYXJ5ID4gc3ZnLFxcbiAgLnN2Zy1idG4tc2Vjb25kYXJ5ID4gc3ZnIHtcXG4gICAgQGFwcGx5IGgtNCB3LTQgZmlsbC13aGl0ZTtcXG4gIH1cXG4gIC5zdmctYnRuLXNlY29uZGFyeSB7XFxuICAgIEBhcHBseSBiZy1ncmF5LTYwMC80MCB0ZXh0LWdyYXktOTAwIGhvdmVyOmJnLWdyYXktNjAwLzMwIGRhcms6Ymctc2xhdGUtNzAwIGRhcms6dGV4dC1ncmF5LTMwMDtcXG4gIH1cXG4gIC5zdmctYnRuLXNlY29uZGFyeSA+IHN2ZyB7XFxuICAgIEBhcHBseSBoLTQgdy00IGZpbGwtZ3JheS05MDAgZGFyazpmaWxsLWdyYXktMzAwO1xcbiAgfVxcblxcbiAgLyogcGFuZWwgKi9cXG4gIC5ib3gtdG9nZ2xlLWJ0biB7XFxuICAgIEBhcHBseSBiZy1jYXJkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBweS0yIHB4LTQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWJsYWNrICBzaGFkb3ctbGcgYmFja2Ryb3AtYmx1ci1tZCBob3ZlcjpiZy13aGl0ZS80MCBkYXJrOnRleHQtd2hpdGUgIGhvdmVyOmRhcms6YmctYmxhY2svNDA7XFxuICB9XFxuICAuYm94LXRvZ2dsZS1idG4gPiBzdmcge1xcbiAgICBAYXBwbHkgaC00IHctNCBmaWxsLWN1cnJlbnQ7XFxuICB9XFxuICAuYm94LXRvZ2dsZS1idG4gPiBzcGFuIHtcXG4gICAgQGFwcGx5IHVwcGVyY2FzZTtcXG4gIH1cXG4gIC5ib3gtdG9nZ2xlLWJ0bi1wYW5lbC1pdGVtIHtcXG4gICAgQGFwcGx5IGZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiByb3VuZGVkLWItbWQ7XFxuICB9XFxuICAuYm94LXRvZ2dsZS1idG4tcGFuZWwtaXRlbSA+IHN2ZyB7XFxuICAgIEBhcHBseSBoLTQgdy00IGZpbGwtYmxhY2sgZGFyazpmaWxsLWdyYXktOTAwO1xcbiAgfVxcbiAgLmJveC10b2dnbGUtYnRuLXBhbmVsLWl0ZW0gPiBzcGFuIHtcXG4gICAgQGFwcGx5IHB5LTEgZm9udC1ub3JtYWwgdXBwZXJjYXNlIHRleHQtYmxhY2sgZGFyazp0ZXh0LWdyYXktOTAwO1xcbiAgfVxcbiAgLnBhbmVsLWNvbnRhaW5lciB7XFxuICAgIEBhcHBseSBhYnNvbHV0ZSBpbnNldC14LTQgdG9wLTQgbXgtYXV0byBmbGV4IGZsZXgtMSBmbGV4LXJvdyBvdmVyZmxvdy1oaWRkZW4gcGItMjtcXG4gIH1cXG4gIC5wYW5lbCB7XFxuICAgIEBhcHBseSBiZy1jYXJkIGgtZnVsbCBtYXgtaC1bNDkwcHhdICB3LWZ1bGwgZmxleC1zaHJpbmstMCBmbGV4LWdyb3ctMCBiYXNpcy1mdWxsIHNuYXAtc3RhcnQgb3ZlcmZsb3cteS1hdXRvIHJvdW5kZWQtbWQgcGItMiBzaGFkb3ctWzBfM3B4XzJweF8tMXB4X3JnYmEoMCwwLDAsMC4xKV07XFxuICB9XFxuICAucGFuZWw6Zmlyc3Qtb2YtdHlwZSB7XFxuICAgIEBhcHBseSBwYi0wO1xcbiAgfVxcbiAgLnBhbmVsLWhlYWRlciB7XFxuICAgIEBhcHBseSByZWxhdGl2ZSBmbGV4IGgtWzQwcHhdIHctZnVsbCBib3JkZXItYiBib3JkZXItYi1ncmF5LTQwMC80MDtcXG4gIH1cXG4gIC5wYW5lbC1oZWFkZXItc3RhcnQsXFxuICAucGFuZWwtaGVhZGVyLWVuZCB7XFxuICAgIEBhcHBseSBtLTEgZmxleCB3LVs0MHB4XSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1tZCBmb250LW1vbm8gaG92ZXI6YmctZ3JheS00MDAvMzAgZGFyazpob3ZlcjpiZy13aGl0ZS8zMDtcXG4gIH1cXG4gIC5wYW5lbC1oZWFkZXItbWlkZGxlIHtcXG4gICAgQGFwcGx5IGZsZXggZmxleC0xIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LW1lZGl1bSB1cHBlcmNhc2U7XFxuICB9XFxuICAucGFuZWwtaGVhZGVyLXN0YXJ0ID4gc3ZnLFxcbiAgLnBhbmVsLWhlYWRlci1lbmQgPiBzdmcge1xcbiAgICBAYXBwbHkgaC00IHctNCBmaWxsLXNsYXRlLTYwMCBkYXJrOmZpbGwtc2xhdGUtMjAwO1xcbiAgfVxcbiAgLnBhbmVsLWdyb3VwLWxhYmVsIHtcXG4gICAgQGFwcGx5IG14LTMgbXQtMiB0ZXh0LXJpZ2h0IHRleHQtWzExcHhdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwO1xcbiAgfVxcbiAgLnBhbmVsLWdyb3VwLWRpdmlkZXIge1xcbiAgICBAYXBwbHkgbXktMC41IGJvcmRlci1ncmF5LTQwMC80MCBkYXJrOmJvcmRlci1ncmF5LTIwMC80MDtcXG4gIH1cXG4gIC5wYW5lbC1ncm91cC1pdGVtIHtcXG4gICAgQGFwcGx5IHJlbGF0aXZlIGZsZXggaC1bMzJweF0gdy1mdWxsIHRyYW5zaXRpb24gaG92ZXI6YmctZ3JheS00MDAvMzAgZGFyazpob3ZlcjpiZy1ncmF5LTQwMC80MDtcXG4gIH1cXG4gIC5wYW5lbC1ncm91cC1pdGVtLXN0YXJ0LFxcbiAgLnBhbmVsLWdyb3VwLWl0ZW0tZW5kIHtcXG4gICAgQGFwcGx5IGZsZXggdy1bNDBweF0gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMTtcXG4gIH1cXG4gIC5wYW5lbC1ncm91cC1pdGVtLXN0YXJ0ID4gc3ZnLFxcbiAgLnBhbmVsLWdyb3VwLWl0ZW0tZW5kID4gc3ZnIHtcXG4gICAgQGFwcGx5IGgtNCB3LTQgZmlsbC1zbGF0ZS05MDAgZGFyazpmaWxsLXNsYXRlLTIwMDtcXG4gIH1cXG4gIC5wYW5lbC1ncm91cC1pdGVtLWVuZCA+IHN2ZyB7XFxuICAgIEBhcHBseSBmaWxsLXNsYXRlLTYwMCBkYXJrOmZpbGwtc2xhdGUtNDAwO1xcbiAgfVxcbiAgLnBhbmVsLWdyb3VwLWl0ZW0tbWlkZGxlIHtcXG4gICAgQGFwcGx5IGZsZXggZmxleC0xIGZsZXgtY29sIGp1c3RpZnktY2VudGVyO1xcbiAgfVxcbiAgLnBhbmVsLWdyb3VwLWl0ZW0tbWlkZGxlID4gaDIge1xcbiAgICBAYXBwbHkgZm9udC1ub3JtYWw7XFxuICB9XFxuICAucGFuZWwtZm9vdGVyIHtcXG4gICAgQGFwcGx5IHJlbGF0aXZlIG10LTQgdGV4dC1jZW50ZXIgdGV4dC1bMTFweF07XFxuICB9XFxuICAucGFuZWwtZm9vdGVyID4gYSB7XFxuICAgIEBhcHBseSB0ZXh0LWluZGlnby01MDAgZGFyazp0ZXh0LWluZGlnby0zMDA7XFxuICB9XFxufVxcblwiLG51bGxdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsIlwidXNlIHN0cmljdFwiO1xuXG4vKlxuICBNSVQgTGljZW5zZSBodHRwOi8vd3d3Lm9wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL21pdC1saWNlbnNlLnBocFxuICBBdXRob3IgVG9iaWFzIEtvcHBlcnMgQHNva3JhXG4qL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoY3NzV2l0aE1hcHBpbmdUb1N0cmluZykge1xuICB2YXIgbGlzdCA9IFtdO1xuXG4gIC8vIHJldHVybiB0aGUgbGlzdCBvZiBtb2R1bGVzIGFzIGNzcyBzdHJpbmdcbiAgbGlzdC50b1N0cmluZyA9IGZ1bmN0aW9uIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiB0aGlzLm1hcChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgdmFyIGNvbnRlbnQgPSBcIlwiO1xuICAgICAgdmFyIG5lZWRMYXllciA9IHR5cGVvZiBpdGVtWzVdICE9PSBcInVuZGVmaW5lZFwiO1xuICAgICAgaWYgKGl0ZW1bNF0pIHtcbiAgICAgICAgY29udGVudCArPSBcIkBzdXBwb3J0cyAoXCIuY29uY2F0KGl0ZW1bNF0sIFwiKSB7XCIpO1xuICAgICAgfVxuICAgICAgaWYgKGl0ZW1bMl0pIHtcbiAgICAgICAgY29udGVudCArPSBcIkBtZWRpYSBcIi5jb25jYXQoaXRlbVsyXSwgXCIge1wiKTtcbiAgICAgIH1cbiAgICAgIGlmIChuZWVkTGF5ZXIpIHtcbiAgICAgICAgY29udGVudCArPSBcIkBsYXllclwiLmNvbmNhdChpdGVtWzVdLmxlbmd0aCA+IDAgPyBcIiBcIi5jb25jYXQoaXRlbVs1XSkgOiBcIlwiLCBcIiB7XCIpO1xuICAgICAgfVxuICAgICAgY29udGVudCArPSBjc3NXaXRoTWFwcGluZ1RvU3RyaW5nKGl0ZW0pO1xuICAgICAgaWYgKG5lZWRMYXllcikge1xuICAgICAgICBjb250ZW50ICs9IFwifVwiO1xuICAgICAgfVxuICAgICAgaWYgKGl0ZW1bMl0pIHtcbiAgICAgICAgY29udGVudCArPSBcIn1cIjtcbiAgICAgIH1cbiAgICAgIGlmIChpdGVtWzRdKSB7XG4gICAgICAgIGNvbnRlbnQgKz0gXCJ9XCI7XG4gICAgICB9XG4gICAgICByZXR1cm4gY29udGVudDtcbiAgICB9KS5qb2luKFwiXCIpO1xuICB9O1xuXG4gIC8vIGltcG9ydCBhIGxpc3Qgb2YgbW9kdWxlcyBpbnRvIHRoZSBsaXN0XG4gIGxpc3QuaSA9IGZ1bmN0aW9uIGkobW9kdWxlcywgbWVkaWEsIGRlZHVwZSwgc3VwcG9ydHMsIGxheWVyKSB7XG4gICAgaWYgKHR5cGVvZiBtb2R1bGVzID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBtb2R1bGVzID0gW1tudWxsLCBtb2R1bGVzLCB1bmRlZmluZWRdXTtcbiAgICB9XG4gICAgdmFyIGFscmVhZHlJbXBvcnRlZE1vZHVsZXMgPSB7fTtcbiAgICBpZiAoZGVkdXBlKSB7XG4gICAgICBmb3IgKHZhciBrID0gMDsgayA8IHRoaXMubGVuZ3RoOyBrKyspIHtcbiAgICAgICAgdmFyIGlkID0gdGhpc1trXVswXTtcbiAgICAgICAgaWYgKGlkICE9IG51bGwpIHtcbiAgICAgICAgICBhbHJlYWR5SW1wb3J0ZWRNb2R1bGVzW2lkXSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgZm9yICh2YXIgX2sgPSAwOyBfayA8IG1vZHVsZXMubGVuZ3RoOyBfaysrKSB7XG4gICAgICB2YXIgaXRlbSA9IFtdLmNvbmNhdChtb2R1bGVzW19rXSk7XG4gICAgICBpZiAoZGVkdXBlICYmIGFscmVhZHlJbXBvcnRlZE1vZHVsZXNbaXRlbVswXV0pIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIGxheWVyICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIGlmICh0eXBlb2YgaXRlbVs1XSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgIGl0ZW1bNV0gPSBsYXllcjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpdGVtWzFdID0gXCJAbGF5ZXJcIi5jb25jYXQoaXRlbVs1XS5sZW5ndGggPiAwID8gXCIgXCIuY29uY2F0KGl0ZW1bNV0pIDogXCJcIiwgXCIge1wiKS5jb25jYXQoaXRlbVsxXSwgXCJ9XCIpO1xuICAgICAgICAgIGl0ZW1bNV0gPSBsYXllcjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKG1lZGlhKSB7XG4gICAgICAgIGlmICghaXRlbVsyXSkge1xuICAgICAgICAgIGl0ZW1bMl0gPSBtZWRpYTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpdGVtWzFdID0gXCJAbWVkaWEgXCIuY29uY2F0KGl0ZW1bMl0sIFwiIHtcIikuY29uY2F0KGl0ZW1bMV0sIFwifVwiKTtcbiAgICAgICAgICBpdGVtWzJdID0gbWVkaWE7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChzdXBwb3J0cykge1xuICAgICAgICBpZiAoIWl0ZW1bNF0pIHtcbiAgICAgICAgICBpdGVtWzRdID0gXCJcIi5jb25jYXQoc3VwcG9ydHMpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGl0ZW1bMV0gPSBcIkBzdXBwb3J0cyAoXCIuY29uY2F0KGl0ZW1bNF0sIFwiKSB7XCIpLmNvbmNhdChpdGVtWzFdLCBcIn1cIik7XG4gICAgICAgICAgaXRlbVs0XSA9IHN1cHBvcnRzO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBsaXN0LnB1c2goaXRlbSk7XG4gICAgfVxuICB9O1xuICByZXR1cm4gbGlzdDtcbn07IiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKHVybCwgb3B0aW9ucykge1xuICBpZiAoIW9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgaWYgKCF1cmwpIHtcbiAgICByZXR1cm4gdXJsO1xuICB9XG4gIHVybCA9IFN0cmluZyh1cmwuX19lc01vZHVsZSA/IHVybC5kZWZhdWx0IDogdXJsKTtcblxuICAvLyBJZiB1cmwgaXMgYWxyZWFkeSB3cmFwcGVkIGluIHF1b3RlcywgcmVtb3ZlIHRoZW1cbiAgaWYgKC9eWydcIl0uKlsnXCJdJC8udGVzdCh1cmwpKSB7XG4gICAgdXJsID0gdXJsLnNsaWNlKDEsIC0xKTtcbiAgfVxuICBpZiAob3B0aW9ucy5oYXNoKSB7XG4gICAgdXJsICs9IG9wdGlvbnMuaGFzaDtcbiAgfVxuXG4gIC8vIFNob3VsZCB1cmwgYmUgd3JhcHBlZD9cbiAgLy8gU2VlIGh0dHBzOi8vZHJhZnRzLmNzc3dnLm9yZy9jc3MtdmFsdWVzLTMvI3VybHNcbiAgaWYgKC9bXCInKCkgXFx0XFxuXXwoJTIwKS8udGVzdCh1cmwpIHx8IG9wdGlvbnMubmVlZFF1b3Rlcykge1xuICAgIHJldHVybiBcIlxcXCJcIi5jb25jYXQodXJsLnJlcGxhY2UoL1wiL2csICdcXFxcXCInKS5yZXBsYWNlKC9cXG4vZywgXCJcXFxcblwiKSwgXCJcXFwiXCIpO1xuICB9XG4gIHJldHVybiB1cmw7XG59OyIsIlwidXNlIHN0cmljdFwiO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChpdGVtKSB7XG4gIHZhciBjb250ZW50ID0gaXRlbVsxXTtcbiAgdmFyIGNzc01hcHBpbmcgPSBpdGVtWzNdO1xuICBpZiAoIWNzc01hcHBpbmcpIHtcbiAgICByZXR1cm4gY29udGVudDtcbiAgfVxuICBpZiAodHlwZW9mIGJ0b2EgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHZhciBiYXNlNjQgPSBidG9hKHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChKU09OLnN0cmluZ2lmeShjc3NNYXBwaW5nKSkpKTtcbiAgICB2YXIgZGF0YSA9IFwic291cmNlTWFwcGluZ1VSTD1kYXRhOmFwcGxpY2F0aW9uL2pzb247Y2hhcnNldD11dGYtODtiYXNlNjQsXCIuY29uY2F0KGJhc2U2NCk7XG4gICAgdmFyIHNvdXJjZU1hcHBpbmcgPSBcIi8qIyBcIi5jb25jYXQoZGF0YSwgXCIgKi9cIik7XG4gICAgcmV0dXJuIFtjb250ZW50XS5jb25jYXQoW3NvdXJjZU1hcHBpbmddKS5qb2luKFwiXFxuXCIpO1xuICB9XG4gIHJldHVybiBbY29udGVudF0uam9pbihcIlxcblwiKTtcbn07IiwiXG4gICAgICBpbXBvcnQgQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCI7XG4gICAgICBpbXBvcnQgZG9tQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVEb21BUEkuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRGbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydEJ5U2VsZWN0b3IuanNcIjtcbiAgICAgIGltcG9ydCBzZXRBdHRyaWJ1dGVzIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc2V0QXR0cmlidXRlc1dpdGhvdXRBdHRyaWJ1dGVzLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0U3R5bGVFbGVtZW50IGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0U3R5bGVFbGVtZW50LmpzXCI7XG4gICAgICBpbXBvcnQgc3R5bGVUYWdUcmFuc2Zvcm1GbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlVGFnVHJhbnNmb3JtLmpzXCI7XG4gICAgICBpbXBvcnQgY29udGVudCwgKiBhcyBuYW1lZEV4cG9ydCBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcz8/cnVsZVNldFsxXS5ydWxlc1swXS51c2VbMV0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Bvc3Rjc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vc3R5bGUuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanM/P3J1bGVTZXRbMV0ucnVsZXNbMF0udXNlWzFdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9wb3N0Y3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3N0eWxlLmNzc1wiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgc3R5bGVzSW5ET00gPSBbXTtcbmZ1bmN0aW9uIGdldEluZGV4QnlJZGVudGlmaWVyKGlkZW50aWZpZXIpIHtcbiAgdmFyIHJlc3VsdCA9IC0xO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IHN0eWxlc0luRE9NLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKHN0eWxlc0luRE9NW2ldLmlkZW50aWZpZXIgPT09IGlkZW50aWZpZXIpIHtcbiAgICAgIHJlc3VsdCA9IGk7XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIG1vZHVsZXNUb0RvbShsaXN0LCBvcHRpb25zKSB7XG4gIHZhciBpZENvdW50TWFwID0ge307XG4gIHZhciBpZGVudGlmaWVycyA9IFtdO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICB2YXIgaXRlbSA9IGxpc3RbaV07XG4gICAgdmFyIGlkID0gb3B0aW9ucy5iYXNlID8gaXRlbVswXSArIG9wdGlvbnMuYmFzZSA6IGl0ZW1bMF07XG4gICAgdmFyIGNvdW50ID0gaWRDb3VudE1hcFtpZF0gfHwgMDtcbiAgICB2YXIgaWRlbnRpZmllciA9IFwiXCIuY29uY2F0KGlkLCBcIiBcIikuY29uY2F0KGNvdW50KTtcbiAgICBpZENvdW50TWFwW2lkXSA9IGNvdW50ICsgMTtcbiAgICB2YXIgaW5kZXhCeUlkZW50aWZpZXIgPSBnZXRJbmRleEJ5SWRlbnRpZmllcihpZGVudGlmaWVyKTtcbiAgICB2YXIgb2JqID0ge1xuICAgICAgY3NzOiBpdGVtWzFdLFxuICAgICAgbWVkaWE6IGl0ZW1bMl0sXG4gICAgICBzb3VyY2VNYXA6IGl0ZW1bM10sXG4gICAgICBzdXBwb3J0czogaXRlbVs0XSxcbiAgICAgIGxheWVyOiBpdGVtWzVdXG4gICAgfTtcbiAgICBpZiAoaW5kZXhCeUlkZW50aWZpZXIgIT09IC0xKSB7XG4gICAgICBzdHlsZXNJbkRPTVtpbmRleEJ5SWRlbnRpZmllcl0ucmVmZXJlbmNlcysrO1xuICAgICAgc3R5bGVzSW5ET01baW5kZXhCeUlkZW50aWZpZXJdLnVwZGF0ZXIob2JqKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFyIHVwZGF0ZXIgPSBhZGRFbGVtZW50U3R5bGUob2JqLCBvcHRpb25zKTtcbiAgICAgIG9wdGlvbnMuYnlJbmRleCA9IGk7XG4gICAgICBzdHlsZXNJbkRPTS5zcGxpY2UoaSwgMCwge1xuICAgICAgICBpZGVudGlmaWVyOiBpZGVudGlmaWVyLFxuICAgICAgICB1cGRhdGVyOiB1cGRhdGVyLFxuICAgICAgICByZWZlcmVuY2VzOiAxXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWRlbnRpZmllcnMucHVzaChpZGVudGlmaWVyKTtcbiAgfVxuICByZXR1cm4gaWRlbnRpZmllcnM7XG59XG5mdW5jdGlvbiBhZGRFbGVtZW50U3R5bGUob2JqLCBvcHRpb25zKSB7XG4gIHZhciBhcGkgPSBvcHRpb25zLmRvbUFQSShvcHRpb25zKTtcbiAgYXBpLnVwZGF0ZShvYmopO1xuICB2YXIgdXBkYXRlciA9IGZ1bmN0aW9uIHVwZGF0ZXIobmV3T2JqKSB7XG4gICAgaWYgKG5ld09iaikge1xuICAgICAgaWYgKG5ld09iai5jc3MgPT09IG9iai5jc3MgJiYgbmV3T2JqLm1lZGlhID09PSBvYmoubWVkaWEgJiYgbmV3T2JqLnNvdXJjZU1hcCA9PT0gb2JqLnNvdXJjZU1hcCAmJiBuZXdPYmouc3VwcG9ydHMgPT09IG9iai5zdXBwb3J0cyAmJiBuZXdPYmoubGF5ZXIgPT09IG9iai5sYXllcikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBhcGkudXBkYXRlKG9iaiA9IG5ld09iaik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFwaS5yZW1vdmUoKTtcbiAgICB9XG4gIH07XG4gIHJldHVybiB1cGRhdGVyO1xufVxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAobGlzdCwgb3B0aW9ucykge1xuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgbGlzdCA9IGxpc3QgfHwgW107XG4gIHZhciBsYXN0SWRlbnRpZmllcnMgPSBtb2R1bGVzVG9Eb20obGlzdCwgb3B0aW9ucyk7XG4gIHJldHVybiBmdW5jdGlvbiB1cGRhdGUobmV3TGlzdCkge1xuICAgIG5ld0xpc3QgPSBuZXdMaXN0IHx8IFtdO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGFzdElkZW50aWZpZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgaWRlbnRpZmllciA9IGxhc3RJZGVudGlmaWVyc1tpXTtcbiAgICAgIHZhciBpbmRleCA9IGdldEluZGV4QnlJZGVudGlmaWVyKGlkZW50aWZpZXIpO1xuICAgICAgc3R5bGVzSW5ET01baW5kZXhdLnJlZmVyZW5jZXMtLTtcbiAgICB9XG4gICAgdmFyIG5ld0xhc3RJZGVudGlmaWVycyA9IG1vZHVsZXNUb0RvbShuZXdMaXN0LCBvcHRpb25zKTtcbiAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgbGFzdElkZW50aWZpZXJzLmxlbmd0aDsgX2krKykge1xuICAgICAgdmFyIF9pZGVudGlmaWVyID0gbGFzdElkZW50aWZpZXJzW19pXTtcbiAgICAgIHZhciBfaW5kZXggPSBnZXRJbmRleEJ5SWRlbnRpZmllcihfaWRlbnRpZmllcik7XG4gICAgICBpZiAoc3R5bGVzSW5ET01bX2luZGV4XS5yZWZlcmVuY2VzID09PSAwKSB7XG4gICAgICAgIHN0eWxlc0luRE9NW19pbmRleF0udXBkYXRlcigpO1xuICAgICAgICBzdHlsZXNJbkRPTS5zcGxpY2UoX2luZGV4LCAxKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbGFzdElkZW50aWZpZXJzID0gbmV3TGFzdElkZW50aWZpZXJzO1xuICB9O1xufTsiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIG1lbW8gPSB7fTtcblxuLyogaXN0YW5idWwgaWdub3JlIG5leHQgICovXG5mdW5jdGlvbiBnZXRUYXJnZXQodGFyZ2V0KSB7XG4gIGlmICh0eXBlb2YgbWVtb1t0YXJnZXRdID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgdmFyIHN0eWxlVGFyZ2V0ID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcih0YXJnZXQpO1xuXG4gICAgLy8gU3BlY2lhbCBjYXNlIHRvIHJldHVybiBoZWFkIG9mIGlmcmFtZSBpbnN0ZWFkIG9mIGlmcmFtZSBpdHNlbGZcbiAgICBpZiAod2luZG93LkhUTUxJRnJhbWVFbGVtZW50ICYmIHN0eWxlVGFyZ2V0IGluc3RhbmNlb2Ygd2luZG93LkhUTUxJRnJhbWVFbGVtZW50KSB7XG4gICAgICB0cnkge1xuICAgICAgICAvLyBUaGlzIHdpbGwgdGhyb3cgYW4gZXhjZXB0aW9uIGlmIGFjY2VzcyB0byBpZnJhbWUgaXMgYmxvY2tlZFxuICAgICAgICAvLyBkdWUgdG8gY3Jvc3Mtb3JpZ2luIHJlc3RyaWN0aW9uc1xuICAgICAgICBzdHlsZVRhcmdldCA9IHN0eWxlVGFyZ2V0LmNvbnRlbnREb2N1bWVudC5oZWFkO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBpc3RhbmJ1bCBpZ25vcmUgbmV4dFxuICAgICAgICBzdHlsZVRhcmdldCA9IG51bGw7XG4gICAgICB9XG4gICAgfVxuICAgIG1lbW9bdGFyZ2V0XSA9IHN0eWxlVGFyZ2V0O1xuICB9XG4gIHJldHVybiBtZW1vW3RhcmdldF07XG59XG5cbi8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICAqL1xuZnVuY3Rpb24gaW5zZXJ0QnlTZWxlY3RvcihpbnNlcnQsIHN0eWxlKSB7XG4gIHZhciB0YXJnZXQgPSBnZXRUYXJnZXQoaW5zZXJ0KTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJDb3VsZG4ndCBmaW5kIGEgc3R5bGUgdGFyZ2V0LiBUaGlzIHByb2JhYmx5IG1lYW5zIHRoYXQgdGhlIHZhbHVlIGZvciB0aGUgJ2luc2VydCcgcGFyYW1ldGVyIGlzIGludmFsaWQuXCIpO1xuICB9XG4gIHRhcmdldC5hcHBlbmRDaGlsZChzdHlsZSk7XG59XG5tb2R1bGUuZXhwb3J0cyA9IGluc2VydEJ5U2VsZWN0b3I7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbi8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICAqL1xuZnVuY3Rpb24gaW5zZXJ0U3R5bGVFbGVtZW50KG9wdGlvbnMpIHtcbiAgdmFyIGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIik7XG4gIG9wdGlvbnMuc2V0QXR0cmlidXRlcyhlbGVtZW50LCBvcHRpb25zLmF0dHJpYnV0ZXMpO1xuICBvcHRpb25zLmluc2VydChlbGVtZW50LCBvcHRpb25zLm9wdGlvbnMpO1xuICByZXR1cm4gZWxlbWVudDtcbn1cbm1vZHVsZS5leHBvcnRzID0gaW5zZXJ0U3R5bGVFbGVtZW50OyIsIlwidXNlIHN0cmljdFwiO1xuXG4vKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAgKi9cbmZ1bmN0aW9uIHNldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcyhzdHlsZUVsZW1lbnQpIHtcbiAgdmFyIG5vbmNlID0gdHlwZW9mIF9fd2VicGFja19ub25jZV9fICE9PSBcInVuZGVmaW5lZFwiID8gX193ZWJwYWNrX25vbmNlX18gOiBudWxsO1xuICBpZiAobm9uY2UpIHtcbiAgICBzdHlsZUVsZW1lbnQuc2V0QXR0cmlidXRlKFwibm9uY2VcIiwgbm9uY2UpO1xuICB9XG59XG5tb2R1bGUuZXhwb3J0cyA9IHNldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlczsiLCJcInVzZSBzdHJpY3RcIjtcblxuLyogaXN0YW5idWwgaWdub3JlIG5leHQgICovXG5mdW5jdGlvbiBhcHBseShzdHlsZUVsZW1lbnQsIG9wdGlvbnMsIG9iaikge1xuICB2YXIgY3NzID0gXCJcIjtcbiAgaWYgKG9iai5zdXBwb3J0cykge1xuICAgIGNzcyArPSBcIkBzdXBwb3J0cyAoXCIuY29uY2F0KG9iai5zdXBwb3J0cywgXCIpIHtcIik7XG4gIH1cbiAgaWYgKG9iai5tZWRpYSkge1xuICAgIGNzcyArPSBcIkBtZWRpYSBcIi5jb25jYXQob2JqLm1lZGlhLCBcIiB7XCIpO1xuICB9XG4gIHZhciBuZWVkTGF5ZXIgPSB0eXBlb2Ygb2JqLmxheWVyICE9PSBcInVuZGVmaW5lZFwiO1xuICBpZiAobmVlZExheWVyKSB7XG4gICAgY3NzICs9IFwiQGxheWVyXCIuY29uY2F0KG9iai5sYXllci5sZW5ndGggPiAwID8gXCIgXCIuY29uY2F0KG9iai5sYXllcikgOiBcIlwiLCBcIiB7XCIpO1xuICB9XG4gIGNzcyArPSBvYmouY3NzO1xuICBpZiAobmVlZExheWVyKSB7XG4gICAgY3NzICs9IFwifVwiO1xuICB9XG4gIGlmIChvYmoubWVkaWEpIHtcbiAgICBjc3MgKz0gXCJ9XCI7XG4gIH1cbiAgaWYgKG9iai5zdXBwb3J0cykge1xuICAgIGNzcyArPSBcIn1cIjtcbiAgfVxuICB2YXIgc291cmNlTWFwID0gb2JqLnNvdXJjZU1hcDtcbiAgaWYgKHNvdXJjZU1hcCAmJiB0eXBlb2YgYnRvYSAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIGNzcyArPSBcIlxcbi8qIyBzb3VyY2VNYXBwaW5nVVJMPWRhdGE6YXBwbGljYXRpb24vanNvbjtiYXNlNjQsXCIuY29uY2F0KGJ0b2EodW5lc2NhcGUoZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KHNvdXJjZU1hcCkpKSksIFwiICovXCIpO1xuICB9XG5cbiAgLy8gRm9yIG9sZCBJRVxuICAvKiBpc3RhbmJ1bCBpZ25vcmUgaWYgICovXG4gIG9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0oY3NzLCBzdHlsZUVsZW1lbnQsIG9wdGlvbnMub3B0aW9ucyk7XG59XG5mdW5jdGlvbiByZW1vdmVTdHlsZUVsZW1lbnQoc3R5bGVFbGVtZW50KSB7XG4gIC8vIGlzdGFuYnVsIGlnbm9yZSBpZlxuICBpZiAoc3R5bGVFbGVtZW50LnBhcmVudE5vZGUgPT09IG51bGwpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgc3R5bGVFbGVtZW50LnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc3R5bGVFbGVtZW50KTtcbn1cblxuLyogaXN0YW5idWwgaWdub3JlIG5leHQgICovXG5mdW5jdGlvbiBkb21BUEkob3B0aW9ucykge1xuICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHVwZGF0ZTogZnVuY3Rpb24gdXBkYXRlKCkge30sXG4gICAgICByZW1vdmU6IGZ1bmN0aW9uIHJlbW92ZSgpIHt9XG4gICAgfTtcbiAgfVxuICB2YXIgc3R5bGVFbGVtZW50ID0gb3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQob3B0aW9ucyk7XG4gIHJldHVybiB7XG4gICAgdXBkYXRlOiBmdW5jdGlvbiB1cGRhdGUob2JqKSB7XG4gICAgICBhcHBseShzdHlsZUVsZW1lbnQsIG9wdGlvbnMsIG9iaik7XG4gICAgfSxcbiAgICByZW1vdmU6IGZ1bmN0aW9uIHJlbW92ZSgpIHtcbiAgICAgIHJlbW92ZVN0eWxlRWxlbWVudChzdHlsZUVsZW1lbnQpO1xuICAgIH1cbiAgfTtcbn1cbm1vZHVsZS5leHBvcnRzID0gZG9tQVBJOyIsIlwidXNlIHN0cmljdFwiO1xuXG4vKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAgKi9cbmZ1bmN0aW9uIHN0eWxlVGFnVHJhbnNmb3JtKGNzcywgc3R5bGVFbGVtZW50KSB7XG4gIGlmIChzdHlsZUVsZW1lbnQuc3R5bGVTaGVldCkge1xuICAgIHN0eWxlRWxlbWVudC5zdHlsZVNoZWV0LmNzc1RleHQgPSBjc3M7XG4gIH0gZWxzZSB7XG4gICAgd2hpbGUgKHN0eWxlRWxlbWVudC5maXJzdENoaWxkKSB7XG4gICAgICBzdHlsZUVsZW1lbnQucmVtb3ZlQ2hpbGQoc3R5bGVFbGVtZW50LmZpcnN0Q2hpbGQpO1xuICAgIH1cbiAgICBzdHlsZUVsZW1lbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY3NzKSk7XG4gIH1cbn1cbm1vZHVsZS5leHBvcnRzID0gc3R5bGVUYWdUcmFuc2Zvcm07IiwiY29uc3QgYnVmZlRvQmFzZTY0ID0gKGJ1ZmY6IFVpbnQ4QXJyYXkpID0+IHdpbmRvdy5idG9hKFN0cmluZy5mcm9tQ2hhckNvZGUuYXBwbHkobnVsbCwgYnVmZiBhcyB1bmtub3duIGFzIG51bWJlcltdKSlcbmNvbnN0IGJhc2U2NFRvQnVmZiA9IChiNjQ6IHN0cmluZykgPT4gVWludDhBcnJheS5mcm9tKHdpbmRvdy5hdG9iKGI2NCksIChjKSA9PiBjLmNoYXJDb2RlQXQoMCkpXG5cbmNvbnN0IGVuYyA9IG5ldyBUZXh0RW5jb2RlcigpXG5jb25zdCBkZWMgPSBuZXcgVGV4dERlY29kZXIoKVxuY29uc3QgYnl0ZUxlbiA9IHsgc2FsdDogMTYsIGl2OiAxMiB9XG5cbi8qKlxuICogR2l2ZW4gYSBwYXNzd29yZCxcbiAqIEByZXR1cm5zIGEga2V5IGZyb20gdGhlIHBhc3N3b3JkLlxuICovXG5jb25zdCBnZXRLZXlGcm9tUGFzc3dvcmQgPSAocGFzc3dvcmQ6IHN0cmluZykgPT4ge1xuICByZXR1cm4gd2luZG93LmNyeXB0by5zdWJ0bGUuaW1wb3J0S2V5KCdyYXcnLCBlbmMuZW5jb2RlKHBhc3N3b3JkKSwgeyBuYW1lOiAnUEJLREYyJyB9LCBmYWxzZSwgW1xuICAgICdkZXJpdmVCaXRzJyxcbiAgICAnZGVyaXZlS2V5J1xuICBdKVxufVxuXG4vKipcbiAqIEdpdmVuIGEga2V5IGZyb20gYSBwYXNzd29yZCBhbmQgYSBzYWx0LFxuICogQHJldHVybnMgYSBrZXkgZGVyaXZlZCBmcm9tIHRoZSBwYXNzd29yZCBhbmQgc2FsdC5cbiAqL1xuY29uc3QgZ2V0S2V5ID0gKGtleUZyb21QYXNzd29yZDogQ3J5cHRvS2V5LCBzYWx0OiBCdWZmZXJTb3VyY2UpID0+IHtcbiAgcmV0dXJuIHdpbmRvdy5jcnlwdG8uc3VidGxlLmRlcml2ZUtleShcbiAgICB7XG4gICAgICBuYW1lOiAnUEJLREYyJyxcbiAgICAgIHNhbHQsXG4gICAgICBpdGVyYXRpb25zOiAxMDAwMDAsXG4gICAgICBoYXNoOiAnU0hBLTI1NidcbiAgICB9LFxuICAgIGtleUZyb21QYXNzd29yZCxcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgbGVuZ3RoOiAyNTYgfSxcbiAgICB0cnVlLFxuICAgIFsnZW5jcnlwdCcsICdkZWNyeXB0J11cbiAgKVxufVxuXG5jb25zdCBlbmNyeXB0ID0gYXN5bmMgKHNlY3JldDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKSA9PiB7XG4gIGNvbnN0IGtleUZyb21QYXNzd29yZCA9IGF3YWl0IGdldEtleUZyb21QYXNzd29yZChwYXNzd29yZClcbiAgY29uc3Qgc2FsdCA9IHdpbmRvdy5jcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KGJ5dGVMZW4uc2FsdCkpXG4gIGNvbnN0IGtleSA9IGF3YWl0IGdldEtleShrZXlGcm9tUGFzc3dvcmQsIHNhbHQpXG4gIGNvbnN0IGl2ID0gd2luZG93LmNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoYnl0ZUxlbi5pdikpXG4gIGNvbnN0IGVuY29kZWQgPSBlbmMuZW5jb2RlKHNlY3JldClcblxuICBjb25zdCBjaXBoZXJUZXh0ID0gYXdhaXQgd2luZG93LmNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICB7XG4gICAgICBuYW1lOiAnQUVTLUdDTScsXG4gICAgICBpdlxuICAgIH0sXG4gICAga2V5LFxuICAgIGVuY29kZWRcbiAgKVxuXG4gIGNvbnN0IGNpcGhlciA9IG5ldyBVaW50OEFycmF5KGNpcGhlclRleHQpXG4gIGNvbnN0IGJ1ZmZlciA9IG5ldyBVaW50OEFycmF5KHNhbHQuYnl0ZUxlbmd0aCArIGl2LmJ5dGVMZW5ndGggKyBjaXBoZXIuYnl0ZUxlbmd0aClcbiAgYnVmZmVyLnNldChzYWx0LCAwKVxuICBidWZmZXIuc2V0KGl2LCBzYWx0LmJ5dGVMZW5ndGgpXG4gIGJ1ZmZlci5zZXQoY2lwaGVyLCBzYWx0LmJ5dGVMZW5ndGggKyBpdi5ieXRlTGVuZ3RoKVxuXG4gIGNvbnN0IGVuY3J5cHRlZCA9IGJ1ZmZUb0Jhc2U2NChidWZmZXIpXG4gIHJldHVybiBlbmNyeXB0ZWRcbn1cblxuLyoqXG4gKiBEZXJpdmUgYSBrZXkgZnJvbSBhIHBhc3N3b3JkIHN1cHBsaWVkIGJ5IHRoZSB1c2VyLFxuICogdXNlIHRoZSBrZXkgdG8gZGVjcnlwdCB0aGUgY2lwaGVyVGV4dC5cbiAqIGlmIHRoZSBjaXBoZXJUZXh0IHdhcyBkZWNyeXB0ZWQgc3VjY2Vzc2Z1bGx5LFxuICogICByZXR1cm4gdGhlIGRlY3J5cHRlZCB2YWx1ZS5cbiAqIGlmIHRoZXJlIHdhcyBhbiBlcnJvciBkZWNyeXB0aW5nLFxuICogICB0aHJvdyBhbiBlcnJvciBtZXNzYWdlLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBlbmNyeXB0ZWQgZW5jcnlwdGVkIGJhc2U2NCBzdHJpbmdcbiAqIEBwYXJhbSB7c3RyaW5nfSBwYXNzd29yZCBwYXNzd29yZCBmb3IgdGhlIGVuY3J5cHRlZCBkYXRhXG4gKiBAcmV0dXJucyBzZWNyZXQgdGV4dCBzZXQgYnkgZW5jcnlwdCgpIGZ1bmN0aW9uIG9yIGFuIGVycm9yIG1lc3NhZ2VcbiAqL1xuY29uc3QgZGVjcnlwdCA9IGFzeW5jIChlbmNyeXB0ZWQ6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZykgPT4ge1xuICBjb25zdCBlbmNyeXB0ZWRCdWZmZXIgPSBiYXNlNjRUb0J1ZmYoZW5jcnlwdGVkKVxuICBjb25zdCBzYWx0ID0gZW5jcnlwdGVkQnVmZmVyLnNsaWNlKDAsIGJ5dGVMZW4uc2FsdClcbiAgY29uc3QgaXYgPSBlbmNyeXB0ZWRCdWZmZXIuc2xpY2UoYnl0ZUxlbi5zYWx0LCBieXRlTGVuLnNhbHQgKyBieXRlTGVuLml2KVxuICBjb25zdCBjaXBoZXJUZXh0ID0gZW5jcnlwdGVkQnVmZmVyLnNsaWNlKGJ5dGVMZW4uc2FsdCArIGJ5dGVMZW4uaXYpXG5cbiAgY29uc3Qga2V5RnJvbVBhc3N3b3JkID0gYXdhaXQgZ2V0S2V5RnJvbVBhc3N3b3JkKHBhc3N3b3JkKVxuICBjb25zdCBrZXkgPSBhd2FpdCBnZXRLZXkoa2V5RnJvbVBhc3N3b3JkLCBzYWx0KVxuXG4gIHRyeSB7XG4gICAgY29uc3QgZGVjcnlwdGVkRW5jb2RlZCA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLmRlY3J5cHQoXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdBRVMtR0NNJyxcbiAgICAgICAgaXZcbiAgICAgIH0sXG4gICAgICBrZXksXG4gICAgICBjaXBoZXJUZXh0XG4gICAgKVxuXG4gICAgY29uc3QgZGVjcnlwdGVkID0gZGVjLmRlY29kZShkZWNyeXB0ZWRFbmNvZGVkKVxuICAgIHJldHVybiBkZWNyeXB0ZWRcbiAgfSBjYXRjaCAoZSkge1xuICAgIHRocm93IG5ldyBFcnJvcihlIGFzIHN0cmluZylcbiAgfVxufVxuXG5leHBvcnQgeyBlbmNyeXB0LCBkZWNyeXB0IH1cbiIsImltcG9ydCB0eXBlIEF1dGhSZXF1ZXN0Q3JlZGVudGlhbHMgZnJvbSAnbW9kZWxzL0F1dGhSZXF1ZXN0Q3JlZGVudGlhbHMnXG5cbmNsYXNzIEVSUCB7XG4gIG9uR2V0U2VjdXJpdHlRdWVzOiAocXVlc3Rpb246IHN0cmluZykgPT4gdm9pZFxuICBpc0xvZ2dlZEluOiAoKSA9PiBQcm9taXNlPGJvb2xlYW4+XG4gIGxvZ291dDogKCkgPT4gUHJvbWlzZTxzdHJpbmc+XG4gIGF1dGhSZXF1ZXN0OiAoYXV0aENyZWQ6IEF1dGhSZXF1ZXN0Q3JlZGVudGlhbHMpID0+IFByb21pc2U8c3RyaW5nPlxuICBnZXRTZWN1cml0eVF1ZXM6ICgpID0+IFByb21pc2U8c3RyaW5nPlxuXG4gIGNvbnN0cnVjdG9yKHJvbGw6IHN0cmluZykge1xuICAgIGxldCB1c2VybmFtZSA9IHJvbGwgfHwgJydcbiAgICBsZXQgcGFzc3dvcmQgPSAnJ1xuICAgIGNvbnN0IHNlY3VyaXR5UXVlc3Rpb25zID0ge30gYXMgeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfVxuXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnRpZXModGhpcywge1xuICAgICAgdXNlcm5hbWU6IHtcbiAgICAgICAgZ2V0KCkge1xuICAgICAgICAgIHJldHVybiB1c2VybmFtZVxuICAgICAgICB9XG4gICAgICB9LFxuXG4gICAgICBwYXNzd29yZDoge1xuICAgICAgICBzZXQocGFzcykge1xuICAgICAgICAgIHBhc3N3b3JkID0gcGFzc1xuICAgICAgICB9XG4gICAgICB9LFxuXG4gICAgICBzZWN1cml0eVF1ZXN0aW9uczoge1xuICAgICAgICBzZXQocXVlcykge1xuICAgICAgICAgIGlmIChxdWVzIGluc3RhbmNlb2YgT2JqZWN0KSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHEgaW4gcXVlcykge1xuICAgICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoc2VjdXJpdHlRdWVzdGlvbnMpLmluY2x1ZGVzKHEpKSB7XG4gICAgICAgICAgICAgICAgc2VjdXJpdHlRdWVzdGlvbnNbcV0gPSBxdWVzW3FdXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIGdldCgpIHtcbiAgICAgICAgICByZXR1cm4gc2VjdXJpdHlRdWVzdGlvbnNcbiAgICAgICAgfVxuICAgICAgfSxcblxuICAgICAgZGF0YToge1xuICAgICAgICBnZXQoKSB7XG4gICAgICAgICAgcmV0dXJuIHsgdXNlcm5hbWUsIHBhc3N3b3JkLCBzZWN1cml0eVF1ZXN0aW9ucyB9XG4gICAgICAgIH1cbiAgICAgIH0sXG5cbiAgICAgIGxvYWQ6IHtcbiAgICAgICAgdmFsdWUodXNlcjogeyB1c2VybmFtZTogc3RyaW5nOyBwYXNzd29yZDogc3RyaW5nOyBzZWN1cml0eVF1ZXN0aW9uczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSB9KSB7XG4gICAgICAgICAgY29uc3QgeyB1c2VybmFtZTogaWQsIHBhc3N3b3JkOiBwYXNzLCBzZWN1cml0eVF1ZXN0aW9uczogcXVlcyB9ID0gdXNlclxuXG4gICAgICAgICAgaWYgKGlkKSB7XG4gICAgICAgICAgICB1c2VybmFtZSA9IGlkXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHBhc3MpIHtcbiAgICAgICAgICAgIHBhc3N3b3JkID0gcGFzc1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChxdWVzKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHEgaW4gcXVlcykge1xuICAgICAgICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHF1ZXMsIHEpKSB7XG4gICAgICAgICAgICAgICAgc2VjdXJpdHlRdWVzdGlvbnNbcV0gPSBxdWVzW3FdXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zb2xlLmluZm8oJ3VzZXIgbG9hZGVkOicsIHtcbiAgICAgICAgICAgIHVzZXJuYW1lLFxuICAgICAgICAgICAgcGFzc3dvcmQsXG4gICAgICAgICAgICBzZWN1cml0eVF1ZXN0aW9uc1xuICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgIH0sXG5cbiAgICAgIGdldEFsbFNlY3VyaXR5UXVlczoge1xuICAgICAgICBhc3luYyB2YWx1ZSgpIHtcbiAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoc2VjdXJpdHlRdWVzdGlvbnMpLmxlbmd0aCA+PSAzKSB7XG4gICAgICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMoc2VjdXJpdHlRdWVzdGlvbnMpXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgbGV0IHF1ZXN0aW9uXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHF1ZXN0aW9uID0gYXdhaXQgdGhpcy5nZXRTZWN1cml0eVF1ZXModXNlcm5hbWUpXG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpXG4gICAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAocXVlc3Rpb24gPT09ICdGQUxTRScpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IobmV3IEVycm9yKCdJbnZhbGlkIHVzZXJuYW1lJykpXG4gICAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoc2VjdXJpdHlRdWVzdGlvbnMpLmxlbmd0aCA8IDMpIHtcbiAgICAgICAgICAgIGlmICghT2JqZWN0LmtleXMoc2VjdXJpdHlRdWVzdGlvbnMpLmluY2x1ZGVzKHF1ZXN0aW9uKSkge1xuICAgICAgICAgICAgICB0aGlzLm9uR2V0U2VjdXJpdHlRdWVzKHF1ZXN0aW9uKVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZWN1cml0eVF1ZXN0aW9uc1txdWVzdGlvbl0gPSAnJ1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5nZXRBbGxTZWN1cml0eVF1ZXMoKVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhzZWN1cml0eVF1ZXN0aW9ucylcbiAgICAgICAgfVxuICAgICAgfSxcblxuICAgICAgbG9naW46IHtcbiAgICAgICAgYXN5bmMgdmFsdWUob3B0aW9uczogeyBzZXNzaW9uVG9rZW4/OiBzdHJpbmc7IHJlcXVlc3RlZFVybD86IHN0cmluZyB9KSB7XG4gICAgICAgICAgbGV0IHsgcmVxdWVzdGVkVXJsIH0gPSBvcHRpb25zIHx8IHt9XG4gICAgICAgICAgY29uc3QgeyBzZXNzaW9uVG9rZW4gfSA9IG9wdGlvbnMgfHwge31cblxuICAgICAgICAgIC8qIFNldCBhIGRlZmF1bHQgdGFyZ2V0IHVybCAqL1xuICAgICAgICAgIGlmICghcmVxdWVzdGVkVXJsKSB7XG4gICAgICAgICAgICByZXF1ZXN0ZWRVcmwgPSAnaHR0cHM6Ly9lcnAuaWl0a2dwLmFjLmluL0lJVF9FUlAzLydcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvKiBDaGVjayBsb2dpbiBzdGF0dXMgKi9cbiAgICAgICAgICBjb25zdCBpc0xvZ2dlZEluID0gYXdhaXQgdGhpcy5pc0xvZ2dlZEluKHJlcXVlc3RlZFVybClcbiAgICAgICAgICBjb25zb2xlLmxvZyh7IGlzTG9nZ2VkSW4gfSlcbiAgICAgICAgICBpZiAoaXNMb2dnZWRJbikge1xuICAgICAgICAgICAgcmV0dXJuIHJlcXVlc3RlZFVybFxuICAgICAgICAgIH1cblxuICAgICAgICAgIC8qIEdldCBzZWN1cml0eSBxdWVzdGlvbiAqL1xuICAgICAgICAgIGxldCBxdWVzdGlvblxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBxdWVzdGlvbiA9IGF3YWl0IHRoaXMuZ2V0U2VjdXJpdHlRdWVzKHVzZXJuYW1lKVxuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgY29uc29sZS5sb2coJ2F1dGhTZWN1cml0eVF1ZXM6JywgcXVlc3Rpb24pXG5cbiAgICAgICAgICAvKiBQaWNrIGFuc3dlciB0byB0aGUgc2VjdXJpdHkgcXVlc3Rpb24gKi9cbiAgICAgICAgICBjb25zdCBhbnN3ZXIgPSBzZWN1cml0eVF1ZXN0aW9uc1txdWVzdGlvbl0gfHwgJydcblxuICAgICAgICAgIC8qIFJlcXVlc3QgZm9yIGxvZ2luICovXG4gICAgICAgICAgY29uc3QgcmVkaXJlY3RlZFVybCA9IGF3YWl0IHRoaXMuYXV0aFJlcXVlc3Qoe1xuICAgICAgICAgICAgdXNlcm5hbWUsXG4gICAgICAgICAgICBwYXNzd29yZCxcbiAgICAgICAgICAgIGFuc3dlcixcbiAgICAgICAgICAgIHNlc3Npb25Ub2tlbixcbiAgICAgICAgICAgIHJlcXVlc3RlZFVybFxuICAgICAgICAgIH0pXG5cbiAgICAgICAgICByZXR1cm4gcmVkaXJlY3RlZFVybFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMub25HZXRTZWN1cml0eVF1ZXMgPSBmdW5jdGlvbiAocXVlc3Rpb246IHN0cmluZykge1xuICAgICAgY29uc29sZS5sb2coeyBxdWVzdGlvbiB9KVxuICAgIH1cblxuICAgIHRoaXMubG9nb3V0ID0gYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgICAgY29uc3QgdXJsID0gJ2h0dHBzOi8vZXJwLmlpdGtncC5hYy5pbi9JSVRfRVJQMy9sb2dvdXQuaHRtJ1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSAoYXdhaXQgcHJvY2Vzc1JlcXVlc3QobmV3IFJlcXVlc3QodXJsKSkpIGFzIFJlc3BvbnNlXG5cbiAgICAgIGlmIChyZXNwb25zZS5yZWRpcmVjdGVkKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS51cmxcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcignTG9nb3V0IGZhaWxlZCcpKVxuICAgIH1cblxuICAgIHRoaXMuaXNMb2dnZWRJbiA9IGFzeW5jIGZ1bmN0aW9uIChyZXF1ZXN0ZWRVcmw/OiBzdHJpbmcpIHtcbiAgICAgIGlmICghcmVxdWVzdGVkVXJsKSB7XG4gICAgICAgIHJlcXVlc3RlZFVybCA9ICdodHRwczovL2VycC5paXRrZ3AuYWMuaW4vSUlUX0VSUDMvJ1xuICAgICAgfVxuXG4gICAgICBjb25zdCByZXMgPSAoYXdhaXQgcHJvY2Vzc1JlcXVlc3QobmV3IFJlcXVlc3QocmVxdWVzdGVkVXJsKSkpIGFzIFJlc3BvbnNlXG4gICAgICBpZiAoIXJlcy5yZWRpcmVjdGVkKSB7XG4gICAgICAgIHJldHVybiB0cnVlXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIHRoaXMuYXV0aFJlcXVlc3QgPSBhc3luYyBmdW5jdGlvbiAoYXV0aENyZWQ6IEF1dGhSZXF1ZXN0Q3JlZGVudGlhbHMpIHtcbiAgICAgIGNvbnN0IHsgdXNlcm5hbWUsIHBhc3N3b3JkLCBhbnN3ZXIsIHNlc3Npb25Ub2tlbiwgcmVxdWVzdGVkVXJsIH0gPSBhdXRoQ3JlZFxuXG4gICAgICBpZiAoIXVzZXJuYW1lIHx8ICFwYXNzd29yZCB8fCAhYW5zd2VyKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignVXNlcm5hbWUgb3IgUGFzc3dvcmQgb3IgQW5zd2VyIGlzIG1pc3NpbmchJylcbiAgICAgIH1cblxuICAgICAgbGV0IGJvZHkgPSBgdXNlcl9pZD0ke3VzZXJuYW1lfSZwYXNzd29yZD0ke3Bhc3N3b3JkfSZhbnN3ZXI9JHthbnN3ZXJ9YFxuICAgICAgaWYgKHNlc3Npb25Ub2tlbikge1xuICAgICAgICBib2R5ICs9IGAmc2Vzc2lvblRva2VuPSR7c2Vzc2lvblRva2VufWBcbiAgICAgIH1cblxuICAgICAgaWYgKHJlcXVlc3RlZFVybCkge1xuICAgICAgICBib2R5ICs9IGAmcmVxdWVzdGVkVXJsPSR7cmVxdWVzdGVkVXJsfWBcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGJvZHkgKz0gJyZyZXF1ZXN0ZWRVcmw9aHR0cHM6Ly9lcnAuaWl0a2dwLmFjLmluL0lJVF9FUlAzLydcbiAgICAgIH1cblxuICAgICAgY29uc3QgdXJsID0gJ2h0dHBzOi8vZXJwLmlpdGtncC5hYy5pbi9TU09BZG1pbmlzdHJhdGlvbi9hdXRoLmh0bSdcbiAgICAgIGNvbnN0IG1ldGhvZCA9ICdQT1NUJ1xuXG4gICAgICBjb25zb2xlLmxvZygncmVxX2JvZHk6JywgYm9keSlcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gKGF3YWl0IHByb2Nlc3NSZXF1ZXN0KG5ldyBSZXF1ZXN0KHVybCwgeyBtZXRob2QsIGJvZHkgfSkpKSBhcyBSZXNwb25zZVxuXG4gICAgICBpZiAocmVzcG9uc2UucmVkaXJlY3RlZCkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UudXJsXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChuZXcgRXJyb3IoJ0ludmFsaWQgY3JlZGVudGlhbHMnKSlcbiAgICB9XG5cbiAgICB0aGlzLmdldFNlY3VyaXR5UXVlcyA9IGFzeW5jIGZ1bmN0aW9uIChpaXRrZ3BMb2dpbklkPzogc3RyaW5nKSB7XG4gICAgICBpZiAoIWlpdGtncExvZ2luSWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdQbGVhc2UgcHJvdmlkZSBsb2dpbiBpZCcpXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHVybCA9ICdodHRwczovL2VycC5paXRrZ3AuYWMuaW4vU1NPQWRtaW5pc3RyYXRpb24vZ2V0U2VjdXJpdHlRdWVzLmh0bSdcbiAgICAgIGNvbnN0IG1ldGhvZCA9ICdQT1NUJ1xuICAgICAgY29uc3QgYm9keSA9IGB1c2VyX2lkPSR7aWl0a2dwTG9naW5JZH1gXG5cbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcHJvY2Vzc1JlcXVlc3QobmV3IFJlcXVlc3QodXJsLCB7IG1ldGhvZCwgYm9keSB9KSlcbiAgICAgIHJldHVybiByZXNwb25zZSA/IHJlc3BvbnNlLnRleHQoKSA6ICdGQUxTRSdcbiAgICB9XG5cbiAgICBjb25zdCBwcm9jZXNzUmVxdWVzdCA9IGFzeW5jIGZ1bmN0aW9uIChyZXF1ZXN0OiBSZXF1ZXN0KSB7XG4gICAgICBsZXQgdHMgPSBEYXRlLm5vdygpXG4gICAgICBjb25zdCB7IHVybCwgbWV0aG9kIH0gPSByZXF1ZXN0XG4gICAgICBjb25zdCB7IHBhdGhuYW1lLCBzZWFyY2ggfSA9IG5ldyBVUkwodXJsKVxuXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IG5hdGl2ZUZldGNoKHJlcXVlc3QpXG4gICAgICB0cyAtPSBEYXRlLm5vdygpXG5cbiAgICAgIGNvbnNvbGUubG9nKGAke21ldGhvZCArIHJlc3BvbnNlLnN0YXR1c306ICR7LXRzfW1zICR7cGF0aG5hbWUgKyBzZWFyY2h9YClcblxuICAgICAgaWYgKHJlc3BvbnNlLm9rICYmIHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAwKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKCdBcGkgcmV0dXJuZWQgc3RhdHVzOiAnICsgcmVzcG9uc2Uuc3RhdHVzKSlcbiAgICB9XG5cbiAgICBjb25zdCBuYXRpdmVGZXRjaCA9IGZ1bmN0aW9uIChyZXF1ZXN0OiBSZXF1ZXN0KSB7XG4gICAgICBpZiAocmVxdWVzdC5tZXRob2QgPT09ICdQT1NUJykge1xuICAgICAgICByZXF1ZXN0LmhlYWRlcnMuc2V0KCdDb250ZW50LXR5cGUnLCAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJylcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGZldGNoKHJlcXVlc3QpXG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IEVSUFxuIiwiY29uc3QgZGlzcGxheU1lc3NhZ2VPblBvcHVwID0gKFxuICBtZXNzYWdlOiBzdHJpbmcsXG4gIHR5cGUgPSAnaW5mbycsXG4gIGFjdGlvbnMgPSBmYWxzZSxcbiAgb25DbGlja1llcyA9ICgpID0+IHt9LFxuICBvbmNsaWNrQ2FuY2VsID0gKCkgPT4ge31cbikgPT4ge1xuICBjb25zdCBsb2cgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbG9nJykgYXMgSFRNTEVsZW1lbnRcbiAgY29uc3QgbG9nSWNvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsb2dJY29uJykgYXMgSFRNTEVsZW1lbnRcbiAgY29uc3QgbG9nVGV4dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsb2dUZXh0JykgYXMgSFRNTEVsZW1lbnRcblxuICBjb25zdCBzdGF0dXMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc3RhdHVzJykgYXMgSFRNTEVsZW1lbnRcbiAgY29uc3Qgc3RhdHVzSWNvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzdGF0dXNJY29uJykgYXMgSFRNTEVsZW1lbnRcbiAgY29uc3Qgc3RhdHVzVGV4dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzdGF0dXNUZXh0JykgYXMgSFRNTEVsZW1lbnRcblxuICBsZXQgaWNvbklkXG4gIGxvZy5jbGFzc05hbWUgPSB0eXBlXG5cbiAgc3RhdHVzLnN0eWxlLmJhY2tncm91bmRDb2xvciA9ICd5ZWxsb3cnXG4gIHN3aXRjaCAodHlwZSkge1xuICAgIGNhc2UgJ3dhcm5pbmcnOlxuICAgICAgaWNvbklkID0gJ3dhcm5pbmcnXG4gICAgICBicmVha1xuICAgIGNhc2UgJ2Vycm9yJzpcbiAgICAgIGljb25JZCA9ICdjcm9zcydcbiAgICAgIGJyZWFrXG4gICAgY2FzZSAnc3VjY2Vzcyc6XG4gICAgICBpY29uSWQgPSAnY2hlY2snXG4gICAgICBzdGF0dXMuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gJ2xpZ2h0Z3JlZW4nXG4gICAgICBicmVha1xuXG4gICAgZGVmYXVsdDpcbiAgICAgIGljb25JZCA9ICdpbmZvJ1xuICAgICAgYnJlYWtcbiAgfVxuXG4gIGxvZ1RleHQudGV4dENvbnRlbnQgPSBtZXNzYWdlXG4gIGxvZ0ljb24uc2V0QXR0cmlidXRlKCdocmVmJywgY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKGAvYXNzZXRzL3Nwcml0ZS5zdmcjJHtpY29uSWQgfHwgJ2luZm8nfWApKVxuXG4gIHN0YXR1c1RleHQudGV4dENvbnRlbnQgPSBtZXNzYWdlXG4gIHN0YXR1c0ljb24uc2V0QXR0cmlidXRlKCdocmVmJywgY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKGAvYXNzZXRzL3Nwcml0ZS5zdmcjJHtpY29uSWQgfHwgJ2luZm8nfWApKVxuXG4gIGlmIChhY3Rpb25zKSB7XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmFjdGlvbicpLmZvckVhY2goKGVsKSA9PiBlbC5yZW1vdmUoKSlcblxuICAgIGNvbnN0IGFjdGlvbkJ0blllcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgYWN0aW9uQnRuWWVzLmNsYXNzTmFtZSA9ICdhY3Rpb24nXG4gICAgYWN0aW9uQnRuWWVzLnRleHRDb250ZW50ID0gJ1llcydcblxuICAgIGNvbnN0IGFjdGlvbkJ0bkNhbmNlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgYWN0aW9uQnRuQ2FuY2VsLmNsYXNzTmFtZSA9ICdhY3Rpb24nXG4gICAgYWN0aW9uQnRuQ2FuY2VsLnRleHRDb250ZW50ID0gJ0NhbmNlbCdcblxuICAgIGxvZy5hcHBlbmRDaGlsZChhY3Rpb25CdG5ZZXMpXG4gICAgbG9nLmFwcGVuZENoaWxkKGFjdGlvbkJ0bkNhbmNlbClcblxuICAgIGFjdGlvbkJ0blllcy5vbmNsaWNrID0gKCkgPT4ge1xuICAgICAgbG9nLnJlbW92ZUNoaWxkKGFjdGlvbkJ0blllcylcbiAgICAgIGxvZy5yZW1vdmVDaGlsZChhY3Rpb25CdG5DYW5jZWwpXG4gICAgICBvbkNsaWNrWWVzKClcbiAgICB9XG5cbiAgICBhY3Rpb25CdG5DYW5jZWwub25jbGljayA9ICgpID0+IHtcbiAgICAgIGxvZy5yZW1vdmVDaGlsZChhY3Rpb25CdG5ZZXMpXG4gICAgICBsb2cucmVtb3ZlQ2hpbGQoYWN0aW9uQnRuQ2FuY2VsKVxuICAgICAgb25jbGlja0NhbmNlbCgpXG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGRpc3BsYXlNZXNzYWdlT25Qb3B1cFxuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHRpZDogbW9kdWxlSWQsXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbi8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBfX3dlYnBhY2tfbW9kdWxlc19fO1xuXG4iLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18uZyA9IChmdW5jdGlvbigpIHtcblx0aWYgKHR5cGVvZiBnbG9iYWxUaGlzID09PSAnb2JqZWN0JykgcmV0dXJuIGdsb2JhbFRoaXM7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHRoaXMgfHwgbmV3IEZ1bmN0aW9uKCdyZXR1cm4gdGhpcycpKCk7XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ29iamVjdCcpIHJldHVybiB3aW5kb3c7XG5cdH1cbn0pKCk7IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsInZhciBzY3JpcHRVcmw7XG5pZiAoX193ZWJwYWNrX3JlcXVpcmVfXy5nLmltcG9ydFNjcmlwdHMpIHNjcmlwdFVybCA9IF9fd2VicGFja19yZXF1aXJlX18uZy5sb2NhdGlvbiArIFwiXCI7XG52YXIgZG9jdW1lbnQgPSBfX3dlYnBhY2tfcmVxdWlyZV9fLmcuZG9jdW1lbnQ7XG5pZiAoIXNjcmlwdFVybCAmJiBkb2N1bWVudCkge1xuXHRpZiAoZG9jdW1lbnQuY3VycmVudFNjcmlwdClcblx0XHRzY3JpcHRVcmwgPSBkb2N1bWVudC5jdXJyZW50U2NyaXB0LnNyYztcblx0aWYgKCFzY3JpcHRVcmwpIHtcblx0XHR2YXIgc2NyaXB0cyA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwic2NyaXB0XCIpO1xuXHRcdGlmKHNjcmlwdHMubGVuZ3RoKSB7XG5cdFx0XHR2YXIgaSA9IHNjcmlwdHMubGVuZ3RoIC0gMTtcblx0XHRcdHdoaWxlIChpID4gLTEgJiYgIXNjcmlwdFVybCkgc2NyaXB0VXJsID0gc2NyaXB0c1tpLS1dLnNyYztcblx0XHR9XG5cdH1cbn1cbi8vIFdoZW4gc3VwcG9ydGluZyBicm93c2VycyB3aGVyZSBhbiBhdXRvbWF0aWMgcHVibGljUGF0aCBpcyBub3Qgc3VwcG9ydGVkIHlvdSBtdXN0IHNwZWNpZnkgYW4gb3V0cHV0LnB1YmxpY1BhdGggbWFudWFsbHkgdmlhIGNvbmZpZ3VyYXRpb25cbi8vIG9yIHBhc3MgYW4gZW1wdHkgc3RyaW5nIChcIlwiKSBhbmQgc2V0IHRoZSBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyB2YXJpYWJsZSBmcm9tIHlvdXIgY29kZSB0byB1c2UgeW91ciBvd24gbG9naWMuXG5pZiAoIXNjcmlwdFVybCkgdGhyb3cgbmV3IEVycm9yKFwiQXV0b21hdGljIHB1YmxpY1BhdGggaXMgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGJyb3dzZXJcIik7XG5zY3JpcHRVcmwgPSBzY3JpcHRVcmwucmVwbGFjZSgvIy4qJC8sIFwiXCIpLnJlcGxhY2UoL1xcPy4qJC8sIFwiXCIpLnJlcGxhY2UoL1xcL1teXFwvXSskLywgXCIvXCIpO1xuX193ZWJwYWNrX3JlcXVpcmVfXy5wID0gc2NyaXB0VXJsICsgXCIuLi8uLi9cIjsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLmIgPSBkb2N1bWVudC5iYXNlVVJJIHx8IHNlbGYubG9jYXRpb24uaHJlZjtcblxuLy8gb2JqZWN0IHRvIHN0b3JlIGxvYWRlZCBhbmQgbG9hZGluZyBjaHVua3Ncbi8vIHVuZGVmaW5lZCA9IGNodW5rIG5vdCBsb2FkZWQsIG51bGwgPSBjaHVuayBwcmVsb2FkZWQvcHJlZmV0Y2hlZFxuLy8gW3Jlc29sdmUsIHJlamVjdCwgUHJvbWlzZV0gPSBjaHVuayBsb2FkaW5nLCAwID0gY2h1bmsgbG9hZGVkXG52YXIgaW5zdGFsbGVkQ2h1bmtzID0ge1xuXHRcInBhZ2VzL1BvcHVwL2luZGV4XCI6IDBcbn07XG5cbi8vIG5vIGNodW5rIG9uIGRlbWFuZCBsb2FkaW5nXG5cbi8vIG5vIHByZWZldGNoaW5nXG5cbi8vIG5vIHByZWxvYWRlZFxuXG4vLyBubyBITVJcblxuLy8gbm8gSE1SIG1hbmlmZXN0XG5cbi8vIG5vIG9uIGNodW5rcyBsb2FkZWRcblxuLy8gbm8ganNvbnAgZnVuY3Rpb24iLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm5jID0gdW5kZWZpbmVkOyIsImltcG9ydCBDcmVkZW50aWFsIGZyb20gJ21vZGVscy9DcmVkZW50aWFsJ1xuaW1wb3J0ICdwYWdlcy9Qb3B1cC9zdHlsZS5jc3MnXG5pbXBvcnQgeyBlbmNyeXB0IH0gZnJvbSAnc2VydmljZXMvY3J5cHRvJ1xuaW1wb3J0IEVSUCBmcm9tICdzZXJ2aWNlcy9lcnAnXG5pbXBvcnQgeyBkZWZhdWx0IGFzIGxvZ2dlciB9IGZyb20gJ3V0aWxzL2Rpc3BsYXlNZXNzYWdlT25Qb3B1cCdcblxuLyogSW5pdGlhbGl6ZSBUaGVtZSAqL1xuY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsndGhlbWUnLCAnYmcnLCAnbGFuZGluZ1BhZ2UnLCAndXNlQWx0UElORGlhbG9nJ10sIChyZXN1bHQpID0+IHtcbiAgY29uc3QgdXNlQWx0UElORGlhbG9nSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndXNlQWx0UElORGlhbG9nJykgYXMgSFRNTElucHV0RWxlbWVudFxuICB1c2VBbHRQSU5EaWFsb2dJbnB1dC5jaGVja2VkID0gcmVzdWx0LnVzZUFsdFBJTkRpYWxvZyB8fCBmYWxzZVxuXG4gIHVzZUFsdFBJTkRpYWxvZ0lucHV0Lm9uY2hhbmdlID0gKGV2KSA9PiB7XG4gICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHtcbiAgICAgIHVzZUFsdFBJTkRpYWxvZzogKGV2LnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IGxhbmRpbmdQYWdlU2VsZWN0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xhbmRpbmdfcGFnZScpIGFzIEhUTUxTZWxlY3RFbGVtZW50XG4gIGNvbnN0IHRoZW1lU2VsZWN0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RoZW1lX3NlbGVjdCcpIGFzIEhUTUxTZWxlY3RFbGVtZW50XG4gIGNvbnN0IHRoZW1lQmcgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGhlbWUtYmcnKSBhcyBIVE1MSW5wdXRFbGVtZW50XG5cbiAgbGV0IGlzRGFyayA9IGZhbHNlXG4gIGxldCBpc0JnRW5hYmxlZCA9IGZhbHNlXG5cbiAgaWYgKHJlc3VsdC50aGVtZSA9PT0gJ2RhcmsnIHx8ICghKCd0aGVtZScgaW4gcmVzdWx0KSAmJiB3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKScpLm1hdGNoZXMpKSB7XG4gICAgaXNEYXJrID0gdHJ1ZVxuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdkYXJrJylcbiAgICB0aGVtZVNlbGVjdC52YWx1ZSA9ICdkYXJrJ1xuICB9IGVsc2Uge1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdkYXJrJylcbiAgICB0aGVtZVNlbGVjdC52YWx1ZSA9ICdsaWdodCdcbiAgfVxuXG4gIGlmIChyZXN1bHQuYmcgPT09ICd5ZXMnKSB7XG4gICAgaXNCZ0VuYWJsZWQgPSB0cnVlXG5cbiAgICBpZiAoaXNEYXJrKSB7XG4gICAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoJ2JnLXRoZW1lLWRhcmsnKVxuICAgIH0gZWxzZSB7XG4gICAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoJ2JnLXRoZW1lJylcbiAgICB9XG4gICAgdGhlbWVCZy5jaGVja2VkID0gdHJ1ZVxuICB9IGVsc2Uge1xuICAgIHRoZW1lQmcuY2hlY2tlZCA9IGZhbHNlXG4gIH1cblxuICB0aGVtZUJnLm9uY2hhbmdlID0gKGV2KSA9PiB7XG4gICAgaWYgKChldi50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkuY2hlY2tlZCkge1xuICAgICAgaXNCZ0VuYWJsZWQgPSB0cnVlXG5cbiAgICAgIGlmIChpc0RhcmspIHtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdiZy10aGVtZS1kYXJrJylcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnRvZ2dsZSgnYmctdGhlbWUnKVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpc0JnRW5hYmxlZCA9IGZhbHNlXG4gICAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5yZW1vdmUoJ2JnLXRoZW1lJylcbiAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZSgnYmctdGhlbWUtZGFyaycpXG4gICAgfVxuICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICBiZzogKGV2LnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkID8gJ3llcycgOiAnbm8nXG4gICAgfSlcbiAgfVxuXG4gIHRoZW1lU2VsZWN0Lm9uY2hhbmdlID0gKGV2KSA9PiB7XG4gICAgaXNEYXJrID0gKGV2LnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZSA9PT0gJ2RhcmsnXG5cbiAgICBpZiAoaXNCZ0VuYWJsZWQpIHtcbiAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZSgnYmctdGhlbWUnKVxuICAgICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKCdiZy10aGVtZS1kYXJrJylcblxuICAgICAgaWYgKGlzRGFyaykge1xuICAgICAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoJ2JnLXRoZW1lLWRhcmsnKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdiZy10aGVtZScpXG4gICAgICB9XG4gICAgfVxuXG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsYXNzTGlzdC50b2dnbGUoJ2RhcmsnKVxuICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IHRoZW1lOiAoZXYudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlIH0pXG4gIH1cblxuICBpZiAocmVzdWx0LmxhbmRpbmdQYWdlKSB7XG4gICAgbGFuZGluZ1BhZ2VTZWxlY3QudmFsdWUgPSByZXN1bHQubGFuZGluZ1BhZ2VcbiAgfVxuXG4gIGxhbmRpbmdQYWdlU2VsZWN0Lm9uY2hhbmdlID0gKGV2KSA9PiB7XG4gICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgbGFuZGluZ1BhZ2U6IChldi50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWUgfSlcbiAgfVxufSlcblxuLyogSW5pdGlhbGl6ZSBGb3JtICovXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignRE9NQ29udGVudExvYWRlZCcsICgpID0+IHtcbiAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFxuICAgIHtcbiAgICAgIGF1dGhDcmVkZW50aWFsczoge1xuICAgICAgICByZXF1aXJlUGluOiBmYWxzZSxcbiAgICAgICAgYXV0b0xvZ2luOiB0cnVlLFxuICAgICAgICB1c2VybmFtZTogJycsXG4gICAgICAgIHBhc3N3b3JkOiAnJyxcbiAgICAgICAgcTE6ICcnLFxuICAgICAgICBxMjogJycsXG4gICAgICAgIHEzOiAnJyxcbiAgICAgICAgYTE6ICcnLFxuICAgICAgICBhMjogJycsXG4gICAgICAgIGEzOiAnJ1xuICAgICAgfVxuICAgIH0sXG4gICAgKHJlc3VsdCkgPT4ge1xuICAgICAgY29uc3QgYXV0aENyZWRlbnRpYWxzID0gcmVzdWx0LmF1dGhDcmVkZW50aWFsc1xuICAgICAgY29uc29sZS5sb2coYXV0aENyZWRlbnRpYWxzKVxuXG4gICAgICBjb25zdCBmb3JtID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Zvcm1fYWRkX3VzZXInKSBhcyBIVE1MRm9ybUVsZW1lbnRcbiAgICAgIGNvbnN0IGZvcm1SZXNldEJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZXNldF9mb3JtJykgYXMgSFRNTElucHV0RWxlbWVudFxuICAgICAgY29uc3QgZm9ybVN1Ym1pdEJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzdWJtaXRfZm9ybScpIGFzIEhUTUxJbnB1dEVsZW1lbnRcblxuICAgICAgY29uc3QgdXNlcm5hbWUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndXNlcm5hbWUnKSBhcyBIVE1MSW5wdXRFbGVtZW50XG4gICAgICBjb25zdCB1c2VybmFtZVN1Ym1pdEJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd1c2VybmFtZV9zdWJtaXRfYnV0dG9uJykgYXMgSFRNTElucHV0RWxlbWVudFxuXG4gICAgICBjb25zdCBwYXNzd29yZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwYXNzd29yZCcpIGFzIEhUTUxJbnB1dEVsZW1lbnRcbiAgICAgIGNvbnN0IGExID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3F1ZXN0aW9uX29uZScpIGFzIEhUTUxJbnB1dEVsZW1lbnRcbiAgICAgIGNvbnN0IGEyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3F1ZXN0aW9uX3R3bycpIGFzIEhUTUxJbnB1dEVsZW1lbnRcbiAgICAgIGNvbnN0IGEzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3F1ZXN0aW9uX3RocmVlJykgYXMgSFRNTElucHV0RWxlbWVudFxuICAgICAgY29uc3QgcGluID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3BpbicpIGFzIEhUTUxJbnB1dEVsZW1lbnRcblxuICAgICAgY29uc3QgcXVlc3Rpb25zID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcImlucHV0W25hbWU9J3F1ZXN0aW9uJ11cIikgYXMgTm9kZUxpc3RPZjxIVE1MSW5wdXRFbGVtZW50PlxuICAgICAgY29uc3QgZm9ybVRvZ2dsZUJ0bnMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcubGVmdC1idXR0b24sLnJpZ2h0LWJ1dHRvbicpIGFzIE5vZGVMaXN0T2Y8SFRNTEJ1dHRvbkVsZW1lbnQ+XG5cbiAgICAgIC8vIEV4dHJhc1xuICAgICAgY29uc3QgbG9hZGVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xvYWRlcicpIGFzIEhUTUxEaXZFbGVtZW50XG4gICAgICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuYm94LWNvbnRhaW5lcicpIGFzIEhUTUxFbGVtZW50XG4gICAgICBjb25zdCBhdXRvTG9naW5Ub2dnbGVCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYXV0b0xvZ2luJykgYXMgSFRNTElucHV0RWxlbWVudFxuXG4gICAgICB1c2VybmFtZS52YWx1ZSA9IGF1dGhDcmVkZW50aWFscy51c2VybmFtZSB8fCAnJ1xuICAgICAgcGFzc3dvcmQudmFsdWUgPSBhdXRoQ3JlZGVudGlhbHMucGFzc3dvcmQgfHwgJydcbiAgICAgIGExLnZhbHVlID0gYXV0aENyZWRlbnRpYWxzLmExIHx8ICcnXG4gICAgICBhMi52YWx1ZSA9IGF1dGhDcmVkZW50aWFscy5hMiB8fCAnJ1xuICAgICAgYTMudmFsdWUgPSBhdXRoQ3JlZGVudGlhbHMuYTMgfHwgJydcbiAgICAgIGExLnBsYWNlaG9sZGVyID0gYXV0aENyZWRlbnRpYWxzLnExIHx8ICdZb3VyIGVycCBxdWVzdGlvbiAxJ1xuICAgICAgYTIucGxhY2Vob2xkZXIgPSBhdXRoQ3JlZGVudGlhbHMucTIgfHwgJ1lvdXIgZXJwIHF1ZXN0aW9uIDInXG4gICAgICBhMy5wbGFjZWhvbGRlciA9IGF1dGhDcmVkZW50aWFscy5xMyB8fCAnWW91ciBlcnAgcXVlc3Rpb24gMydcbiAgICAgIGF1dG9Mb2dpblRvZ2dsZUJ0bi5jaGVja2VkID0gYXV0aENyZWRlbnRpYWxzLmF1dG9Mb2dpblxuXG4gICAgICBpZiAoYXV0aENyZWRlbnRpYWxzLnVzZXJuYW1lID09PSAnJykge1xuICAgICAgICBsb2dnZXIoJ0VudGVyIFJvbGwgTnVtYmVyJylcbiAgICAgICAgdXNlcm5hbWUucmVtb3ZlQXR0cmlidXRlKCdkaXNhYmxlZCcpXG4gICAgICAgIHVzZXJuYW1lU3VibWl0QnRuLnJlbW92ZUF0dHJpYnV0ZSgnZGlzYWJsZWQnKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbG9nZ2VyKGBZb3UgYXJlIGFsbCBzZXQhICR7YXV0aENyZWRlbnRpYWxzLnVzZXJuYW1lfWAsICdzdWNjZXNzJylcblxuICAgICAgICBwaW4uc3R5bGUuZGlzcGxheSA9ICdub25lJ1xuICAgICAgICBjb25zdCBzbWFsbFRleHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdiJykgYXMgSFRNTEVsZW1lbnRcbiAgICAgICAgc21hbGxUZXh0LnNldEF0dHJpYnV0ZSgnc3R5bGUnLCAnbWFyZ2luLWxlZnQ6IDUwcHgnKVxuICAgICAgICBpZiAoYXV0aENyZWRlbnRpYWxzLnJlcXVpcmVQaW4pIHNtYWxsVGV4dC5pbm5lclRleHQgPSAnUElOIHdhcyBzZXQgISdcbiAgICAgICAgZWxzZSBzbWFsbFRleHQuaW5uZXJUZXh0ID0gJ1BJTiB3YXMgTk9UIHNldCAhJ1xuXG4gICAgICAgIHBpbi5hZnRlcihzbWFsbFRleHQpXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGVtcHR5RmllbGRFeGlzdHMgPVxuICAgICAgICBhdXRoQ3JlZGVudGlhbHMudXNlcm5hbWUgPT09ICcnIHx8XG4gICAgICAgIGF1dGhDcmVkZW50aWFscy5wYXNzd29yZCA9PT0gJycgfHxcbiAgICAgICAgYXV0aENyZWRlbnRpYWxzLmExID09PSAnJyB8fFxuICAgICAgICBhdXRoQ3JlZGVudGlhbHMucTEgPT09ICdZb3VyIGVycCBxdWVzdGlvbiAxJyB8fFxuICAgICAgICBhdXRoQ3JlZGVudGlhbHMuYTIgPT09ICcnIHx8XG4gICAgICAgIGF1dGhDcmVkZW50aWFscy5xMiA9PT0gJ1lvdXIgZXJwIHF1ZXN0aW9uIDInIHx8XG4gICAgICAgIGF1dGhDcmVkZW50aWFscy5hMyA9PT0gJycgfHxcbiAgICAgICAgYXV0aENyZWRlbnRpYWxzLnEzID09PSAnWW91ciBlcnAgcXVlc3Rpb24gMidcblxuICAgICAgaWYgKGVtcHR5RmllbGRFeGlzdHMpIHtcbiAgICAgICAgY29udGFpbmVyLmNsYXNzTGlzdC50b2dnbGUoJ3JpZ2h0LW9wZW4nKVxuICAgICAgfVxuXG4gICAgICBmb3JtVG9nZ2xlQnRucy5mb3JFYWNoKChidXR0b24pID0+XG4gICAgICAgIGJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgICBjb250YWluZXIuY2xhc3NMaXN0LnRvZ2dsZSgncmlnaHQtb3BlbicpXG4gICAgICAgIH0pXG4gICAgICApXG5cbiAgICAgIGF1dG9Mb2dpblRvZ2dsZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudFxuXG4gICAgICAgIGNvbnNvbGUubG9nKGBjdXJyICR7dGFyZ2V0LmlkfTpgLCBhdXRoQ3JlZGVudGlhbHNbdGFyZ2V0LmlkXSlcbiAgICAgICAgY29uc29sZS5sb2coYHNldCAke3RhcmdldC5pZH0gdG86YCwgdGFyZ2V0LmNoZWNrZWQpXG5cbiAgICAgICAgYXV0aENyZWRlbnRpYWxzW3RhcmdldC5pZF0gPSB0YXJnZXQuY2hlY2tlZFxuICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1xuICAgICAgICAgIGF1dGhDcmVkZW50aWFsczogYXV0aENyZWRlbnRpYWxzIGFzIENyZWRlbnRpYWxcbiAgICAgICAgfSlcbiAgICAgIH0pXG5cbiAgICAgIGZvcm0uYWRkRXZlbnRMaXN0ZW5lcignc3VibWl0JywgYXN5bmMgKGUpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICAgICAgbG9hZGVyLnN0eWxlLmRpc3BsYXkgPSAnZmxleCdcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgbG9hZGVyLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcbiAgICAgICAgfSwgNTAwKVxuXG4gICAgICAgIGlmIChwaW4udmFsdWUpIHtcbiAgICAgICAgICBwaW4uc3R5bGUuZGlzcGxheSA9ICdub25lJ1xuICAgICAgICAgIGNvbnN0IHNtYWxsVGV4dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NtYWxsJylcbiAgICAgICAgICBzbWFsbFRleHQuc2V0QXR0cmlidXRlKCdzdHlsZScsICdtYXJnaW4tbGVmdDogNTBweCcpXG4gICAgICAgICAgc21hbGxUZXh0LmlubmVyVGV4dCA9ICdQSU4gaXMgc2V0ISdcbiAgICAgICAgICBwaW4uYWZ0ZXIoc21hbGxUZXh0KVxuXG4gICAgICAgICAgY29uc3QgW2FuczEsIGFuczIsIGFuczMsIHBhc3NdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgICAgZW5jcnlwdChhMS52YWx1ZSwgcGluLnZhbHVlKSxcbiAgICAgICAgICAgIGVuY3J5cHQoYTIudmFsdWUsIHBpbi52YWx1ZSksXG4gICAgICAgICAgICBlbmNyeXB0KGEzLnZhbHVlLCBwaW4udmFsdWUpLFxuICAgICAgICAgICAgZW5jcnlwdChwYXNzd29yZC52YWx1ZSwgcGluLnZhbHVlKVxuICAgICAgICAgIF0pXG5cbiAgICAgICAgICBjb25zdCBlbmNyeXB0ZWRDcmVkOiBDcmVkZW50aWFsID0ge1xuICAgICAgICAgICAgYXV0b0xvZ2luOiBhdXRoQ3JlZGVudGlhbHMuYXV0b0xvZ2luLFxuICAgICAgICAgICAgdXNlcm5hbWU6IHVzZXJuYW1lLnZhbHVlLFxuICAgICAgICAgICAgcTE6IGExLnBsYWNlaG9sZGVyLFxuICAgICAgICAgICAgcTI6IGEyLnBsYWNlaG9sZGVyLFxuICAgICAgICAgICAgcTM6IGEzLnBsYWNlaG9sZGVyLFxuICAgICAgICAgICAgcmVxdWlyZVBpbjogdHJ1ZSxcbiAgICAgICAgICAgIHBhc3N3b3JkOiBwYXNzLFxuICAgICAgICAgICAgYTE6IGFuczEsXG4gICAgICAgICAgICBhMjogYW5zMixcbiAgICAgICAgICAgIGEzOiBhbnMzXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgYXV0aENyZWRlbnRpYWxzOiBlbmNyeXB0ZWRDcmVkIH0sICgpID0+IGxvY2F0aW9uLnJlbG9hZCgpKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IGNyZWRlbnRpYWxzID0ge1xuICAgICAgICAgICAgYXV0b0xvZ2luOiBhdXRoQ3JlZGVudGlhbHMuYXV0b0xvZ2luLFxuICAgICAgICAgICAgdXNlcm5hbWU6IHVzZXJuYW1lLnZhbHVlLFxuICAgICAgICAgICAgcTE6IGExLnBsYWNlaG9sZGVyLFxuICAgICAgICAgICAgcTI6IGEyLnBsYWNlaG9sZGVyLFxuICAgICAgICAgICAgcTM6IGEzLnBsYWNlaG9sZGVyLFxuICAgICAgICAgICAgcmVxdWlyZVBpbjogZmFsc2UsXG4gICAgICAgICAgICBwYXNzd29yZDogcGFzc3dvcmQudmFsdWUsXG4gICAgICAgICAgICBhMTogYTEudmFsdWUsXG4gICAgICAgICAgICBhMjogYTIudmFsdWUsXG4gICAgICAgICAgICBhMzogYTMudmFsdWVcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBhdXRoQ3JlZGVudGlhbHM6IGNyZWRlbnRpYWxzIH0sICgpID0+IGxvY2F0aW9uLnJlbG9hZCgpKVxuICAgICAgICB9XG4gICAgICB9KVxuXG4gICAgICBmb3JtUmVzZXRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgICAgICBsb2dnZXIoXG4gICAgICAgICAgJ0FyZSB5b3Ugc3VyZSEnLFxuICAgICAgICAgICd3YXJuaW5nJyxcbiAgICAgICAgICB0cnVlLFxuICAgICAgICAgICgpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCd5ZXMnKVxuICAgICAgICAgICAgZG9jdW1lbnQuZm9ybXNbMF0ucmVzZXQoKVxuICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFsnYXV0aENyZWRlbnRpYWxzJ10sICgpID0+IHtcbiAgICAgICAgICAgICAgbG9jYXRpb24ucmVsb2FkKClcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgfSxcbiAgICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgICBsb2dnZXIoJ0NhbmNlbGxlZC4nKVxuICAgICAgICAgIH1cbiAgICAgICAgKVxuICAgICAgfSlcblxuICAgICAgdXNlcm5hbWUuYWRkRXZlbnRMaXN0ZW5lcigna2V5dXAnLCAoZSkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgICAgICBpZiAodXNlcm5hbWUudmFsdWUubGVuZ3RoICE9PSA5KSB7XG4gICAgICAgICAgaWYgKHVzZXJuYW1lLnZhbHVlLmxlbmd0aCA9PT0gOCB8fCB1c2VybmFtZS52YWx1ZS5sZW5ndGggPT09IDEwKSB7XG4gICAgICAgICAgICBxdWVzdGlvbnMuZm9yRWFjaCgocSwgaSkgPT4ge1xuICAgICAgICAgICAgICBxLnBsYWNlaG9sZGVyID0gYFlvdXIgZXJwIHF1ZXN0aW9uICR7aSArIDF9YFxuICAgICAgICAgICAgICBxLnZhbHVlID0gJydcbiAgICAgICAgICAgICAgcS5kaXNhYmxlZCA9IHRydWVcbiAgICAgICAgICAgIH0pXG5cbiAgICAgICAgICAgIHBhc3N3b3JkLnZhbHVlID0gJydcbiAgICAgICAgICAgIHBpbi52YWx1ZSA9ICcnXG5cbiAgICAgICAgICAgIHBhc3N3b3JkLmRpc2FibGVkID0gdHJ1ZVxuICAgICAgICAgICAgcGluLmRpc2FibGVkID0gdHJ1ZVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICB9KVxuXG4gICAgICB1c2VybmFtZVN1Ym1pdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgICAgIGxvZ2dlcignR2V0dGluZyBxdWVzdGlvbnMsIHdhaXQuLi4nKVxuXG4gICAgICAgIGNvbnN0IGVycFVzZXIgPSBuZXcgRVJQKHVzZXJuYW1lLnZhbHVlKSBhcyB1bmtub3duIGFzIHtcbiAgICAgICAgICBnZXRBbGxTZWN1cml0eVF1ZXM6ICgpID0+IFByb21pc2U8Ym9vbGVhbj5cbiAgICAgICAgICBvbkdldFNlY3VyaXR5UXVlczogKGRhdGE6IHN0cmluZykgPT4gdm9pZFxuICAgICAgICB9XG5cbiAgICAgICAgZXJwVXNlci5nZXRBbGxTZWN1cml0eVF1ZXMoKS50aGVuKChyZXM6IGJvb2xlYW4pID0+IHtcbiAgICAgICAgICBpZiAocmVzID09PSBmYWxzZSkge1xuICAgICAgICAgICAgbG9nZ2VyKCdJbnZhbGlkIFJvbGxObyEnLCAnZXJyb3InKVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBsb2dnZXIoJ1F1ZXN0aW9ucyBmZXRjaGVkIScsICdzdWNjZXNzJylcbiAgICAgICAgICAgIHBhc3N3b3JkLnJlbW92ZUF0dHJpYnV0ZSgnZGlzYWJsZWQnKVxuICAgICAgICAgICAgcGluLnJlbW92ZUF0dHJpYnV0ZSgnZGlzYWJsZWQnKVxuICAgICAgICAgICAgZm9ybVN1Ym1pdEJ0bi5yZW1vdmVBdHRyaWJ1dGUoJ2Rpc2FibGVkJylcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG5cbiAgICAgICAgbGV0IGlkeCA9IDBcbiAgICAgICAgZXJwVXNlci5vbkdldFNlY3VyaXR5UXVlcyA9IChxOiBzdHJpbmcpID0+IHtcbiAgICAgICAgICBxdWVzdGlvbnNbaWR4XS5yZW1vdmVBdHRyaWJ1dGUoJ2Rpc2FibGVkJylcbiAgICAgICAgICBxdWVzdGlvbnNbaWR4XS5wbGFjZWhvbGRlciA9IHFcbiAgICAgICAgICBpZHgrK1xuICAgICAgICB9XG4gICAgICB9KVxuXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgbG9hZGVyLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcbiAgICAgIH0sIDUwMClcbiAgICB9XG4gIClcbn0pXG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=