/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/services/crypto.ts":
/*!********************************!*\
  !*** ./src/services/crypto.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decrypt: () => (/* binding */ decrypt),
/* harmony export */   encrypt: () => (/* binding */ encrypt)
/* harmony export */ });
const buffToBase64 = (buff) => window.btoa(String.fromCharCode.apply(null, buff));
const base64ToBuff = (b64) => Uint8Array.from(window.atob(b64), (c) => c.charCodeAt(0));
const enc = new TextEncoder();
const dec = new TextDecoder();
const byteLen = { salt: 16, iv: 12 };
/**
 * Given a password,
 * @returns a key from the password.
 */
const getKeyFromPassword = (password) => {
    return window.crypto.subtle.importKey('raw', enc.encode(password), { name: 'PBKDF2' }, false, [
        'deriveBits',
        'deriveKey'
    ]);
};
/**
 * Given a key from a password and a salt,
 * @returns a key derived from the password and salt.
 */
const getKey = (keyFromPassword, salt) => {
    return window.crypto.subtle.deriveKey({
        name: 'PBKDF2',
        salt,
        iterations: 100000,
        hash: 'SHA-256'
    }, keyFromPassword, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
};
const encrypt = async (secret, password) => {
    const keyFromPassword = await getKeyFromPassword(password);
    const salt = window.crypto.getRandomValues(new Uint8Array(byteLen.salt));
    const key = await getKey(keyFromPassword, salt);
    const iv = window.crypto.getRandomValues(new Uint8Array(byteLen.iv));
    const encoded = enc.encode(secret);
    const cipherText = await window.crypto.subtle.encrypt({
        name: 'AES-GCM',
        iv
    }, key, encoded);
    const cipher = new Uint8Array(cipherText);
    const buffer = new Uint8Array(salt.byteLength + iv.byteLength + cipher.byteLength);
    buffer.set(salt, 0);
    buffer.set(iv, salt.byteLength);
    buffer.set(cipher, salt.byteLength + iv.byteLength);
    const encrypted = buffToBase64(buffer);
    return encrypted;
};
/**
 * Derive a key from a password supplied by the user,
 * use the key to decrypt the cipherText.
 * if the cipherText was decrypted successfully,
 *   return the decrypted value.
 * if there was an error decrypting,
 *   throw an error message.
 *
 * @param {string} encrypted encrypted base64 string
 * @param {string} password password for the encrypted data
 * @returns secret text set by encrypt() function or an error message
 */
const decrypt = async (encrypted, password) => {
    const encryptedBuffer = base64ToBuff(encrypted);
    const salt = encryptedBuffer.slice(0, byteLen.salt);
    const iv = encryptedBuffer.slice(byteLen.salt, byteLen.salt + byteLen.iv);
    const cipherText = encryptedBuffer.slice(byteLen.salt + byteLen.iv);
    const keyFromPassword = await getKeyFromPassword(password);
    const key = await getKey(keyFromPassword, salt);
    try {
        const decryptedEncoded = await window.crypto.subtle.decrypt({
            name: 'AES-GCM',
            iv
        }, key, cipherText);
        const decrypted = dec.decode(decryptedEncoded);
        return decrypted;
    }
    catch (e) {
        throw new Error(e);
    }
};



/***/ }),

/***/ "./src/utils/displayMessageOnErpLoginPage.ts":
/*!***************************************************!*\
  !*** ./src/utils/displayMessageOnErpLoginPage.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const MESSAGE_ELEMENT_ID = 'erp_auto_login_message';
const displayMessageOnErpLoginPage = (message, color = '#45a1ff') => {
    if (document.getElementById(MESSAGE_ELEMENT_ID)) {
        ;
        document.getElementById(MESSAGE_ELEMENT_ID).remove();
    }
    const msg = document.createElement('div');
    msg.setAttribute('id', MESSAGE_ELEMENT_ID);
    msg.setAttribute(`style`, `background-image: linear-gradient(to right, ${color}, rgb(237,78,80));color: #ffffff;font-weight:500; width:100%; height:35px; text-align: center;display:flex; justify-content: center; align-items: center;flex-direction:row`);
    msg.textContent = message;
    // const text = document.createElement('span')
    // text.textContent = message
    // const closeBtn = document.createElement('button')
    // closeBtn.setAttribute('style', 'margin-left: 10px; border: none; background-color: transparent; color: #ffffff;')
    // closeBtn.textContent = 'x'
    // closeBtn.addEventListener('click', () => {
    //   msg.remove()
    // })
    // msg.append(text, closeBtn)
    document.body.prepend(msg);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (displayMessageOnErpLoginPage);


/***/ }),

/***/ "./src/utils/pinDialog.ts":
/*!********************************!*\
  !*** ./src/utils/pinDialog.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// create a pin dialog using html
const pinDialog = document.createElement('dialog');
pinDialog.id = 'pinDialog';
pinDialog.open = false;
pinDialog.innerHTML = `
  <div class="prompt">
    Enter your 4 digit PIN
  </div>
  <form class="digit-group" data-group-name="digits" data-autosubmit="false" autocomplete="off">
	<input type="password" id="digit-1" name="digit-1" data-next="digit-2" />
    <input type="password" id="digit-2" name="digit-2" data-next="digit-3" data-previous="digit-1" />
    <input type="password" id="digit-3" name="digit-3" data-next="digit-4" data-previous="digit-2" />
    <input type="password" id="digit-4" name="digit-4" data-previous="digit-3" />
  </form>
	<button id="pinDialogCloseBtn">Close</button>
`;
const style = document.createElement('style');
style.innerHTML = `
body {
  overflow: hidden;
}
dialog {
    z-index: 2147483646 !important;
    position: fixed;
    // top: 50%;
    left: 50%;
    transform: translate(-50%, 0%);
    width: 340px;
    // height: 200px;
    border: none;
    border-radius: 0 0 3px 3px;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.5);
    padding: 10px;
    padding-left: 35px;
    margin: 0;
    
    background-color: #fff;
    // background-color: #0f0f1a;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;

    background-image: url("${chrome.runtime.getURL('assets/images/ext_icon.png')}");
    background-repeat: no-repeat;
    background-position: 25px center;
    background-size: 50px;
  }
  
  dialog::backdrop {
    background-color: rgba(0 0 0 / 0.5);
    // backdrop-filter: blur(3px);
  }

  
.digit-group input {
  width: 30px;
  height: 50px;
  // background-color: #18182a;
  background-color: #fff;
  border: 2px solid gray;
  border-radius: 5px;
  border-opacity: 0.5;
  line-height: 50px;
  text-align: center;
  font-size: 24px;
  font-family: "Raleway", sans-serif;
  font-weight: 200;
  // color: white;
  color: black;
  margin: 0 2px;
}

.prompt {
  margin-bottom: 20px;
  font-size: 16px;
  // color: white;
  color: black;
}
#pinDialogCloseBtn {
  margin-top: 20px;
  border-radius: 5px;
  border: none;
  // color: white;
  color: black;
  padding: 5px 10px;
}
`;
async function getPinFromDialog() {
    let pin = '';
    // add the elements to the DOM
    document.head.appendChild(style);
    document.body.appendChild(pinDialog);
    // show the pin dialog
    pinDialog.showModal();
    // get the pin from the dialog
    // convert above jQuery code to javascript
    const pinDialogCloseBtn = document.getElementById('pinDialogCloseBtn');
    pinDialogCloseBtn.addEventListener('click', () => {
        pinDialog.close();
    });
    const digitGroups = document.querySelectorAll('.digit-group');
    digitGroups.forEach((digitGroup) => {
        const inputs = digitGroup.querySelectorAll('input');
        inputs.forEach((input) => {
            input.setAttribute('maxlength', '1');
            input.addEventListener('keyup', (e) => {
                const parent = input.parentElement;
                if (e.keyCode === 8 || e.keyCode === 37) {
                    const prev = parent.querySelector(`input#${input.dataset.previous}`);
                    if (prev)
                        prev.select();
                }
                else if ((e.keyCode >= 48 && e.keyCode <= 57) ||
                    (e.keyCode >= 65 && e.keyCode <= 90) ||
                    (e.keyCode >= 96 && e.keyCode <= 105) ||
                    e.keyCode === 39) {
                    const next = parent.querySelector(`input#${input.dataset.next}`);
                    if (next)
                        next.select();
                    else if (parent.dataset.autosubmit) {
                        // print the pin
                        console.log(inputs[0].value + inputs[1].value + inputs[2].value + inputs[3].value);
                        pin = inputs[0].value + inputs[1].value + inputs[2].value + inputs[3].value;
                        pinDialog.close();
                    }
                }
            });
        });
    });
    // wait for the pin to be entered
    await new Promise((resolve) => {
        pinDialog.addEventListener('close', resolve);
    });
    // remove the pin dialog
    pinDialog.remove();
    style.remove();
    return new Promise((resolve, reject) => {
        resolve(pin);
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getPinFromDialog);


/***/ }),

/***/ "./src/utils/validateCredentials.ts":
/*!******************************************!*\
  !*** ./src/utils/validateCredentials.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FieldValidationStatus: () => (/* binding */ FieldValidationStatus),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var FieldValidationStatus;
(function (FieldValidationStatus) {
    FieldValidationStatus[FieldValidationStatus["SomeFieldIsEmpty"] = 0] = "SomeFieldIsEmpty";
    FieldValidationStatus[FieldValidationStatus["AllFieldsFilled"] = 1] = "AllFieldsFilled";
})(FieldValidationStatus || (FieldValidationStatus = {}));
const validateCredentials = (credObjFromStorage) => {
    if (credObjFromStorage.username !== '' &&
        credObjFromStorage.password !== '' &&
        credObjFromStorage.q1 !== 'Your ERP question 1' &&
        credObjFromStorage.q2 !== 'Your ERP question 2' &&
        credObjFromStorage.q3 !== 'Your ERP question 3' &&
        credObjFromStorage.a1 !== '' &&
        credObjFromStorage.a2 !== '' &&
        credObjFromStorage.a3 !== '') {
        return FieldValidationStatus.AllFieldsFilled;
    }
    else {
        return FieldValidationStatus.SomeFieldIsEmpty;
    }
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (validateCredentials);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!************************!*\
  !*** ./src/content.ts ***!
  \************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var services_crypto__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! services/crypto */ "./src/services/crypto.ts");
/* harmony import */ var utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! utils/displayMessageOnErpLoginPage */ "./src/utils/displayMessageOnErpLoginPage.ts");
/* harmony import */ var utils_pinDialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! utils/pinDialog */ "./src/utils/pinDialog.ts");
/* harmony import */ var utils_validateCredentials__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! utils/validateCredentials */ "./src/utils/validateCredentials.ts");




// Create an observer instance linked to the callback function
const login = async (res) => {
    /**
     * ?Skip if no credentials are stored or autoLogin is not enabled
     */
    if (!res.authCredentials) {
        (0,utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__["default"])('You have extension for automatic login. Please fill it', '#715100');
        return;
    }
    const credentials = res.authCredentials;
    if (!credentials.autoLogin) {
        (0,utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__["default"])('Automatic login is turned off!', '#4a4a4f');
        return;
    }
    const fieldsValidationStatus = (0,utils_validateCredentials__WEBPACK_IMPORTED_MODULE_3__["default"])(res.authCredentials);
    if (fieldsValidationStatus === utils_validateCredentials__WEBPACK_IMPORTED_MODULE_3__.FieldValidationStatus.SomeFieldIsEmpty) {
        (0,utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__["default"])('Please fill all the fields', '#4a4a4f');
        return;
    }
    /**
     * ?Initialize the login process
     */
    if (fieldsValidationStatus === utils_validateCredentials__WEBPACK_IMPORTED_MODULE_3__.FieldValidationStatus.AllFieldsFilled)
        (0,utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__["default"])('Prefilling credentials! please wait...');
    const { requirePin, username } = credentials;
    let pin = '';
    if (requirePin) {
        res.useAltPINDialog ? (pin = await (0,utils_pinDialog__WEBPACK_IMPORTED_MODULE_2__["default"])()) : (pin = prompt('Enter your 4 digit PIN') ?? '');
    }
    let password = '', question = '', answer = '';
    const usernameInput = document.getElementById('user_id');
    const observer = new MutationObserver(async (mutationList, observer) => {
        let [mutation] = mutationList;
        let [node] = mutation.addedNodes;
        question = node.nodeValue;
        observer.disconnect();
        switch (question) {
            case credentials.q1:
                answer = credentials.a1;
                break;
            case credentials.q2:
                answer = credentials.a2;
                break;
            case credentials.q3:
                answer = credentials.a3;
                break;
            default:
                /**
                 * !This means that the credentials are invalid
                 */
                (0,utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__["default"])('Invalid username/password set! Please update your credentials', '#a4000f');
                return;
        }
        if (requirePin) {
            try {
                password = await (0,services_crypto__WEBPACK_IMPORTED_MODULE_0__.decrypt)(credentials.password, pin);
                answer = await (0,services_crypto__WEBPACK_IMPORTED_MODULE_0__.decrypt)(answer, pin);
            }
            catch (_) {
                (0,utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__["default"])('Incorrect PIN!, Please reset if forgot or refresh page to retry.', '#a4000f');
                return;
            }
        }
        else {
            password = credentials.password;
        }
        (0,utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__["default"])('Prefilling credentials! please wait...');
        let passwordInput = document.getElementById('password');
        let answerInput = document.getElementById('answer');
        if (!passwordInput || !answerInput) {
            (0,utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__["default"])('Something went wrong! Please refresh page and retry', '#a4000f');
            return;
        }
        passwordInput.value = password;
        answerInput.value = answer;
        document.getElementById('getotp')?.click();
        (0,utils_displayMessageOnErpLoginPage__WEBPACK_IMPORTED_MODULE_1__["default"])("Data filled and 'OTP' was sent to mail. Fill the OTP from your mail", '#4a4a4f');
    });
    if (usernameInput) {
        observer.observe(document.getElementById('answer_div'), {
            attributes: false,
            childList: true,
            subtree: true
        });
        // make sure
        usernameInput.value = username;
        usernameInput.blur();
    }
};
chrome.storage.local.get({
    authCredentials: null,
    landingPage: null,
    useAltPINDialog: false
}, login);

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSxNQUFNLFlBQVksR0FBRyxDQUFDLElBQWdCLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLElBQTJCLENBQUMsQ0FBQztBQUNwSCxNQUFNLFlBQVksR0FBRyxDQUFDLEdBQVcsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBRS9GLE1BQU0sR0FBRyxHQUFHLElBQUksV0FBVyxFQUFFO0FBQzdCLE1BQU0sR0FBRyxHQUFHLElBQUksV0FBVyxFQUFFO0FBQzdCLE1BQU0sT0FBTyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFO0FBRXBDOzs7R0FHRztBQUNILE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxRQUFnQixFQUFFLEVBQUU7SUFDOUMsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEVBQUUsS0FBSyxFQUFFO1FBQzVGLFlBQVk7UUFDWixXQUFXO0tBQ1osQ0FBQztBQUNKLENBQUM7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLE1BQU0sR0FBRyxDQUFDLGVBQTBCLEVBQUUsSUFBa0IsRUFBRSxFQUFFO0lBQ2hFLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUNuQztRQUNFLElBQUksRUFBRSxRQUFRO1FBQ2QsSUFBSTtRQUNKLFVBQVUsRUFBRSxNQUFNO1FBQ2xCLElBQUksRUFBRSxTQUFTO0tBQ2hCLEVBQ0QsZUFBZSxFQUNmLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLEVBQ2hDLElBQUksRUFDSixDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FDdkI7QUFDSCxDQUFDO0FBRUQsTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLE1BQWMsRUFBRSxRQUFnQixFQUFFLEVBQUU7SUFDekQsTUFBTSxlQUFlLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxRQUFRLENBQUM7SUFDMUQsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsSUFBSSxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3hFLE1BQU0sR0FBRyxHQUFHLE1BQU0sTUFBTSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7SUFDL0MsTUFBTSxFQUFFLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsSUFBSSxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3BFLE1BQU0sT0FBTyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0lBRWxDLE1BQU0sVUFBVSxHQUFHLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUNuRDtRQUNFLElBQUksRUFBRSxTQUFTO1FBQ2YsRUFBRTtLQUNILEVBQ0QsR0FBRyxFQUNILE9BQU8sQ0FDUjtJQUVELE1BQU0sTUFBTSxHQUFHLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FBQztJQUN6QyxNQUFNLE1BQU0sR0FBRyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQztJQUNsRixNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7SUFDbkIsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUMvQixNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFFbkQsTUFBTSxTQUFTLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQztJQUN0QyxPQUFPLFNBQVM7QUFDbEIsQ0FBQztBQUVEOzs7Ozs7Ozs7OztHQVdHO0FBQ0gsTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLFNBQWlCLEVBQUUsUUFBZ0IsRUFBRSxFQUFFO0lBQzVELE1BQU0sZUFBZSxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUM7SUFDL0MsTUFBTSxJQUFJLEdBQUcsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQztJQUNuRCxNQUFNLEVBQUUsR0FBRyxlQUFlLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQ3pFLE1BQU0sVUFBVSxHQUFHLGVBQWUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBRW5FLE1BQU0sZUFBZSxHQUFHLE1BQU0sa0JBQWtCLENBQUMsUUFBUSxDQUFDO0lBQzFELE1BQU0sR0FBRyxHQUFHLE1BQU0sTUFBTSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7SUFFL0MsSUFBSTtRQUNGLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQ3pEO1lBQ0UsSUFBSSxFQUFFLFNBQVM7WUFDZixFQUFFO1NBQ0gsRUFDRCxHQUFHLEVBQ0gsVUFBVSxDQUNYO1FBRUQsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQztRQUM5QyxPQUFPLFNBQVM7S0FDakI7SUFBQyxPQUFPLENBQUMsRUFBRTtRQUNWLE1BQU0sSUFBSSxLQUFLLENBQUMsQ0FBVyxDQUFDO0tBQzdCO0FBQ0gsQ0FBQztBQUUwQjs7Ozs7Ozs7Ozs7Ozs7O0FDckczQixNQUFNLGtCQUFrQixHQUFHLHdCQUF3QjtBQUVuRCxNQUFNLDRCQUE0QixHQUFHLENBQUMsT0FBZSxFQUFFLEtBQUssR0FBRyxTQUFTLEVBQUUsRUFBRTtJQUMxRSxJQUFJLFFBQVEsQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUMsRUFBRTtRQUMvQyxDQUFDO1FBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBaUIsQ0FBQyxNQUFNLEVBQUU7S0FDdkU7SUFFRCxNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBbUI7SUFDM0QsR0FBRyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLENBQUM7SUFDMUMsR0FBRyxDQUFDLFlBQVksQ0FDZCxPQUFPLEVBQ1AsK0NBQStDLEtBQUssNktBQTZLLENBQ2xPO0lBQ0QsR0FBRyxDQUFDLFdBQVcsR0FBRyxPQUFPO0lBRXpCLDhDQUE4QztJQUM5Qyw2QkFBNkI7SUFFN0Isb0RBQW9EO0lBQ3BELG9IQUFvSDtJQUNwSCw2QkFBNkI7SUFFN0IsNkNBQTZDO0lBQzdDLGlCQUFpQjtJQUNqQixLQUFLO0lBRUwsNkJBQTZCO0lBQzdCLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztBQUM1QixDQUFDO0FBRUQsaUVBQWUsNEJBQTRCOzs7Ozs7Ozs7Ozs7Ozs7QUM5QjNDLGlDQUFpQztBQUNqQyxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQztBQUNsRCxTQUFTLENBQUMsRUFBRSxHQUFHLFdBQVc7QUFDMUIsU0FBUyxDQUFDLElBQUksR0FBRyxLQUFLO0FBQ3RCLFNBQVMsQ0FBQyxTQUFTLEdBQUc7Ozs7Ozs7Ozs7O0NBV3JCO0FBRUQsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7QUFDN0MsS0FBSyxDQUFDLFNBQVMsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NkJBMEJXLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLDRCQUE0QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTRDL0U7QUFFRCxLQUFLLFVBQVUsZ0JBQWdCO0lBQzdCLElBQUksR0FBRyxHQUFHLEVBQUU7SUFDWiw4QkFBOEI7SUFDOUIsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO0lBQ2hDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQztJQUVwQyxzQkFBc0I7SUFDdEIsU0FBUyxDQUFDLFNBQVMsRUFBRTtJQUVyQiw4QkFBOEI7SUFDOUIsMENBQTBDO0lBQzFDLE1BQU0saUJBQWlCLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBc0I7SUFDM0YsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLEdBQUcsRUFBRTtRQUMvQyxTQUFTLENBQUMsS0FBSyxFQUFFO0lBQ25CLENBQUMsQ0FBQztJQUNGLE1BQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUM7SUFDN0QsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO1FBQ2pDLE1BQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUM7UUFDbkQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ3ZCLEtBQUssQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQztZQUNwQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3BDLE1BQU0sTUFBTSxHQUFHLEtBQUssQ0FBQyxhQUFvQjtnQkFDekMsSUFBSSxDQUFDLENBQUMsT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxLQUFLLEVBQUUsRUFBRTtvQkFDdkMsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ3BFLElBQUksSUFBSTt3QkFBRSxJQUFJLENBQUMsTUFBTSxFQUFFO2lCQUN4QjtxQkFBTSxJQUNMLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7b0JBQ3BDLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7b0JBQ3BDLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUM7b0JBQ3JDLENBQUMsQ0FBQyxPQUFPLEtBQUssRUFBRSxFQUNoQjtvQkFDQSxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsYUFBYSxDQUFDLFNBQVMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDaEUsSUFBSSxJQUFJO3dCQUFFLElBQUksQ0FBQyxNQUFNLEVBQUU7eUJBQ2xCLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUU7d0JBQ2xDLGdCQUFnQjt3QkFDaEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUNsRixHQUFHLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7d0JBQzNFLFNBQVMsQ0FBQyxLQUFLLEVBQUU7cUJBQ2xCO2lCQUNGO1lBQ0gsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDO0lBRUYsaUNBQWlDO0lBQ2pDLE1BQU0sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtRQUM1QixTQUFTLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztJQUM5QyxDQUFDLENBQUM7SUFFRix3QkFBd0I7SUFDeEIsU0FBUyxDQUFDLE1BQU0sRUFBRTtJQUNsQixLQUFLLENBQUMsTUFBTSxFQUFFO0lBRWQsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtRQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ2QsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUVELGlFQUFlLGdCQUFnQjs7Ozs7Ozs7Ozs7Ozs7OztBQ3BKL0IsSUFBSyxxQkFHSjtBQUhELFdBQUsscUJBQXFCO0lBQ3hCLHlGQUFnQjtJQUNoQix1RkFBZTtBQUNqQixDQUFDLEVBSEkscUJBQXFCLEtBQXJCLHFCQUFxQixRQUd6QjtBQUVELE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxrQkFBOEMsRUFBeUIsRUFBRTtJQUNwRyxJQUNFLGtCQUFrQixDQUFDLFFBQVEsS0FBSyxFQUFFO1FBQ2xDLGtCQUFrQixDQUFDLFFBQVEsS0FBSyxFQUFFO1FBQ2xDLGtCQUFrQixDQUFDLEVBQUUsS0FBSyxxQkFBcUI7UUFDL0Msa0JBQWtCLENBQUMsRUFBRSxLQUFLLHFCQUFxQjtRQUMvQyxrQkFBa0IsQ0FBQyxFQUFFLEtBQUsscUJBQXFCO1FBQy9DLGtCQUFrQixDQUFDLEVBQUUsS0FBSyxFQUFFO1FBQzVCLGtCQUFrQixDQUFDLEVBQUUsS0FBSyxFQUFFO1FBQzVCLGtCQUFrQixDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQzVCO1FBQ0EsT0FBTyxxQkFBcUIsQ0FBQyxlQUFlO0tBQzdDO1NBQU07UUFDTCxPQUFPLHFCQUFxQixDQUFDLGdCQUFnQjtLQUM5QztBQUNILENBQUM7QUFFK0I7QUFDaEMsaUVBQWUsbUJBQW1COzs7Ozs7O1VDdkJsQztVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7OztXQ3RCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7Ozs7Ozs7Ozs7O0FDTHlDO0FBQ29DO0FBRS9CO0FBQ3dDO0FBRXRGLDhEQUE4RDtBQUU5RCxNQUFNLEtBQUssR0FBRyxLQUFLLEVBQUUsR0FBK0IsRUFBRSxFQUFFO0lBQ3REOztPQUVHO0lBRUgsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUU7UUFDeEIsOEVBQTRCLENBQUMsd0RBQXdELEVBQUUsU0FBUyxDQUFDO1FBQ2pHLE9BQU07S0FDUDtJQUVELE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxlQUE2QjtJQUVyRCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRTtRQUMxQiw4RUFBNEIsQ0FBQyxnQ0FBZ0MsRUFBRSxTQUFTLENBQUM7UUFDekUsT0FBTTtLQUNQO0lBRUQsTUFBTSxzQkFBc0IsR0FBRyxxRUFBbUIsQ0FBQyxHQUFHLENBQUMsZUFBNkMsQ0FBQztJQUVyRyxJQUFJLHNCQUFzQixLQUFLLDRFQUFxQixDQUFDLGdCQUFnQixFQUFFO1FBQ3JFLDhFQUE0QixDQUFDLDRCQUE0QixFQUFFLFNBQVMsQ0FBQztRQUNyRSxPQUFNO0tBQ1A7SUFFRDs7T0FFRztJQUVILElBQUksc0JBQXNCLEtBQUssNEVBQXFCLENBQUMsZUFBZTtRQUNsRSw4RUFBNEIsQ0FBQyx3Q0FBd0MsQ0FBQztJQUV4RSxNQUFNLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxHQUFHLFdBQVc7SUFFNUMsSUFBSSxHQUFHLEdBQUcsRUFBRTtJQUNaLElBQUksVUFBVSxFQUFFO1FBQ2QsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsTUFBTSwyREFBZ0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQztLQUN4RztJQUVELElBQUksUUFBUSxHQUFHLEVBQUUsRUFDZixRQUFRLEdBQUcsRUFBRSxFQUNiLE1BQU0sR0FBRyxFQUFFO0lBRWIsTUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQXFCO0lBRTVFLE1BQU0sUUFBUSxHQUFHLElBQUksZ0JBQWdCLENBQUMsS0FBSyxFQUFFLFlBQVksRUFBRSxRQUFRLEVBQUUsRUFBRTtRQUNyRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsWUFBWTtRQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsUUFBUSxDQUFDLFVBQVU7UUFFaEMsUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFtQjtRQUNuQyxRQUFRLENBQUMsVUFBVSxFQUFFO1FBRXJCLFFBQVEsUUFBUSxFQUFFO1lBQ2hCLEtBQUssV0FBVyxDQUFDLEVBQUU7Z0JBQ2pCLE1BQU0sR0FBRyxXQUFXLENBQUMsRUFBRTtnQkFDdkIsTUFBSztZQUVQLEtBQUssV0FBVyxDQUFDLEVBQUU7Z0JBQ2pCLE1BQU0sR0FBRyxXQUFXLENBQUMsRUFBRTtnQkFDdkIsTUFBSztZQUVQLEtBQUssV0FBVyxDQUFDLEVBQUU7Z0JBQ2pCLE1BQU0sR0FBRyxXQUFXLENBQUMsRUFBRTtnQkFDdkIsTUFBSztZQUVQO2dCQUNFOzttQkFFRztnQkFDSCw4RUFBNEIsQ0FBQywrREFBK0QsRUFBRSxTQUFTLENBQUM7Z0JBQ3hHLE9BQU07U0FDVDtRQUVELElBQUksVUFBVSxFQUFFO1lBQ2QsSUFBSTtnQkFDRixRQUFRLEdBQUcsTUFBTSx3REFBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsR0FBYSxDQUFDO2dCQUM3RCxNQUFNLEdBQUcsTUFBTSx3REFBTyxDQUFDLE1BQU0sRUFBRSxHQUFhLENBQUM7YUFDOUM7WUFBQyxPQUFPLENBQUMsRUFBRTtnQkFDViw4RUFBNEIsQ0FBQyxrRUFBa0UsRUFBRSxTQUFTLENBQUM7Z0JBQzNHLE9BQU07YUFDUDtTQUNGO2FBQU07WUFDTCxRQUFRLEdBQUcsV0FBVyxDQUFDLFFBQVE7U0FDaEM7UUFFRCw4RUFBNEIsQ0FBQyx3Q0FBd0MsQ0FBQztRQUV0RSxJQUFJLGFBQWEsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBcUI7UUFDM0UsSUFBSSxXQUFXLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQXFCO1FBRXZFLElBQUksQ0FBQyxhQUFhLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDbEMsOEVBQTRCLENBQUMscURBQXFELEVBQUUsU0FBUyxDQUFDO1lBQzlGLE9BQU07U0FDUDtRQUVELGFBQWEsQ0FBQyxLQUFLLEdBQUcsUUFBUTtRQUM5QixXQUFXLENBQUMsS0FBSyxHQUFHLE1BQU07UUFDMUIsUUFBUSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQztRQUUzQyw4RUFBNEIsQ0FBQyxxRUFBcUUsRUFBRSxTQUFTLENBQUM7SUFDaEgsQ0FBQyxDQUFDO0lBRUYsSUFBSSxhQUFhLEVBQUU7UUFDakIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBUyxFQUFFO1lBQzlELFVBQVUsRUFBRSxLQUFLO1lBQ2pCLFNBQVMsRUFBRSxJQUFJO1lBQ2YsT0FBTyxFQUFFLElBQUk7U0FDZCxDQUFDO1FBRUYsWUFBWTtRQUNaLGFBQWEsQ0FBQyxLQUFLLEdBQUcsUUFBUTtRQUM5QixhQUFhLENBQUMsSUFBSSxFQUFFO0tBQ3JCO0FBQ0gsQ0FBQztBQUVELE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FDdEI7SUFDRSxlQUFlLEVBQUUsSUFBSTtJQUNyQixXQUFXLEVBQUUsSUFBSTtJQUNqQixlQUFlLEVBQUUsS0FBSztDQUN2QixFQUNELEtBQUssQ0FDTiIsInNvdXJjZXMiOlsid2VicGFjazovL2F1dG8tbG9naW4tZXJwLy4vc3JjL3NlcnZpY2VzL2NyeXB0by50cyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC8uL3NyYy91dGlscy9kaXNwbGF5TWVzc2FnZU9uRXJwTG9naW5QYWdlLnRzIiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwLy4vc3JjL3V0aWxzL3BpbkRpYWxvZy50cyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC8uL3NyYy91dGlscy92YWxpZGF0ZUNyZWRlbnRpYWxzLnRzIiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9hdXRvLWxvZ2luLWVycC93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2F1dG8tbG9naW4tZXJwL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vYXV0by1sb2dpbi1lcnAvLi9zcmMvY29udGVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBidWZmVG9CYXNlNjQgPSAoYnVmZjogVWludDhBcnJheSkgPT4gd2luZG93LmJ0b2EoU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBidWZmIGFzIHVua25vd24gYXMgbnVtYmVyW10pKVxuY29uc3QgYmFzZTY0VG9CdWZmID0gKGI2NDogc3RyaW5nKSA9PiBVaW50OEFycmF5LmZyb20od2luZG93LmF0b2IoYjY0KSwgKGMpID0+IGMuY2hhckNvZGVBdCgwKSlcblxuY29uc3QgZW5jID0gbmV3IFRleHRFbmNvZGVyKClcbmNvbnN0IGRlYyA9IG5ldyBUZXh0RGVjb2RlcigpXG5jb25zdCBieXRlTGVuID0geyBzYWx0OiAxNiwgaXY6IDEyIH1cblxuLyoqXG4gKiBHaXZlbiBhIHBhc3N3b3JkLFxuICogQHJldHVybnMgYSBrZXkgZnJvbSB0aGUgcGFzc3dvcmQuXG4gKi9cbmNvbnN0IGdldEtleUZyb21QYXNzd29yZCA9IChwYXNzd29yZDogc3RyaW5nKSA9PiB7XG4gIHJldHVybiB3aW5kb3cuY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoJ3JhdycsIGVuYy5lbmNvZGUocGFzc3dvcmQpLCB7IG5hbWU6ICdQQktERjInIH0sIGZhbHNlLCBbXG4gICAgJ2Rlcml2ZUJpdHMnLFxuICAgICdkZXJpdmVLZXknXG4gIF0pXG59XG5cbi8qKlxuICogR2l2ZW4gYSBrZXkgZnJvbSBhIHBhc3N3b3JkIGFuZCBhIHNhbHQsXG4gKiBAcmV0dXJucyBhIGtleSBkZXJpdmVkIGZyb20gdGhlIHBhc3N3b3JkIGFuZCBzYWx0LlxuICovXG5jb25zdCBnZXRLZXkgPSAoa2V5RnJvbVBhc3N3b3JkOiBDcnlwdG9LZXksIHNhbHQ6IEJ1ZmZlclNvdXJjZSkgPT4ge1xuICByZXR1cm4gd2luZG93LmNyeXB0by5zdWJ0bGUuZGVyaXZlS2V5KFxuICAgIHtcbiAgICAgIG5hbWU6ICdQQktERjInLFxuICAgICAgc2FsdCxcbiAgICAgIGl0ZXJhdGlvbnM6IDEwMDAwMCxcbiAgICAgIGhhc2g6ICdTSEEtMjU2J1xuICAgIH0sXG4gICAga2V5RnJvbVBhc3N3b3JkLFxuICAgIHsgbmFtZTogJ0FFUy1HQ00nLCBsZW5ndGg6IDI1NiB9LFxuICAgIHRydWUsXG4gICAgWydlbmNyeXB0JywgJ2RlY3J5cHQnXVxuICApXG59XG5cbmNvbnN0IGVuY3J5cHQgPSBhc3luYyAoc2VjcmV0OiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpID0+IHtcbiAgY29uc3Qga2V5RnJvbVBhc3N3b3JkID0gYXdhaXQgZ2V0S2V5RnJvbVBhc3N3b3JkKHBhc3N3b3JkKVxuICBjb25zdCBzYWx0ID0gd2luZG93LmNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoYnl0ZUxlbi5zYWx0KSlcbiAgY29uc3Qga2V5ID0gYXdhaXQgZ2V0S2V5KGtleUZyb21QYXNzd29yZCwgc2FsdClcbiAgY29uc3QgaXYgPSB3aW5kb3cuY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheShieXRlTGVuLml2KSlcbiAgY29uc3QgZW5jb2RlZCA9IGVuYy5lbmNvZGUoc2VjcmV0KVxuXG4gIGNvbnN0IGNpcGhlclRleHQgPSBhd2FpdCB3aW5kb3cuY3J5cHRvLnN1YnRsZS5lbmNyeXB0KFxuICAgIHtcbiAgICAgIG5hbWU6ICdBRVMtR0NNJyxcbiAgICAgIGl2XG4gICAgfSxcbiAgICBrZXksXG4gICAgZW5jb2RlZFxuICApXG5cbiAgY29uc3QgY2lwaGVyID0gbmV3IFVpbnQ4QXJyYXkoY2lwaGVyVGV4dClcbiAgY29uc3QgYnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkoc2FsdC5ieXRlTGVuZ3RoICsgaXYuYnl0ZUxlbmd0aCArIGNpcGhlci5ieXRlTGVuZ3RoKVxuICBidWZmZXIuc2V0KHNhbHQsIDApXG4gIGJ1ZmZlci5zZXQoaXYsIHNhbHQuYnl0ZUxlbmd0aClcbiAgYnVmZmVyLnNldChjaXBoZXIsIHNhbHQuYnl0ZUxlbmd0aCArIGl2LmJ5dGVMZW5ndGgpXG5cbiAgY29uc3QgZW5jcnlwdGVkID0gYnVmZlRvQmFzZTY0KGJ1ZmZlcilcbiAgcmV0dXJuIGVuY3J5cHRlZFxufVxuXG4vKipcbiAqIERlcml2ZSBhIGtleSBmcm9tIGEgcGFzc3dvcmQgc3VwcGxpZWQgYnkgdGhlIHVzZXIsXG4gKiB1c2UgdGhlIGtleSB0byBkZWNyeXB0IHRoZSBjaXBoZXJUZXh0LlxuICogaWYgdGhlIGNpcGhlclRleHQgd2FzIGRlY3J5cHRlZCBzdWNjZXNzZnVsbHksXG4gKiAgIHJldHVybiB0aGUgZGVjcnlwdGVkIHZhbHVlLlxuICogaWYgdGhlcmUgd2FzIGFuIGVycm9yIGRlY3J5cHRpbmcsXG4gKiAgIHRocm93IGFuIGVycm9yIG1lc3NhZ2UuXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGVuY3J5cHRlZCBlbmNyeXB0ZWQgYmFzZTY0IHN0cmluZ1xuICogQHBhcmFtIHtzdHJpbmd9IHBhc3N3b3JkIHBhc3N3b3JkIGZvciB0aGUgZW5jcnlwdGVkIGRhdGFcbiAqIEByZXR1cm5zIHNlY3JldCB0ZXh0IHNldCBieSBlbmNyeXB0KCkgZnVuY3Rpb24gb3IgYW4gZXJyb3IgbWVzc2FnZVxuICovXG5jb25zdCBkZWNyeXB0ID0gYXN5bmMgKGVuY3J5cHRlZDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKSA9PiB7XG4gIGNvbnN0IGVuY3J5cHRlZEJ1ZmZlciA9IGJhc2U2NFRvQnVmZihlbmNyeXB0ZWQpXG4gIGNvbnN0IHNhbHQgPSBlbmNyeXB0ZWRCdWZmZXIuc2xpY2UoMCwgYnl0ZUxlbi5zYWx0KVxuICBjb25zdCBpdiA9IGVuY3J5cHRlZEJ1ZmZlci5zbGljZShieXRlTGVuLnNhbHQsIGJ5dGVMZW4uc2FsdCArIGJ5dGVMZW4uaXYpXG4gIGNvbnN0IGNpcGhlclRleHQgPSBlbmNyeXB0ZWRCdWZmZXIuc2xpY2UoYnl0ZUxlbi5zYWx0ICsgYnl0ZUxlbi5pdilcblxuICBjb25zdCBrZXlGcm9tUGFzc3dvcmQgPSBhd2FpdCBnZXRLZXlGcm9tUGFzc3dvcmQocGFzc3dvcmQpXG4gIGNvbnN0IGtleSA9IGF3YWl0IGdldEtleShrZXlGcm9tUGFzc3dvcmQsIHNhbHQpXG5cbiAgdHJ5IHtcbiAgICBjb25zdCBkZWNyeXB0ZWRFbmNvZGVkID0gYXdhaXQgd2luZG93LmNyeXB0by5zdWJ0bGUuZGVjcnlwdChcbiAgICAgIHtcbiAgICAgICAgbmFtZTogJ0FFUy1HQ00nLFxuICAgICAgICBpdlxuICAgICAgfSxcbiAgICAgIGtleSxcbiAgICAgIGNpcGhlclRleHRcbiAgICApXG5cbiAgICBjb25zdCBkZWNyeXB0ZWQgPSBkZWMuZGVjb2RlKGRlY3J5cHRlZEVuY29kZWQpXG4gICAgcmV0dXJuIGRlY3J5cHRlZFxuICB9IGNhdGNoIChlKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGUgYXMgc3RyaW5nKVxuICB9XG59XG5cbmV4cG9ydCB7IGVuY3J5cHQsIGRlY3J5cHQgfVxuIiwiY29uc3QgTUVTU0FHRV9FTEVNRU5UX0lEID0gJ2VycF9hdXRvX2xvZ2luX21lc3NhZ2UnXG5cbmNvbnN0IGRpc3BsYXlNZXNzYWdlT25FcnBMb2dpblBhZ2UgPSAobWVzc2FnZTogc3RyaW5nLCBjb2xvciA9ICcjNDVhMWZmJykgPT4ge1xuICBpZiAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoTUVTU0FHRV9FTEVNRU5UX0lEKSkge1xuICAgIDsoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoTUVTU0FHRV9FTEVNRU5UX0lEKSBhcyBIVE1MRWxlbWVudCkucmVtb3ZlKClcbiAgfVxuXG4gIGNvbnN0IG1zZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpIGFzIEhUTUxEaXZFbGVtZW50XG4gIG1zZy5zZXRBdHRyaWJ1dGUoJ2lkJywgTUVTU0FHRV9FTEVNRU5UX0lEKVxuICBtc2cuc2V0QXR0cmlidXRlKFxuICAgIGBzdHlsZWAsXG4gICAgYGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgJHtjb2xvcn0sIHJnYigyMzcsNzgsODApKTtjb2xvcjogI2ZmZmZmZjtmb250LXdlaWdodDo1MDA7IHdpZHRoOjEwMCU7IGhlaWdodDozNXB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7ZGlzcGxheTpmbGV4OyBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgYWxpZ24taXRlbXM6IGNlbnRlcjtmbGV4LWRpcmVjdGlvbjpyb3dgXG4gIClcbiAgbXNnLnRleHRDb250ZW50ID0gbWVzc2FnZVxuXG4gIC8vIGNvbnN0IHRleHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJylcbiAgLy8gdGV4dC50ZXh0Q29udGVudCA9IG1lc3NhZ2VcblxuICAvLyBjb25zdCBjbG9zZUJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpXG4gIC8vIGNsb3NlQnRuLnNldEF0dHJpYnV0ZSgnc3R5bGUnLCAnbWFyZ2luLWxlZnQ6IDEwcHg7IGJvcmRlcjogbm9uZTsgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7IGNvbG9yOiAjZmZmZmZmOycpXG4gIC8vIGNsb3NlQnRuLnRleHRDb250ZW50ID0gJ3gnXG5cbiAgLy8gY2xvc2VCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIC8vICAgbXNnLnJlbW92ZSgpXG4gIC8vIH0pXG5cbiAgLy8gbXNnLmFwcGVuZCh0ZXh0LCBjbG9zZUJ0bilcbiAgZG9jdW1lbnQuYm9keS5wcmVwZW5kKG1zZylcbn1cblxuZXhwb3J0IGRlZmF1bHQgZGlzcGxheU1lc3NhZ2VPbkVycExvZ2luUGFnZVxuIiwiLy8gY3JlYXRlIGEgcGluIGRpYWxvZyB1c2luZyBodG1sXG5jb25zdCBwaW5EaWFsb2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaWFsb2cnKVxucGluRGlhbG9nLmlkID0gJ3BpbkRpYWxvZydcbnBpbkRpYWxvZy5vcGVuID0gZmFsc2VcbnBpbkRpYWxvZy5pbm5lckhUTUwgPSBgXG4gIDxkaXYgY2xhc3M9XCJwcm9tcHRcIj5cbiAgICBFbnRlciB5b3VyIDQgZGlnaXQgUElOXG4gIDwvZGl2PlxuICA8Zm9ybSBjbGFzcz1cImRpZ2l0LWdyb3VwXCIgZGF0YS1ncm91cC1uYW1lPVwiZGlnaXRzXCIgZGF0YS1hdXRvc3VibWl0PVwiZmFsc2VcIiBhdXRvY29tcGxldGU9XCJvZmZcIj5cblx0PGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIGlkPVwiZGlnaXQtMVwiIG5hbWU9XCJkaWdpdC0xXCIgZGF0YS1uZXh0PVwiZGlnaXQtMlwiIC8+XG4gICAgPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIGlkPVwiZGlnaXQtMlwiIG5hbWU9XCJkaWdpdC0yXCIgZGF0YS1uZXh0PVwiZGlnaXQtM1wiIGRhdGEtcHJldmlvdXM9XCJkaWdpdC0xXCIgLz5cbiAgICA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgaWQ9XCJkaWdpdC0zXCIgbmFtZT1cImRpZ2l0LTNcIiBkYXRhLW5leHQ9XCJkaWdpdC00XCIgZGF0YS1wcmV2aW91cz1cImRpZ2l0LTJcIiAvPlxuICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBpZD1cImRpZ2l0LTRcIiBuYW1lPVwiZGlnaXQtNFwiIGRhdGEtcHJldmlvdXM9XCJkaWdpdC0zXCIgLz5cbiAgPC9mb3JtPlxuXHQ8YnV0dG9uIGlkPVwicGluRGlhbG9nQ2xvc2VCdG5cIj5DbG9zZTwvYnV0dG9uPlxuYFxuXG5jb25zdCBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJylcbnN0eWxlLmlubmVySFRNTCA9IGBcbmJvZHkge1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuZGlhbG9nIHtcbiAgICB6LWluZGV4OiAyMTQ3NDgzNjQ2ICFpbXBvcnRhbnQ7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIC8vIHRvcDogNTAlO1xuICAgIGxlZnQ6IDUwJTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAwJSk7XG4gICAgd2lkdGg6IDM0MHB4O1xuICAgIC8vIGhlaWdodDogMjAwcHg7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIGJvcmRlci1yYWRpdXM6IDAgMCAzcHggM3B4O1xuICAgIGJveC1zaGFkb3c6IDAgM3B4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjUpO1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAzNXB4O1xuICAgIG1hcmdpbjogMDtcbiAgICBcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIC8vIGJhY2tncm91bmQtY29sb3I6ICMwZjBmMWE7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5cbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIke2Nocm9tZS5ydW50aW1lLmdldFVSTCgnYXNzZXRzL2ltYWdlcy9leHRfaWNvbi5wbmcnKX1cIik7XG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiAyNXB4IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kLXNpemU6IDUwcHg7XG4gIH1cbiAgXG4gIGRpYWxvZzo6YmFja2Ryb3Age1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCAwIDAgLyAwLjUpO1xuICAgIC8vIGJhY2tkcm9wLWZpbHRlcjogYmx1cigzcHgpO1xuICB9XG5cbiAgXG4uZGlnaXQtZ3JvdXAgaW5wdXQge1xuICB3aWR0aDogMzBweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjMTgxODJhO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBib3JkZXI6IDJweCBzb2xpZCBncmF5O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIGJvcmRlci1vcGFjaXR5OiAwLjU7XG4gIGxpbmUtaGVpZ2h0OiA1MHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgZm9udC1mYW1pbHk6IFwiUmFsZXdheVwiLCBzYW5zLXNlcmlmO1xuICBmb250LXdlaWdodDogMjAwO1xuICAvLyBjb2xvcjogd2hpdGU7XG4gIGNvbG9yOiBibGFjaztcbiAgbWFyZ2luOiAwIDJweDtcbn1cblxuLnByb21wdCB7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgLy8gY29sb3I6IHdoaXRlO1xuICBjb2xvcjogYmxhY2s7XG59XG4jcGluRGlhbG9nQ2xvc2VCdG4ge1xuICBtYXJnaW4tdG9wOiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIGJvcmRlcjogbm9uZTtcbiAgLy8gY29sb3I6IHdoaXRlO1xuICBjb2xvcjogYmxhY2s7XG4gIHBhZGRpbmc6IDVweCAxMHB4O1xufVxuYFxuXG5hc3luYyBmdW5jdGlvbiBnZXRQaW5Gcm9tRGlhbG9nKCk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGxldCBwaW4gPSAnJ1xuICAvLyBhZGQgdGhlIGVsZW1lbnRzIHRvIHRoZSBET01cbiAgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzdHlsZSlcbiAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChwaW5EaWFsb2cpXG5cbiAgLy8gc2hvdyB0aGUgcGluIGRpYWxvZ1xuICBwaW5EaWFsb2cuc2hvd01vZGFsKClcblxuICAvLyBnZXQgdGhlIHBpbiBmcm9tIHRoZSBkaWFsb2dcbiAgLy8gY29udmVydCBhYm92ZSBqUXVlcnkgY29kZSB0byBqYXZhc2NyaXB0XG4gIGNvbnN0IHBpbkRpYWxvZ0Nsb3NlQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3BpbkRpYWxvZ0Nsb3NlQnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnRcbiAgcGluRGlhbG9nQ2xvc2VCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgcGluRGlhbG9nLmNsb3NlKClcbiAgfSlcbiAgY29uc3QgZGlnaXRHcm91cHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuZGlnaXQtZ3JvdXAnKVxuICBkaWdpdEdyb3Vwcy5mb3JFYWNoKChkaWdpdEdyb3VwKSA9PiB7XG4gICAgY29uc3QgaW5wdXRzID0gZGlnaXRHcm91cC5xdWVyeVNlbGVjdG9yQWxsKCdpbnB1dCcpXG4gICAgaW5wdXRzLmZvckVhY2goKGlucHV0KSA9PiB7XG4gICAgICBpbnB1dC5zZXRBdHRyaWJ1dGUoJ21heGxlbmd0aCcsICcxJylcbiAgICAgIGlucHV0LmFkZEV2ZW50TGlzdGVuZXIoJ2tleXVwJywgKGUpID0+IHtcbiAgICAgICAgY29uc3QgcGFyZW50ID0gaW5wdXQucGFyZW50RWxlbWVudCBhcyBhbnlcbiAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gOCB8fCBlLmtleUNvZGUgPT09IDM3KSB7XG4gICAgICAgICAgY29uc3QgcHJldiA9IHBhcmVudC5xdWVyeVNlbGVjdG9yKGBpbnB1dCMke2lucHV0LmRhdGFzZXQucHJldmlvdXN9YClcbiAgICAgICAgICBpZiAocHJldikgcHJldi5zZWxlY3QoKVxuICAgICAgICB9IGVsc2UgaWYgKFxuICAgICAgICAgIChlLmtleUNvZGUgPj0gNDggJiYgZS5rZXlDb2RlIDw9IDU3KSB8fFxuICAgICAgICAgIChlLmtleUNvZGUgPj0gNjUgJiYgZS5rZXlDb2RlIDw9IDkwKSB8fFxuICAgICAgICAgIChlLmtleUNvZGUgPj0gOTYgJiYgZS5rZXlDb2RlIDw9IDEwNSkgfHxcbiAgICAgICAgICBlLmtleUNvZGUgPT09IDM5XG4gICAgICAgICkge1xuICAgICAgICAgIGNvbnN0IG5leHQgPSBwYXJlbnQucXVlcnlTZWxlY3RvcihgaW5wdXQjJHtpbnB1dC5kYXRhc2V0Lm5leHR9YClcbiAgICAgICAgICBpZiAobmV4dCkgbmV4dC5zZWxlY3QoKVxuICAgICAgICAgIGVsc2UgaWYgKHBhcmVudC5kYXRhc2V0LmF1dG9zdWJtaXQpIHtcbiAgICAgICAgICAgIC8vIHByaW50IHRoZSBwaW5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGlucHV0c1swXS52YWx1ZSArIGlucHV0c1sxXS52YWx1ZSArIGlucHV0c1syXS52YWx1ZSArIGlucHV0c1szXS52YWx1ZSlcbiAgICAgICAgICAgIHBpbiA9IGlucHV0c1swXS52YWx1ZSArIGlucHV0c1sxXS52YWx1ZSArIGlucHV0c1syXS52YWx1ZSArIGlucHV0c1szXS52YWx1ZVxuICAgICAgICAgICAgcGluRGlhbG9nLmNsb3NlKClcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfSlcbiAgfSlcblxuICAvLyB3YWl0IGZvciB0aGUgcGluIHRvIGJlIGVudGVyZWRcbiAgYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBwaW5EaWFsb2cuYWRkRXZlbnRMaXN0ZW5lcignY2xvc2UnLCByZXNvbHZlKVxuICB9KVxuXG4gIC8vIHJlbW92ZSB0aGUgcGluIGRpYWxvZ1xuICBwaW5EaWFsb2cucmVtb3ZlKClcbiAgc3R5bGUucmVtb3ZlKClcblxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIHJlc29sdmUocGluKVxuICB9KVxufVxuXG5leHBvcnQgZGVmYXVsdCBnZXRQaW5Gcm9tRGlhbG9nXG4iLCJlbnVtIEZpZWxkVmFsaWRhdGlvblN0YXR1cyB7XG4gIFNvbWVGaWVsZElzRW1wdHksXG4gIEFsbEZpZWxkc0ZpbGxlZFxufVxuXG5jb25zdCB2YWxpZGF0ZUNyZWRlbnRpYWxzID0gKGNyZWRPYmpGcm9tU3RvcmFnZTogeyBba2V5OiBzdHJpbmddOiB1bmtub3duIH0pOiBGaWVsZFZhbGlkYXRpb25TdGF0dXMgPT4ge1xuICBpZiAoXG4gICAgY3JlZE9iakZyb21TdG9yYWdlLnVzZXJuYW1lICE9PSAnJyAmJlxuICAgIGNyZWRPYmpGcm9tU3RvcmFnZS5wYXNzd29yZCAhPT0gJycgJiZcbiAgICBjcmVkT2JqRnJvbVN0b3JhZ2UucTEgIT09ICdZb3VyIEVSUCBxdWVzdGlvbiAxJyAmJlxuICAgIGNyZWRPYmpGcm9tU3RvcmFnZS5xMiAhPT0gJ1lvdXIgRVJQIHF1ZXN0aW9uIDInICYmXG4gICAgY3JlZE9iakZyb21TdG9yYWdlLnEzICE9PSAnWW91ciBFUlAgcXVlc3Rpb24gMycgJiZcbiAgICBjcmVkT2JqRnJvbVN0b3JhZ2UuYTEgIT09ICcnICYmXG4gICAgY3JlZE9iakZyb21TdG9yYWdlLmEyICE9PSAnJyAmJlxuICAgIGNyZWRPYmpGcm9tU3RvcmFnZS5hMyAhPT0gJydcbiAgKSB7XG4gICAgcmV0dXJuIEZpZWxkVmFsaWRhdGlvblN0YXR1cy5BbGxGaWVsZHNGaWxsZWRcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gRmllbGRWYWxpZGF0aW9uU3RhdHVzLlNvbWVGaWVsZElzRW1wdHlcbiAgfVxufVxuXG5leHBvcnQgeyBGaWVsZFZhbGlkYXRpb25TdGF0dXMgfVxuZXhwb3J0IGRlZmF1bHQgdmFsaWRhdGVDcmVkZW50aWFsc1xuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJpbXBvcnQgQ3JlZGVudGlhbCBmcm9tICdtb2RlbHMvQ3JlZGVudGlhbCdcbmltcG9ydCB7IGRlY3J5cHQgfSBmcm9tICdzZXJ2aWNlcy9jcnlwdG8nXG5pbXBvcnQgZGlzcGxheU1lc3NhZ2VPbkVycExvZ2luUGFnZSBmcm9tICd1dGlscy9kaXNwbGF5TWVzc2FnZU9uRXJwTG9naW5QYWdlJ1xuaW1wb3J0IGZldGNoRnJvbUVycCBmcm9tICd1dGlscy9mZXRjaEZyb21FcnAnXG5pbXBvcnQgZ2V0UGluRnJvbURpYWxvZyBmcm9tICd1dGlscy9waW5EaWFsb2cnXG5pbXBvcnQgdmFsaWRhdGVDcmVkZW50aWFscywgeyBGaWVsZFZhbGlkYXRpb25TdGF0dXMgfSBmcm9tICd1dGlscy92YWxpZGF0ZUNyZWRlbnRpYWxzJ1xuXG4vLyBDcmVhdGUgYW4gb2JzZXJ2ZXIgaW5zdGFuY2UgbGlua2VkIHRvIHRoZSBjYWxsYmFjayBmdW5jdGlvblxuXG5jb25zdCBsb2dpbiA9IGFzeW5jIChyZXM6IHsgW2tleTogc3RyaW5nXTogdW5rbm93biB9KSA9PiB7XG4gIC8qKlxuICAgKiA/U2tpcCBpZiBubyBjcmVkZW50aWFscyBhcmUgc3RvcmVkIG9yIGF1dG9Mb2dpbiBpcyBub3QgZW5hYmxlZFxuICAgKi9cblxuICBpZiAoIXJlcy5hdXRoQ3JlZGVudGlhbHMpIHtcbiAgICBkaXNwbGF5TWVzc2FnZU9uRXJwTG9naW5QYWdlKCdZb3UgaGF2ZSBleHRlbnNpb24gZm9yIGF1dG9tYXRpYyBsb2dpbi4gUGxlYXNlIGZpbGwgaXQnLCAnIzcxNTEwMCcpXG4gICAgcmV0dXJuXG4gIH1cblxuICBjb25zdCBjcmVkZW50aWFscyA9IHJlcy5hdXRoQ3JlZGVudGlhbHMgYXMgQ3JlZGVudGlhbFxuXG4gIGlmICghY3JlZGVudGlhbHMuYXV0b0xvZ2luKSB7XG4gICAgZGlzcGxheU1lc3NhZ2VPbkVycExvZ2luUGFnZSgnQXV0b21hdGljIGxvZ2luIGlzIHR1cm5lZCBvZmYhJywgJyM0YTRhNGYnKVxuICAgIHJldHVyblxuICB9XG5cbiAgY29uc3QgZmllbGRzVmFsaWRhdGlvblN0YXR1cyA9IHZhbGlkYXRlQ3JlZGVudGlhbHMocmVzLmF1dGhDcmVkZW50aWFscyBhcyB7IFtrZXk6IHN0cmluZ106IHVua25vd24gfSlcblxuICBpZiAoZmllbGRzVmFsaWRhdGlvblN0YXR1cyA9PT0gRmllbGRWYWxpZGF0aW9uU3RhdHVzLlNvbWVGaWVsZElzRW1wdHkpIHtcbiAgICBkaXNwbGF5TWVzc2FnZU9uRXJwTG9naW5QYWdlKCdQbGVhc2UgZmlsbCBhbGwgdGhlIGZpZWxkcycsICcjNGE0YTRmJylcbiAgICByZXR1cm5cbiAgfVxuXG4gIC8qKlxuICAgKiA/SW5pdGlhbGl6ZSB0aGUgbG9naW4gcHJvY2Vzc1xuICAgKi9cblxuICBpZiAoZmllbGRzVmFsaWRhdGlvblN0YXR1cyA9PT0gRmllbGRWYWxpZGF0aW9uU3RhdHVzLkFsbEZpZWxkc0ZpbGxlZClcbiAgICBkaXNwbGF5TWVzc2FnZU9uRXJwTG9naW5QYWdlKCdQcmVmaWxsaW5nIGNyZWRlbnRpYWxzISBwbGVhc2Ugd2FpdC4uLicpXG5cbiAgY29uc3QgeyByZXF1aXJlUGluLCB1c2VybmFtZSB9ID0gY3JlZGVudGlhbHNcblxuICBsZXQgcGluID0gJydcbiAgaWYgKHJlcXVpcmVQaW4pIHtcbiAgICByZXMudXNlQWx0UElORGlhbG9nID8gKHBpbiA9IGF3YWl0IGdldFBpbkZyb21EaWFsb2coKSkgOiAocGluID0gcHJvbXB0KCdFbnRlciB5b3VyIDQgZGlnaXQgUElOJykgPz8gJycpXG4gIH1cblxuICBsZXQgcGFzc3dvcmQgPSAnJyxcbiAgICBxdWVzdGlvbiA9ICcnLFxuICAgIGFuc3dlciA9ICcnXG5cbiAgY29uc3QgdXNlcm5hbWVJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd1c2VyX2lkJykgYXMgSFRNTElucHV0RWxlbWVudFxuXG4gIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoYXN5bmMgKG11dGF0aW9uTGlzdCwgb2JzZXJ2ZXIpID0+IHtcbiAgICBsZXQgW211dGF0aW9uXSA9IG11dGF0aW9uTGlzdFxuICAgIGxldCBbbm9kZV0gPSBtdXRhdGlvbi5hZGRlZE5vZGVzXG5cbiAgICBxdWVzdGlvbiA9IG5vZGUubm9kZVZhbHVlIGFzIHN0cmluZ1xuICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKVxuXG4gICAgc3dpdGNoIChxdWVzdGlvbikge1xuICAgICAgY2FzZSBjcmVkZW50aWFscy5xMTpcbiAgICAgICAgYW5zd2VyID0gY3JlZGVudGlhbHMuYTFcbiAgICAgICAgYnJlYWtcblxuICAgICAgY2FzZSBjcmVkZW50aWFscy5xMjpcbiAgICAgICAgYW5zd2VyID0gY3JlZGVudGlhbHMuYTJcbiAgICAgICAgYnJlYWtcblxuICAgICAgY2FzZSBjcmVkZW50aWFscy5xMzpcbiAgICAgICAgYW5zd2VyID0gY3JlZGVudGlhbHMuYTNcbiAgICAgICAgYnJlYWtcblxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgLyoqXG4gICAgICAgICAqICFUaGlzIG1lYW5zIHRoYXQgdGhlIGNyZWRlbnRpYWxzIGFyZSBpbnZhbGlkXG4gICAgICAgICAqL1xuICAgICAgICBkaXNwbGF5TWVzc2FnZU9uRXJwTG9naW5QYWdlKCdJbnZhbGlkIHVzZXJuYW1lL3Bhc3N3b3JkIHNldCEgUGxlYXNlIHVwZGF0ZSB5b3VyIGNyZWRlbnRpYWxzJywgJyNhNDAwMGYnKVxuICAgICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBpZiAocmVxdWlyZVBpbikge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGFzc3dvcmQgPSBhd2FpdCBkZWNyeXB0KGNyZWRlbnRpYWxzLnBhc3N3b3JkLCBwaW4gYXMgc3RyaW5nKVxuICAgICAgICBhbnN3ZXIgPSBhd2FpdCBkZWNyeXB0KGFuc3dlciwgcGluIGFzIHN0cmluZylcbiAgICAgIH0gY2F0Y2ggKF8pIHtcbiAgICAgICAgZGlzcGxheU1lc3NhZ2VPbkVycExvZ2luUGFnZSgnSW5jb3JyZWN0IFBJTiEsIFBsZWFzZSByZXNldCBpZiBmb3Jnb3Qgb3IgcmVmcmVzaCBwYWdlIHRvIHJldHJ5LicsICcjYTQwMDBmJylcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhc3N3b3JkID0gY3JlZGVudGlhbHMucGFzc3dvcmRcbiAgICB9XG5cbiAgICBkaXNwbGF5TWVzc2FnZU9uRXJwTG9naW5QYWdlKCdQcmVmaWxsaW5nIGNyZWRlbnRpYWxzISBwbGVhc2Ugd2FpdC4uLicpXG5cbiAgICBsZXQgcGFzc3dvcmRJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwYXNzd29yZCcpIGFzIEhUTUxJbnB1dEVsZW1lbnRcbiAgICBsZXQgYW5zd2VySW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYW5zd2VyJykgYXMgSFRNTElucHV0RWxlbWVudFxuXG4gICAgaWYgKCFwYXNzd29yZElucHV0IHx8ICFhbnN3ZXJJbnB1dCkge1xuICAgICAgZGlzcGxheU1lc3NhZ2VPbkVycExvZ2luUGFnZSgnU29tZXRoaW5nIHdlbnQgd3JvbmchIFBsZWFzZSByZWZyZXNoIHBhZ2UgYW5kIHJldHJ5JywgJyNhNDAwMGYnKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgcGFzc3dvcmRJbnB1dC52YWx1ZSA9IHBhc3N3b3JkXG4gICAgYW5zd2VySW5wdXQudmFsdWUgPSBhbnN3ZXJcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZ2V0b3RwJyk/LmNsaWNrKCk7XG5cbiAgICBkaXNwbGF5TWVzc2FnZU9uRXJwTG9naW5QYWdlKFwiRGF0YSBmaWxsZWQgYW5kICdPVFAnIHdhcyBzZW50IHRvIG1haWwuIEZpbGwgdGhlIE9UUCBmcm9tIHlvdXIgbWFpbFwiLCAnIzRhNGE0ZicpXG4gIH0pXG5cbiAgaWYgKHVzZXJuYW1lSW5wdXQpIHtcbiAgICBvYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdhbnN3ZXJfZGl2JykgYXMgTm9kZSwge1xuICAgICAgYXR0cmlidXRlczogZmFsc2UsXG4gICAgICBjaGlsZExpc3Q6IHRydWUsXG4gICAgICBzdWJ0cmVlOiB0cnVlXG4gICAgfSlcblxuICAgIC8vIG1ha2Ugc3VyZVxuICAgIHVzZXJuYW1lSW5wdXQudmFsdWUgPSB1c2VybmFtZVxuICAgIHVzZXJuYW1lSW5wdXQuYmx1cigpXG4gIH1cbn1cblxuY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFxuICB7XG4gICAgYXV0aENyZWRlbnRpYWxzOiBudWxsLFxuICAgIGxhbmRpbmdQYWdlOiBudWxsLFxuICAgIHVzZUFsdFBJTkRpYWxvZzogZmFsc2VcbiAgfSxcbiAgbG9naW5cbilcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==